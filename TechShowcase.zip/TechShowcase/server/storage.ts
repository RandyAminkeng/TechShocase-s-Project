import type {
  User, InsertUser,
  Subject, InsertSubject,
  Course, InsertCourse,
  Lesson, InsertLesson,
  UserProgress, InsertUserProgress,
  UserStats, InsertUserStats,
  Resource, InsertResource,
  AiChatHistory, InsertAiChatHistory,
  MoodEntry, InsertMoodEntry,
  StudySession, InsertStudySession,
  MotivationGoal, InsertMotivationGoal,
  AiMotivationInsight, InsertAiMotivationInsight,
  LearningStreak, InsertLearningStreak
} from "../shared/schema";
import { users, subjects, courses, lessons, userProgress, userStats, resources, aiChatHistory, moodEntries, studySessions, motivationGoals, aiMotivationInsights, learningStreaks } from "../shared/schema";
import { db } from "./db";
import { eq, and, isNull, desc, gte, lte, count, sum, avg } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  updateUser(id: number, updateUser: Partial<User>): Promise<User>;
  
  // Subject methods
  getSubjects(): Promise<Subject[]>;
  getSubject(id: number): Promise<Subject | undefined>;
  createSubject(insertSubject: InsertSubject): Promise<Subject>;
  
  // Course methods
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesBySubject(subjectId: number): Promise<Course[]>;
  createCourse(insertCourse: InsertCourse): Promise<Course>;
  
  // Lesson methods
  getLessons(): Promise<Lesson[]>;
  getLesson(id: number): Promise<Lesson | undefined>;
  getLessonsByCourse(courseId: number): Promise<Lesson[]>;
  createLesson(insertLesson: InsertLesson): Promise<Lesson>;
  
  // User Progress methods
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getUserProgressByLesson(userId: number, lessonId: number): Promise<UserProgress | undefined>;
  createUserProgress(insertUserProgress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: number, updateUserProgress: Partial<UserProgress>): Promise<UserProgress>;
  
  // User Stats methods
  getUserStats(userId: number): Promise<UserStats | undefined>;
  createUserStats(insertUserStats: InsertUserStats): Promise<UserStats>;
  updateUserStats(userId: number, updateUserStats: Partial<UserStats>): Promise<UserStats>;
  
  // Resource methods
  getResources(): Promise<Resource[]>;
  getResource(id: number): Promise<Resource | undefined>;
  getResourcesBySubject(subjectId: number): Promise<Resource[]>;
  createResource(insertResource: InsertResource): Promise<Resource>;
  
  // AI Chat History methods
  getAiChatHistory(userId: number): Promise<AiChatHistory[]>;
  createAiChatHistory(insertAiChatHistory: InsertAiChatHistory): Promise<AiChatHistory>;
  
  // Mood and Motivation methods
  getMoodEntries(userId: number): Promise<MoodEntry[]>;
  createMoodEntry(insertEntry: InsertMoodEntry): Promise<MoodEntry>;
  getStudySessions(userId: number): Promise<StudySession[]>;
  getActiveStudySession(userId: number): Promise<StudySession | undefined>;
  createStudySession(insertSession: InsertStudySession): Promise<StudySession>;
  updateStudySession(id: number, updateSession: Partial<StudySession>): Promise<StudySession>;
  getMotivationGoals(userId: number): Promise<MotivationGoal[]>;
  createMotivationGoal(insertGoal: InsertMotivationGoal): Promise<MotivationGoal>;
  updateMotivationGoal(id: number, updateGoal: Partial<MotivationGoal>): Promise<MotivationGoal>;
  getAiMotivationInsights(userId: number): Promise<AiMotivationInsight[]>;
  createAiMotivationInsight(insertInsight: InsertAiMotivationInsight): Promise<AiMotivationInsight>;
  getLearningStreak(userId: number): Promise<LearningStreak | undefined>;
  updateLearningStreak(userId: number, insertStreak: InsertLearningStreak): Promise<LearningStreak>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updateUser: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updateUser)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Subject methods
  async getSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject;
  }

  async createSubject(insertSubject: InsertSubject): Promise<Subject> {
    const [subject] = await db.insert(subjects).values(insertSubject).returning();
    return subject;
  }

  // Course methods
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async getCoursesBySubject(subjectId: number): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.subjectId, subjectId));
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db.insert(courses).values(insertCourse).returning();
    return course;
  }

  // Lesson methods
  async getLessons(): Promise<Lesson[]> {
    return await db.select().from(lessons);
  }

  async getLesson(id: number): Promise<Lesson | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson;
  }

  async getLessonsByCourse(courseId: number): Promise<Lesson[]> {
    return await db.select().from(lessons).where(eq(lessons.courseId, courseId));
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const [lesson] = await db.insert(lessons).values(insertLesson).returning();
    return lesson;
  }

  // User Progress methods
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getUserProgressByLesson(userId: number, lessonId: number): Promise<UserProgress | undefined> {
    const [progress] = await db.select().from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.lessonId, lessonId)));
    return progress;
  }

  async createUserProgress(insertUserProgress: InsertUserProgress): Promise<UserProgress> {
    const [progress] = await db.insert(userProgress).values(insertUserProgress).returning();
    return progress;
  }

  async updateUserProgress(id: number, updateUserProgress: Partial<UserProgress>): Promise<UserProgress> {
    const [progress] = await db
      .update(userProgress)
      .set(updateUserProgress)
      .where(eq(userProgress.id, id))
      .returning();
    return progress;
  }

  // User Stats methods
  async getUserStats(userId: number): Promise<UserStats | undefined> {
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    return stats;
  }

  async createUserStats(insertUserStats: InsertUserStats): Promise<UserStats> {
    const [stats] = await db.insert(userStats).values(insertUserStats).returning();
    return stats;
  }

  async updateUserStats(userId: number, updateUserStats: Partial<UserStats>): Promise<UserStats> {
    const [stats] = await db
      .update(userStats)
      .set(updateUserStats)
      .where(eq(userStats.userId, userId))
      .returning();
    return stats;
  }

  // Resource methods
  async getResources(): Promise<Resource[]> {
    return await db.select().from(resources);
  }

  async getResource(id: number): Promise<Resource | undefined> {
    const [resource] = await db.select().from(resources).where(eq(resources.id, id));
    return resource;
  }

  async getResourcesBySubject(subjectId: number): Promise<Resource[]> {
    return await db.select().from(resources).where(eq(resources.subjectId, subjectId));
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const [resource] = await db.insert(resources).values(insertResource).returning();
    return resource;
  }

  // AI Chat History methods
  async getAiChatHistory(userId: number): Promise<AiChatHistory[]> {
    return await db.select().from(aiChatHistory)
      .where(eq(aiChatHistory.userId, userId))
      .orderBy(desc(aiChatHistory.timestamp));
  }

  async createAiChatHistory(insertAiChatHistory: InsertAiChatHistory): Promise<AiChatHistory> {
    const [history] = await db.insert(aiChatHistory).values(insertAiChatHistory).returning();
    return history;
  }

  // Mood and Motivation methods - FIXED
  async getMoodEntries(userId: number): Promise<MoodEntry[]> {
    return await db.select().from(moodEntries)
      .where(eq(moodEntries.userId, userId))
      .orderBy(desc(moodEntries.date));
  }

  async createMoodEntry(insertEntry: InsertMoodEntry): Promise<MoodEntry> {
    const [entry] = await db.insert(moodEntries).values(insertEntry).returning();
    return entry;
  }

  async getStudySessions(userId: number): Promise<StudySession[]> {
    return await db.select().from(studySessions).where(eq(studySessions.userId, userId));
  }

  async getActiveStudySession(userId: number): Promise<StudySession | undefined> {
    const [session] = await db.select().from(studySessions)
      .where(and(eq(studySessions.userId, userId), isNull(studySessions.endTime)));
    return session || undefined;
  }

  async createStudySession(insertSession: InsertStudySession): Promise<StudySession> {
    const [session] = await db.insert(studySessions).values(insertSession).returning();
    return session;
  }

  async updateStudySession(id: number, updateSession: Partial<StudySession>): Promise<StudySession> {
    const [session] = await db
      .update(studySessions)
      .set(updateSession)
      .where(eq(studySessions.id, id))
      .returning();
    return session;
  }

  async getMotivationGoals(userId: number): Promise<MotivationGoal[]> {
    return await db.select().from(motivationGoals).where(eq(motivationGoals.userId, userId));
  }

  async createMotivationGoal(insertGoal: InsertMotivationGoal): Promise<MotivationGoal> {
    const [goal] = await db.insert(motivationGoals).values(insertGoal).returning();
    return goal;
  }

  async updateMotivationGoal(id: number, updateGoal: Partial<MotivationGoal>): Promise<MotivationGoal> {
    const [goal] = await db
      .update(motivationGoals)
      .set(updateGoal)
      .where(eq(motivationGoals.id, id))
      .returning();
    return goal;
  }

  async getAiMotivationInsights(userId: number): Promise<AiMotivationInsight[]> {
    return await db.select().from(aiMotivationInsights)
      .where(eq(aiMotivationInsights.userId, userId))
      .orderBy(desc(aiMotivationInsights.generatedAt));
  }

  async createAiMotivationInsight(insertInsight: InsertAiMotivationInsight): Promise<AiMotivationInsight> {
    const [insight] = await db.insert(aiMotivationInsights).values(insertInsight).returning();
    return insight;
  }

  async getLearningStreak(userId: number): Promise<LearningStreak | undefined> {
    const [streak] = await db.select().from(learningStreaks).where(eq(learningStreaks.userId, userId));
    return streak;
  }

  async updateLearningStreak(userId: number, insertStreak: InsertLearningStreak): Promise<LearningStreak> {
    const existing = await this.getLearningStreak(userId);
    if (existing) {
      const [streak] = await db
        .update(learningStreaks)
        .set(insertStreak)
        .where(eq(learningStreaks.userId, userId))
        .returning();
      return streak;
    } else {
      const [streak] = await db.insert(learningStreaks).values(insertStreak).returning();
      return streak;
    }
  }
}

export const storage = new DatabaseStorage();