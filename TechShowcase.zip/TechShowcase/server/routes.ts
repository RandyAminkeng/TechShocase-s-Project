import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { z } from "zod";
import { insertAiChatHistorySchema, insertUserProgressSchema } from "@shared/schema";
import { generateTutorResponse, generateResourceRecommendations } from "./openai";
import { geminiChatResponse, performIntelligentSearch as geminiSearch, generateCode as geminiCode, analyzeDrawing as geminiDrawing, solveMathProblem as geminiMath, translateText as geminiTranslate, summarizeContent as geminiSummarize, generateCreativeContent as geminiCreative, type ChatMessage } from "./gemini-ai";
import { performRealGoogleSearch, getRealGoogleSuggestions } from "./real-google-search";
import { searchGooglePlaces, translateText } from "./google-services";

// Voice Study Helper Functions
function generateMotivationalResponse(command: string, progress: number, goal: string) {
  const motivationalMessages = [
    {
      trigger: ['motivate', 'encourage', 'help'],
      messages: [
        "You're doing amazing! Every step forward is progress, no matter how small.",
        "I believe in your ability to achieve great things! Keep pushing forward!",
        "Your dedication to learning is inspiring. You've got this!",
        "Remember, every expert was once a beginner. You're on the right path!",
        "Your hard work is paying off! I can see your progress and I'm proud of you!"
      ]
    },
    {
      trigger: ['break', 'tired', 'difficult'],
      messages: [
        "Taking breaks is part of the learning process. Rest up and come back stronger!",
        "It's okay to feel challenged - that means you're growing! Take your time.",
        "Even the greatest minds needed breaks. Recharge and return with fresh energy!",
        "Difficulty is just another word for opportunity to learn something new!",
        "Your brain needs rest to consolidate what you've learned. Well-deserved break!"
      ]
    },
    {
      trigger: ['goal', 'target', 'objective'],
      messages: [
        `Your goal of "${goal}" is absolutely achievable! Let's break it down step by step.`,
        `With ${progress}% progress on "${goal}", you're already making great strides!`,
        `"${goal}" is a fantastic learning objective. I'm here to support you every step!`,
        `Your commitment to "${goal}" shows real dedication. Keep up the excellent work!`,
        `Every session brings you closer to mastering "${goal}". You're doing wonderfully!`
      ]
    }
  ];

  const lowerCommand = command.toLowerCase();
  let selectedMessage = "You're doing great! Keep up the excellent work!";
  
  for (const category of motivationalMessages) {
    if (category.trigger.some(trigger => lowerCommand.includes(trigger))) {
      selectedMessage = category.messages[Math.floor(Math.random() * category.messages.length)];
      break;
    }
  }

  let progressUpdate = "";
  if (progress < 25) {
    progressUpdate = "You're just getting started, and that's the hardest part! Great job taking the first steps!";
  } else if (progress < 50) {
    progressUpdate = "You're making solid progress! The momentum you're building is fantastic!";
  } else if (progress < 75) {
    progressUpdate = "Over halfway there! Your persistence is really showing results!";
  } else if (progress < 100) {
    progressUpdate = "You're so close to completing your goal! The finish line is in sight!";
  } else {
    progressUpdate = "Incredible! You've achieved your goal! Time to set even bigger challenges!";
  }

  return {
    message: selectedMessage,
    encouragement: progressUpdate,
    nextAction: generateNextAction(command, progress),
    progressUpdate: progress < 100 ? "Keep going, you're making progress!" : "Goal achieved! Set a new challenge!"
  };
}

function generateNextAction(command: string, progress: number): string {
  if (command.includes('quiz')) {
    return "Ready for a knowledge check? Let's see how much you've learned!";
  } else if (command.includes('break')) {
    return "Take 5-10 minutes to recharge, then we'll continue your learning journey!";
  } else if (progress < 50) {
    return "Let's focus on the fundamentals. Building a strong foundation is key!";
  } else {
    return "You're ready for more advanced concepts. Let's challenge ourselves!";
  }
}

function handleVoiceSession(action: string, sessionData: any) {
  switch (action) {
    case 'start':
      return {
        success: true,
        message: "Study session started! I'm here to keep you motivated and focused.",
        sessionId: `session_${Date.now()}`,
        tips: [
          "Use voice commands to control your session",
          "Ask for motivation whenever you need it",
          "Take breaks when needed - I'll remind you",
          "Set clear goals for better focus"
        ]
      };
    case 'pause':
      return {
        success: true,
        message: "Session paused. Take your time, I'll be here when you're ready!",
        reminder: "Remember to stay hydrated and stretch during your break!"
      };
    case 'end':
      return {
        success: true,
        message: "Excellent work! You should be proud of your dedication to learning.",
        summary: sessionData ? `You spent ${sessionData.duration || 0} minutes studying` : "Great study session completed!",
        achievement: "Learning Champion - Completed a voice study session!"
      };
    default:
      return {
        success: false,
        message: "I didn't understand that action. Try 'start', 'pause', or 'end'."
      };
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // All API routes are prefixed with /api
  
  // Users
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    const userId = Number(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't send password in response
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Current User (mock for demo purposes)
  app.get("/api/me", async (req: Request, res: Response) => {
    const user = await storage.getUserByUsername("randy");
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't send password in response
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Update User Profile
  app.put("/api/users/:id", async (req: Request, res: Response) => {
    const userId = Number(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const schema = z.object({
      name: z.string().optional(),
      email: z.string().email().optional(),
      bio: z.string().optional(),
      avatar: z.string().optional()
    });

    try {
      const updates = schema.parse(req.body);
      const user = await storage.updateUser(userId, updates);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send password in response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Invalid request", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Update Current User
  app.put("/api/me", async (req: Request, res: Response) => {
    const schema = z.object({
      name: z.string().optional(),
      email: z.string().email().optional(),
      bio: z.string().optional(),
      avatar: z.string().optional()
    });

    try {
      const updates = schema.parse(req.body);
      const user = await storage.getUserByUsername("randy");
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.updateUser(user.id, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Failed to update user" });
      }
      
      // Don't send password in response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Invalid request", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Subjects
  app.get("/api/subjects", async (req: Request, res: Response) => {
    const subjects = await storage.getSubjects();
    res.json(subjects);
  });

  app.get("/api/subjects/:id", async (req: Request, res: Response) => {
    const subjectId = Number(req.params.id);
    if (isNaN(subjectId)) {
      return res.status(400).json({ message: "Invalid subject ID" });
    }
    
    const subject = await storage.getSubject(subjectId);
    if (!subject) {
      return res.status(404).json({ message: "Subject not found" });
    }
    
    res.json(subject);
  });

  // Courses
  app.get("/api/courses", async (req: Request, res: Response) => {
    const subjectId = req.query.subjectId ? Number(req.query.subjectId) : undefined;
    
    let courses;
    if (subjectId && !isNaN(subjectId)) {
      courses = await storage.getCoursesBySubject(subjectId);
    } else {
      courses = await storage.getCourses();
    }
    
    res.json(courses);
  });

  app.get("/api/courses/:id", async (req: Request, res: Response) => {
    const courseId = Number(req.params.id);
    if (isNaN(courseId)) {
      return res.status(400).json({ message: "Invalid course ID" });
    }
    
    const course = await storage.getCourse(courseId);
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    
    res.json(course);
  });

  // User Progress
  app.get("/api/progress/:userId", async (req: Request, res: Response) => {
    const userId = Number(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const progress = await storage.getUserProgress(userId);
    
    // Augment progress with course details
    const progressWithDetails = await Promise.all(progress.map(async (p) => {
      const course = await storage.getCourse(p.courseId || 0);
      return {
        ...p,
        course
      };
    }));
    
    res.json(progressWithDetails);
  });

  app.put("/api/progress/:id", async (req: Request, res: Response) => {
    const progressId = Number(req.params.id);
    if (isNaN(progressId)) {
      return res.status(400).json({ message: "Invalid progress ID" });
    }
    
    const schema = insertUserProgressSchema.partial();
    
    try {
      const validatedData = schema.parse(req.body);
      const updatedProgress = await storage.updateUserProgress(progressId, validatedData);
      res.json(updatedProgress);
    } catch (error) {
      res.status(400).json({ message: "Invalid data", error });
    }
  });

  // User Stats
  app.get("/api/stats/:userId", async (req: Request, res: Response) => {
    const userId = Number(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const stats = await storage.getUserStats(userId);
    if (!stats) {
      return res.status(404).json({ message: "User stats not found" });
    }
    
    res.json(stats);
  });

  app.put("/api/stats/:userId", async (req: Request, res: Response) => {
    const userId = Number(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    try {
      const updatedStats = await storage.updateUserStats(userId, req.body);
      res.json(updatedStats);
    } catch (error) {
      res.status(400).json({ message: "Error updating stats", error });
    }
  });

  // Resources
  app.get("/api/resources", async (req: Request, res: Response) => {
    const subjectId = req.query.subjectId ? Number(req.query.subjectId) : undefined;
    
    let resources;
    if (subjectId && !isNaN(subjectId)) {
      resources = await storage.getResourcesBySubject(subjectId);
    } else {
      resources = await storage.getResources();
    }
    
    res.json(resources);
  });

  app.get("/api/resources/recommended/:userId", async (req: Request, res: Response) => {
    const userId = Number(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const stats = await storage.getUserStats(userId);
    if (!stats) {
      return res.status(404).json({ message: "User stats not found" });
    }
    
    // Simple recommendation (in a real app, this would be more sophisticated)
    const resources = await storage.getResources();
    const recommended = resources.slice(0, 3);
    
    res.json(recommended);
  });

  // Real AI Chat (ChatGPT-like)
  app.post("/api/ai/chat", async (req: Request, res: Response) => {
    const schema = z.object({
      message: z.string(),
      conversationHistory: z.array(z.object({
        role: z.enum(['user', 'assistant', 'system']),
        content: z.string(),
        timestamp: z.string().optional()
      })).optional().default([]),
      systemPrompt: z.string().optional().default(""),
      context: z.string().optional().default("")
    });
    
    try {
      const { message, conversationHistory, systemPrompt, context } = schema.parse(req.body);
      
      const messages: ChatMessage[] = [
        ...(conversationHistory || []),
        { role: 'user', content: message, timestamp: new Date().toISOString() }
      ];
      
      const response = await geminiChatResponse(messages, systemPrompt || undefined);
      
      res.json(response);
    } catch (error) {
      console.error("AI Chat API error:", error);
      res.status(500).json({ message: "Failed to generate AI response", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Intelligent Search (Google-like AI search)
  app.post("/api/ai/search", async (req: Request, res: Response) => {
    const schema = z.object({
      query: z.string(),
      context: z.string().optional()
    });
    
    try {
      const { query, context } = schema.parse(req.body);
      
      const result = await geminiSearch({ query, context });
      
      res.json(result);
    } catch (error) {
      console.error("Intelligent Search API error:", error);
      res.status(500).json({ message: "Failed to perform intelligent search", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Code Generation
  app.post("/api/ai/code", async (req: Request, res: Response) => {
    const schema = z.object({
      description: z.string(),
      language: z.string().default("javascript"),
      context: z.string().optional()
    });
    
    try {
      const { description, language, context } = schema.parse(req.body);
      
      const result = await geminiCode(description, language);
      
      res.json(result);
    } catch (error) {
      console.error("Code Generation API error:", error);
      res.status(500).json({ message: "Failed to generate code", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Math Problem Solving
  app.post("/api/ai/math", async (req: Request, res: Response) => {
    const schema = z.object({
      problem: z.string()
    });
    
    try {
      const { problem } = schema.parse(req.body);
      
      const result = await geminiMath(problem);
      
      res.json(result);
    } catch (error) {
      console.error("Math Problem Solving API error:", error);
      res.status(500).json({ message: "Failed to solve math problem", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // AI Translation
  app.post("/api/ai/translate", async (req: Request, res: Response) => {
    const schema = z.object({
      text: z.string(),
      targetLanguage: z.string(),
      sourceLanguage: z.string().optional()
    });
    
    try {
      const { text, targetLanguage, sourceLanguage } = schema.parse(req.body);
      
      const result = await geminiTranslate(text, targetLanguage, sourceLanguage);
      
      res.json(result);
    } catch (error) {
      console.error("AI Translation API error:", error);
      res.status(500).json({ message: "Failed to translate text", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Content Summarization
  app.post("/api/ai/summarize", async (req: Request, res: Response) => {
    const schema = z.object({
      content: z.string(),
      maxLength: z.number().optional()
    });
    
    try {
      const { content, maxLength } = schema.parse(req.body);
      
      const result = await geminiSummarize(content, maxLength);
      
      res.json(result);
    } catch (error) {
      console.error("Content Summarization API error:", error);
      res.status(500).json({ message: "Failed to summarize content", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Creative Content Generation
  app.post("/api/ai/creative", async (req: Request, res: Response) => {
    const schema = z.object({
      prompt: z.string(),
      type: z.enum(['story', 'poem', 'article', 'essay', 'creative']),
      length: z.enum(['short', 'medium', 'long']).optional()
    });
    
    try {
      const { prompt, type, length } = schema.parse(req.body);
      
      const result = await geminiCreative(prompt, type);
      
      res.json(result);
    } catch (error) {
      console.error("Creative Content Generation API error:", error);
      res.status(500).json({ message: "Failed to generate creative content", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Whiteboard Drawing Analysis
  app.post("/api/ai/analyze-drawing", async (req: Request, res: Response) => {
    const schema = z.object({
      imageData: z.string(),
      context: z.string().optional()
    });
    
    try {
      const { imageData, context } = schema.parse(req.body);
      
      const result = await geminiDrawing(imageData, context);
      
      res.json(result);
    } catch (error) {
      console.error("Drawing Analysis API error:", error);
      res.status(500).json({ message: "Failed to analyze drawing", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // AI Tutor (Updated)
  app.post("/api/tutor/chat", async (req: Request, res: Response) => {
    const schema = z.object({
      question: z.string(),
      subject: z.string(),
      userId: z.number().optional().default(1),
      model: z.string().optional()
    });
    
    try {
      const { question, subject, userId, model } = schema.parse(req.body);
      
      // Use Gemini AI for reliable responses
      const chatResponse = await geminiChatResponse(
        [{ role: 'user', content: `Please provide educational tutoring for this ${subject} question: ${question}` }],
        `You are an expert ${subject} tutor. Provide clear, educational explanations with examples and follow-up questions to enhance learning.`
      );
      
      const response = {
        answer: chatResponse.message,
        explanation: `Educational explanation for ${subject}`,
        followUpQuestions: [
          `Can you explain more about ${subject} concepts?`,
          `Would you like practice problems?`,
          `Any other ${subject} questions?`
        ]
      };
      
      res.json(response);
    } catch (error) {
      console.error("Tutor chat API error:", error);
      res.status(400).json({ message: "Invalid request", error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.get("/api/tutor/history/:userId", async (req: Request, res: Response) => {
    const userId = Number(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const subjectId = req.query.subjectId ? Number(req.query.subjectId) : undefined;
    
    let history;
    if (subjectId && !isNaN(subjectId)) {
      history = await storage.getChatHistoryBySubject(userId, subjectId);
    } else {
      history = await storage.getChatHistory(userId);
    }
    
    // Parse the JSON responses
    const parsedHistory = history.map(entry => ({
      ...entry,
      response: JSON.parse(entry.response)
    }));
    
    res.json(parsedHistory);
  });
  
  app.post("/api/tutor/recommendations", async (req: Request, res: Response) => {
    const schema = z.object({
      userId: z.number(),
      subject: z.string(),
      performance: z.number().min(0).max(100)
    });
    
    try {
      const { userId, subject, performance } = schema.parse(req.body);
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const recommendations = await generateResourceRecommendations(
        userId,
        subject,
        performance
      );
      
      res.json(recommendations);
    } catch (error) {
      res.status(400).json({ message: "Invalid request", error });
    }
  });

  // Mood Tracking API Routes
  app.get("/api/mood/entries", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Using default user for now
      const entries = await storage.getMoodEntries(userId);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching mood entries:", error);
      res.status(500).json({ error: "Failed to fetch mood entries" });
    }
  });

  app.post("/api/mood/entries", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Using default user for now
      const { moodScore, energyLevel, motivationLevel, stressLevel, notes, tags } = req.body;
      
      const entry = await storage.createMoodEntry({
        userId,
        moodScore,
        energyLevel,
        motivationLevel,
        stressLevel,
        notes,
        tags: tags || []
      });

      res.json(entry);
    } catch (error) {
      console.error("Error creating mood entry:", error);
      res.status(500).json({ error: "Failed to create mood entry" });
    }
  });

  // Motivation Goals API Routes
  app.get("/api/motivation/goals", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Using default user for now
      const goals = await storage.getMotivationGoals(userId);
      res.json(goals);
    } catch (error) {
      console.error("Error fetching motivation goals:", error);
      res.status(500).json({ error: "Failed to fetch motivation goals" });
    }
  });

  app.post("/api/motivation/goals", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Using default user for now
      const goal = await storage.createMotivationGoal({
        userId,
        ...req.body
      });
      res.json(goal);
    } catch (error) {
      console.error("Error creating motivation goal:", error);
      res.status(500).json({ error: "Failed to create motivation goal" });
    }
  });

  // AI Insights API Routes
  app.get("/api/ai/insights", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Using default user for now
      const insights = await storage.getAiMotivationInsights(userId);
      res.json(insights);
    } catch (error) {
      console.error("Error fetching AI insights:", error);
      res.status(500).json({ error: "Failed to fetch AI insights" });
    }
  });

  // Search endpoints
  app.post("/api/search", async (req: Request, res: Response) => {
    try {
      const { query, type = 'all', timeFilter, regionFilter, languageFilter, safeSearch } = req.body;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: "Query is required" });
      }

      const filters = {
        timeFilter: timeFilter || 'any',
        regionFilter: regionFilter || 'all', 
        languageFilter: languageFilter || 'any',
        safeSearch: safeSearch || 'moderate'
      };

      const results = await performRealGoogleSearch(query.trim(), type, filters);
      
      // Generate AI-powered direct answer for comprehensive search experience
      let directAnswer = null;
      try {
        const aiResponse = await geminiSearch({ query: query.trim(), context: "educational search" });
        directAnswer = {
          answer: aiResponse.answer,
          sources: aiResponse.sources,
          relatedQuestions: aiResponse.relatedQuestions,
          confidence: 0.9
        };
      } catch (aiError) {
        console.log("AI answer generation failed, using search results only");
      }
      
      res.json({ 
        results, 
        query, 
        type,
        searchTime: (Math.random() * 0.5 + 0.1).toFixed(2),
        totalResults: Math.floor(Math.random() * 1000000) + 50000,
        directAnswer
      });
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ error: "Search failed" });
    }
  });

  app.get("/api/search/suggestions", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      
      if (!query) {
        return res.json({ suggestions: [] });
      }

      const suggestions = await getRealGoogleSuggestions(query);
      res.json({ suggestions });
    } catch (error) {
      console.error("Suggestions error:", error);
      res.json({ suggestions: [] });
    }
  });

  // Live activity endpoints
  app.get("/api/live/activities", async (req: Request, res: Response) => {
    try {
      const activities = (global as any).getLiveActivities?.() || [];
      res.json(activities);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/live/activity", async (req: Request, res: Response) => {
    try {
      const activity = req.body;
      (global as any).addLiveActivity?.(activity);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Voice Study and Motivational Coaching API
  app.post("/api/voice/motivation", async (req: Request, res: Response) => {
    try {
      const { command, progress, goal } = req.body;
      
      const motivationalResponse = generateMotivationalResponse(command, progress, goal);
      
      res.json(motivationalResponse);
    } catch (error: any) {
      console.error('Voice motivation error:', error);
      res.status(500).json({ error: 'Failed to generate motivation' });
    }
  });

  app.post("/api/voice/session", async (req: Request, res: Response) => {
    try {
      const { action, sessionData } = req.body;
      
      const response = handleVoiceSession(action, sessionData);
      
      res.json(response);
    } catch (error: any) {
      console.error('Voice session error:', error);
      res.status(500).json({ error: 'Failed to handle voice session' });
    }
  });

  // Google Maps and Places API integration
  app.post("/api/google/places", async (req: Request, res: Response) => {
    try {
      const { query, location, type } = req.body;
      
      if (!query) {
        return res.status(400).json({ error: "Query is required" });
      }

      const places = await searchGooglePlaces(query, location, type);
      res.json({ places, query });
    } catch (error) {
      console.error("Google Places search error:", error);
      res.status(500).json({ error: "Places search failed" });
    }
  });

  // Google Translate API integration
  app.post("/api/google/translate", async (req: Request, res: Response) => {
    try {
      const { text, targetLanguage, sourceLanguage } = req.body;
      
      if (!text || !targetLanguage) {
        return res.status(400).json({ error: "Text and target language are required" });
      }

      const translation = await translateText(text, targetLanguage, sourceLanguage);
      
      if (!translation) {
        return res.status(500).json({ error: "Translation failed" });
      }

      res.json(translation);
    } catch (error) {
      console.error("Google Translate error:", error);
      res.status(500).json({ error: "Translation failed" });
    }
  });

  const httpServer = createServer(app);
  
  // WebSocket server for real-time collaboration
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store active whiteboard rooms and users
  const whiteboardRooms = new Map();
  const userConnections = new Map();
  
  wss.on('connection', (ws: any) => {
    let userId: string | null = null;
    let roomId: string | null = null;
    
    ws.on('message', (message: Buffer) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'join_whiteboard':
            userId = data.userId;
            roomId = data.roomId;
            
            // Store user connection
            userConnections.set(userId, { ws, username: data.username, roomId });
            
            // Add user to room
            if (!whiteboardRooms.has(roomId)) {
              whiteboardRooms.set(roomId, new Set());
            }
            whiteboardRooms.get(roomId).add(userId);
            
            // Notify other users in the room
            if (roomId) {
              broadcastToRoom(roomId, {
                type: 'user_joined',
                userId,
                username: data.username
              }, userId);
            }
            
            console.log(`User ${data.username} joined whiteboard room ${roomId}`);
            break;
            
          case 'drawing_update':
            if (roomId) {
              broadcastToRoom(roomId, {
                type: 'drawing_update',
                path: data.path,
                userId
              }, userId);
            }
            break;
            
          case 'cursor_update':
            if (roomId) {
              const userConnection = userConnections.get(userId);
              if (userConnection) {
                broadcastToRoom(roomId, {
                  type: 'cursor_update',
                  userId,
                  username: userConnection.username,
                  x: data.x,
                  y: data.y,
                  color: getRandomColor()
                }, userId);
              }
            }
            break;
            
          case 'clear_canvas':
            if (roomId) {
              broadcastToRoom(roomId, {
                type: 'clear_canvas',
                userId
              }, userId);
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      if (userId && roomId) {
        // Remove user from room
        const room = whiteboardRooms.get(roomId);
        if (room) {
          room.delete(userId);
          if (room.size === 0) {
            whiteboardRooms.delete(roomId);
          }
        }
        
        // Remove user connection
        userConnections.delete(userId);
        
        // Notify other users
        if (roomId) {
          broadcastToRoom(roomId, {
            type: 'user_left',
            userId
          }, userId);
        }
        
        console.log(`User ${userId} left whiteboard room ${roomId}`);
      }
    });
  });
  
  function broadcastToRoom(roomId: string, message: any, excludeUserId?: string | null) {
    const room = whiteboardRooms.get(roomId);
    if (!room) return;
    
    for (const userId of room) {
      if (userId !== excludeUserId) {
        const userConnection = userConnections.get(userId);
        if (userConnection && userConnection.ws.readyState === 1) { // WebSocket.OPEN
          userConnection.ws.send(JSON.stringify(message));
        }
      }
    }
  }
  
  function getRandomColor() {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
    return colors[Math.floor(Math.random() * colors.length)];
  }
  
  return httpServer;
}
