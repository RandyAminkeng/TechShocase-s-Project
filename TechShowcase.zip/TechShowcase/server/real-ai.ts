import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: string;
}

export interface ChatResponse {
  message: string;
  conversationId?: string;
  timestamp: string;
  tokens?: number;
  model: string;
}

export interface SearchQuery {
  query: string;
  context?: string;
}

export interface IntelligentSearchResult {
  answer: string;
  sources: string[];
  relatedQuestions: string[];
  timestamp: string;
}

// Real ChatGPT-like conversation system
export async function generateChatResponse(
  message: string,
  conversationHistory: ChatMessage[] = [],
  systemPrompt?: string
): Promise<ChatResponse> {
  try {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: systemPrompt || 'You are a helpful, knowledgeable AI assistant. Provide accurate, detailed, and helpful responses to user questions.'
      },
      ...conversationHistory,
      {
        role: 'user',
        content: message
      }
    ];

    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // Latest OpenAI model
      messages: messages.map(msg => ({
        role: msg.role,
        content: msg.content
      })),
      temperature: 0.7,
      max_tokens: 2000,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0,
    });

    const response = completion.choices[0].message.content || "I apologize, but I couldn't generate a response.";
    
    return {
      message: response,
      timestamp: new Date().toISOString(),
      tokens: completion.usage?.total_tokens,
      model: "gpt-4o"
    };
  } catch (error) {
    console.error("OpenAI API Error:", error);
    
    // Return error for API configuration
    throw new Error("AI service temporarily unavailable. Please check your OpenAI API key configuration.");
  }
}

// Intelligent search with AI-powered analysis
export async function performIntelligentSearch(searchQuery: SearchQuery): Promise<IntelligentSearchResult> {
  try {
    const searchPrompt = `
You are an intelligent search assistant. For the query "${searchQuery.query}", provide:
1. A comprehensive, accurate answer
2. List of authoritative sources where this information can be verified
3. Related questions that might interest the user

Format your response as JSON:
{
  "answer": "detailed answer here",
  "sources": ["source1", "source2", "source3"],
  "relatedQuestions": ["question1", "question2", "question3"]
}
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: 'system',
          content: 'You are an expert research assistant. Provide accurate, well-sourced information in the requested JSON format.'
        },
        {
          role: 'user',
          content: searchPrompt
        }
      ],
      temperature: 0.3,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(completion.choices[0].message.content || '{}');
    
    return {
      answer: result.answer || "No answer available",
      sources: result.sources || [],
      relatedQuestions: result.relatedQuestions || [],
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error("Intelligent Search Error:", error);
    throw new Error("Failed to perform intelligent search");
  }
}

// Real-time code generation and analysis
export async function generateCode(
  description: string,
  language: string = "javascript",
  context?: string
): Promise<{ code: string; explanation: string }> {
  try {
    const codePrompt = `
Generate ${language} code for: ${description}
${context ? `Context: ${context}` : ''}

Provide clean, well-commented, production-ready code with explanation.
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: 'system',
          content: `You are an expert ${language} developer. Generate high-quality, efficient code with clear explanations.`
        },
        {
          role: 'user',
          content: codePrompt
        }
      ],
      temperature: 0.2,
      max_tokens: 2000
    });

    const response = completion.choices[0].message.content || "";
    
    // Extract code blocks and explanation
    const codeMatch = response.match(/```[\w]*\n([\s\S]*?)\n```/);
    const code = codeMatch ? codeMatch[1] : response;
    const explanation = response.replace(/```[\w]*\n([\s\S]*?)\n```/g, '').trim();

    return {
      code: code.trim(),
      explanation: explanation || "Code generated successfully"
    };
  } catch (error) {
    console.error("Code Generation Error:", error);
    throw new Error("Failed to generate code");
  }
}

// Image analysis using GPT-4 Vision
export async function analyzeImage(
  imageBase64: string,
  question?: string
): Promise<{ analysis: string; details: string[] }> {
  try {
    const prompt = question || "Analyze this image in detail. Describe what you see, identify key elements, and provide relevant insights.";

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`
              }
            }
          ]
        }
      ],
      max_tokens: 1000
    });

    const analysis = completion.choices[0].message.content || "Unable to analyze image";
    
    return {
      analysis,
      details: analysis.split('\n').filter(line => line.trim().length > 0)
    };
  } catch (error) {
    console.error("Image Analysis Error:", error);
    throw new Error("Failed to analyze image");
  }
}

// Whiteboard drawing analysis with educational context
export async function analyzeDrawing(
  imageBase64: string,
  context: string = "educational"
): Promise<{
  content: string;
  confidence: number;
  suggestions: string[];
  relatedConcepts: string[];
}> {
  try {
    const educationalPrompt = `
Analyze this whiteboard drawing from an educational perspective. Provide:

1. A clear explanation of what is drawn and its educational significance
2. Suggestions for improvement or extension of the concept
3. Related educational concepts that could be explored

Context: ${context}

Format your response as JSON:
{
  "content": "detailed analysis and explanation",
  "confidence": 0.95,
  "suggestions": ["suggestion1", "suggestion2", "suggestion3"],
  "relatedConcepts": ["concept1", "concept2", "concept3"]
}
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert educational analyst specializing in interpreting visual content and providing educational insights."
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: educationalPrompt
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/png;base64,${imageBase64}`
              }
            }
          ]
        }
      ],
      temperature: 0.3,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(completion.choices[0].message.content || '{}');
    
    return {
      content: result.content || "Unable to analyze the drawing",
      confidence: result.confidence || 0.5,
      suggestions: result.suggestions || [],
      relatedConcepts: result.relatedConcepts || []
    };
  } catch (error) {
    console.error("Drawing Analysis Error:", error);
    
    // Provide educational fallback analysis when OpenAI is not available
    return {
      content: "This appears to be a whiteboard drawing that could represent various educational concepts. Common elements in educational drawings include diagrams, mathematical equations, scientific illustrations, mind maps, or conceptual frameworks.",
      confidence: 0.7,
      suggestions: [
        "Add labels and annotations to clarify concepts",
        "Use different colors to highlight key elements",
        "Consider adding arrows to show relationships",
        "Include a title or heading for context"
      ],
      relatedConcepts: [
        "Visual Learning",
        "Concept Mapping", 
        "Educational Diagrams",
        "Knowledge Representation"
      ]
    };
  }
}

// Mathematical problem solving
export async function solveMathProblem(problem: string): Promise<{
  solution: string;
  steps: string[];
  explanation: string;
}> {
  try {
    const mathPrompt = `
Solve this mathematical problem step by step: ${problem}

Provide:
1. The final solution
2. Step-by-step breakdown
3. Clear explanation of the method used

Format as JSON:
{
  "solution": "final answer",
  "steps": ["step1", "step2", "step3"],
  "explanation": "detailed explanation"
}
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: 'system',
          content: 'You are a mathematics expert. Solve problems with clear, accurate step-by-step solutions.'
        },
        {
          role: 'user',
          content: mathPrompt
        }
      ],
      temperature: 0.1,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(completion.choices[0].message.content || '{}');
    
    return {
      solution: result.solution || "Unable to solve",
      steps: result.steps || [],
      explanation: result.explanation || "No explanation available"
    };
  } catch (error) {
    console.error("Math Problem Solving Error:", error);
    
    // Return error for API configuration
    throw new Error("Math solving requires OpenAI API key configuration.");
  }
}

// Language translation
export async function translateText(
  text: string,
  targetLanguage: string,
  sourceLanguage?: string
): Promise<{ translation: string; confidence: number }> {
  try {
    const translatePrompt = `
Translate the following text ${sourceLanguage ? `from ${sourceLanguage}` : ''} to ${targetLanguage}:

"${text}"

Provide an accurate, natural translation that preserves the original meaning and tone.
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: 'system',
          content: 'You are a professional translator. Provide accurate, natural translations while preserving meaning and context.'
        },
        {
          role: 'user',
          content: translatePrompt
        }
      ],
      temperature: 0.2
    });

    const translation = completion.choices[0].message.content || "Translation failed";
    
    return {
      translation: translation.trim(),
      confidence: 0.95 // OpenAI generally provides high-quality translations
    };
  } catch (error) {
    console.error("Translation Error:", error);
    throw new Error("Failed to translate text");
  }
}

// Summarization and content analysis
export async function summarizeContent(
  content: string,
  maxLength?: number
): Promise<{ summary: string; keyPoints: string[]; sentiment: string }> {
  try {
    const summaryPrompt = `
Analyze and summarize the following content:

"${content}"

Provide:
1. A concise summary ${maxLength ? `(max ${maxLength} words)` : ''}
2. Key points (bullet format)
3. Overall sentiment (positive/negative/neutral)

Format as JSON:
{
  "summary": "concise summary",
  "keyPoints": ["point1", "point2", "point3"],
  "sentiment": "positive/negative/neutral"
}
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: 'system',
          content: 'You are a content analysis expert. Provide accurate summaries and insights.'
        },
        {
          role: 'user',
          content: summaryPrompt
        }
      ],
      temperature: 0.3,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(completion.choices[0].message.content || '{}');
    
    return {
      summary: result.summary || "No summary available",
      keyPoints: result.keyPoints || [],
      sentiment: result.sentiment || "neutral"
    };
  } catch (error) {
    console.error("Content Analysis Error:", error);
    throw new Error("Failed to analyze content");
  }
}

// Creative content generation
export async function generateCreativeContent(
  prompt: string,
  type: 'story' | 'poem' | 'article' | 'essay' | 'creative',
  length?: 'short' | 'medium' | 'long'
): Promise<{ content: string; title: string; wordCount: number }> {
  try {
    const creativePrompt = `
Create a ${type} based on: ${prompt}
Length: ${length || 'medium'}

Generate engaging, original content with appropriate structure and style.
Include a compelling title.
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: 'system',
          content: `You are a creative writer specializing in ${type}s. Create engaging, original content with excellent narrative structure.`
        },
        {
          role: 'user',
          content: creativePrompt
        }
      ],
      temperature: 0.8,
      max_tokens: length === 'long' ? 3000 : length === 'short' ? 800 : 1500
    });

    const response = completion.choices[0].message.content || "";
    const lines = response.split('\n');
    const title = lines[0].replace(/^(Title:|#\s*)/, '').trim();
    const content = lines.slice(1).join('\n').trim();
    const wordCount = content.split(/\s+/).length;
    
    return {
      content,
      title: title || `Generated ${type}`,
      wordCount
    };
  } catch (error) {
    console.error("Creative Content Generation Error:", error);
    throw new Error("Failed to generate creative content");
  }
}