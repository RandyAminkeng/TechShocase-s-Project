import { db } from "./db";
import { users, subjects, courses, userProgress, userStats, resources } from "../shared/schema";

async function seed() {
  console.log("Seeding database...");

  // Create subjects
  const [mathSubject] = await db.insert(subjects).values({
    name: "Mathematics",
    description: "Learn algebra, calculus, and more",
    icon: "calculate",
    color: "primary"
  }).returning();

  const [scienceSubject] = await db.insert(subjects).values({
    name: "Science",
    description: "Physics, chemistry, and biology",
    icon: "science",
    color: "secondary"
  }).returning();

  const [languageSubject] = await db.insert(subjects).values({
    name: "Languages",
    description: "Learn Spanish, French, and more",
    icon: "language",
    color: "accent"
  }).returning();

  const [historySubject] = await db.insert(subjects).values({
    name: "History",
    description: "World history and civilizations",
    icon: "history_edu",
    color: "info"
  }).returning();

  // Create user
  const [user] = await db.insert(users).values({
    username: "alex",
    password: "password123",
    displayName: "Alex Morgan",
    role: "student"
  }).returning();

  // Create courses
  const [algebraCourse] = await db.insert(courses).values({
    subjectId: mathSubject.id,
    name: "Advanced Algebra",
    description: "Master algebraic concepts and equations",
    totalLessons: 24,
    level: "Intermediate",
    imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb"
  }).returning();

  const [chemistryCourse] = await db.insert(courses).values({
    subjectId: scienceSubject.id,
    name: "Organic Chemistry",
    description: "Study of carbon compounds and reactions",
    totalLessons: 30,
    level: "Advanced",
    imageUrl: "https://images.unsplash.com/photo-1532094349884-543bc11b234d"
  }).returning();

  const [spanishCourse] = await db.insert(courses).values({
    subjectId: languageSubject.id,
    name: "Spanish Intermediate",
    description: "Conversation and grammar for intermediate speakers",
    totalLessons: 20,
    level: "Intermediate",
    imageUrl: "https://images.unsplash.com/photo-1544717297-fa95b6ee9643"
  }).returning();

  // Create user progress
  await db.insert(userProgress).values([
    {
      userId: user.id,
      courseId: algebraCourse.id,
      completedLessons: 8,
      progress: 33.3
    },
    {
      userId: user.id,
      courseId: chemistryCourse.id,
      completedLessons: 12,
      progress: 40.0
    },
    {
      userId: user.id,
      courseId: spanishCourse.id,
      completedLessons: 5,
      progress: 25.0
    }
  ]);

  // Create user stats
  await db.insert(userStats).values({
    userId: user.id,
    learningHours: 12.5,
    completedLessons: 25,
    streak: 7,
    bestStreak: 12,
    quizAverage: 87.5
  });

  // Create resources
  await db.insert(resources).values([
    {
      subjectId: mathSubject.id,
      title: "Algebra Foundations",
      description: "Comprehensive guide to algebraic principles",
      type: "PDF",
      url: "/resources/algebra-foundations.pdf",
      imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb",
      metadata: { pages: 45 }
    },
    {
      subjectId: scienceSubject.id,
      title: "Interactive Periodic Table",
      description: "Explore elements and their properties",
      type: "Interactive",
      url: "/resources/periodic-table",
      imageUrl: "https://images.unsplash.com/photo-1532094349884-543bc11b234d",
      metadata: { elements: 118 }
    },
    {
      subjectId: languageSubject.id,
      title: "Spanish Conversation Practice",
      description: "Practice dialogues with native speakers",
      type: "Audio",
      url: "/resources/spanish-conversations",
      imageUrl: "https://images.unsplash.com/photo-1544717297-fa95b6ee9643",
      metadata: { dialogues: 24, duration: "3h 45m" }
    }
  ]);

  console.log("Database seeded successfully!");
}

seed().catch(console.error);