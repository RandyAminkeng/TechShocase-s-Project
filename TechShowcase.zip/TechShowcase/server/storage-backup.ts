import type {
  User, InsertUser,
  Subject, InsertSubject,
  Course, InsertCourse,
  Lesson, InsertLesson,
  UserProgress, InsertUserProgress,
  UserStats, InsertUserStats,
  Resource, InsertResource,
  AiChatHistory, InsertAiChatHistory,
  MoodEntry, InsertMoodEntry,
  StudySession, InsertStudySession,
  MotivationGoal, InsertMotivationGoal,
  AiMotivationInsight, InsertAiMotivationInsight,
  LearningStreak, InsertLearningStreak
} from "../shared/schema";
import { users, subjects, courses, lessons, userProgress, userStats, resources, aiChatHistory, moodEntries, studySessions, motivationGoals, aiMotivationInsights, learningStreaks } from "../shared/schema";
import { db } from "./db";
import { eq, and, isNull, desc, gte, lte, count, sum, avg } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Subject methods
  getSubjects(): Promise<Subject[]>;
  getSubject(id: number): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  
  // Course methods
  getCourses(): Promise<Course[]>;
  getCoursesBySubject(subjectId: number): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Lesson methods
  getLessonsByCourse(courseId: number): Promise<Lesson[]>;
  getLesson(id: number): Promise<Lesson | undefined>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  
  // UserProgress methods
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getUserProgressByCourse(userId: number, courseId: number): Promise<UserProgress | undefined>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: number, progress: Partial<UserProgress>): Promise<UserProgress>;
  
  // UserStats methods
  getUserStats(userId: number): Promise<UserStats | undefined>;
  createUserStats(stats: InsertUserStats): Promise<UserStats>;
  updateUserStats(userId: number, stats: Partial<UserStats>): Promise<UserStats>;
  
  // Resource methods
  getResources(): Promise<Resource[]>;
  getResourcesBySubject(subjectId: number): Promise<Resource[]>;
  getResource(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  
  // AiChatHistory methods
  getChatHistory(userId: number): Promise<AiChatHistory[]>;
  getChatHistoryBySubject(userId: number, subjectId: number): Promise<AiChatHistory[]>;
  createChatHistory(entry: InsertAiChatHistory): Promise<AiChatHistory>;
  
  // Mood and Motivation Tracking methods
  getMoodEntries(userId: number): Promise<MoodEntry[]>;
  getMoodEntriesByDateRange(userId: number, startDate: Date, endDate: Date): Promise<MoodEntry[]>;
  createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry>;
  
  getStudySessions(userId: number): Promise<StudySession[]>;
  getActiveStudySession(userId: number): Promise<StudySession | undefined>;
  createStudySession(session: InsertStudySession): Promise<StudySession>;
  updateStudySession(id: number, session: Partial<StudySession>): Promise<StudySession>;
  
  getMotivationGoals(userId: number): Promise<MotivationGoal[]>;
  getActiveMotivationGoals(userId: number): Promise<MotivationGoal[]>;
  createMotivationGoal(goal: InsertMotivationGoal): Promise<MotivationGoal>;
  updateMotivationGoal(id: number, goal: Partial<MotivationGoal>): Promise<MotivationGoal>;
  
  getAiMotivationInsights(userId: number): Promise<AiMotivationInsight[]>;
  getUnreadAiInsights(userId: number): Promise<AiMotivationInsight[]>;
  createAiMotivationInsight(insight: InsertAiMotivationInsight): Promise<AiMotivationInsight>;
  updateAiInsightRead(id: number, isRead: boolean): Promise<AiMotivationInsight>;
  
  getLearningStreak(userId: number): Promise<LearningStreak | undefined>;
  createLearningStreak(streak: InsertLearningStreak): Promise<LearningStreak>;
  updateLearningStreak(userId: number, streak: Partial<LearningStreak>): Promise<LearningStreak>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private subjects: Map<number, Subject>;
  private courses: Map<number, Course>;
  private lessons: Map<number, Lesson>;
  private userProgress: Map<number, UserProgress>;
  private userStats: Map<number, UserStats>;
  private resources: Map<number, Resource>;
  private aiChatHistory: Map<number, AiChatHistory>;
  private moodEntries: Map<number, MoodEntry>;
  private studySessions: Map<number, StudySession>;
  private motivationGoals: Map<number, MotivationGoal>;
  private aiMotivationInsights: Map<number, AiMotivationInsight>;
  private learningStreaks: Map<number, LearningStreak>;

  private userIdCounter: number;
  private subjectIdCounter: number;
  private courseIdCounter: number;
  private lessonIdCounter: number;
  private userProgressIdCounter: number;
  private userStatsIdCounter: number;
  private resourceIdCounter: number;
  private aiChatHistoryIdCounter: number;
  private moodEntryIdCounter: number;
  private studySessionIdCounter: number;
  private motivationGoalIdCounter: number;
  private aiMotivationInsightIdCounter: number;
  private learningStreakIdCounter: number;

  constructor() {
    this.users = new Map();
    this.subjects = new Map();
    this.courses = new Map();
    this.lessons = new Map();
    this.userProgress = new Map();
    this.userStats = new Map();
    this.resources = new Map();
    this.aiChatHistory = new Map();
    this.moodEntries = new Map();
    this.studySessions = new Map();
    this.motivationGoals = new Map();
    this.aiMotivationInsights = new Map();
    this.learningStreaks = new Map();
    
    this.userIdCounter = 1;
    this.subjectIdCounter = 1;
    this.courseIdCounter = 1;
    this.lessonIdCounter = 1;
    this.userProgressIdCounter = 1;
    this.userStatsIdCounter = 1;
    this.resourceIdCounter = 1;
    this.aiChatHistoryIdCounter = 1;
    this.moodEntryIdCounter = 1;
    this.studySessionIdCounter = 1;
    this.motivationGoalIdCounter = 1;
    this.aiMotivationInsightIdCounter = 1;
    this.learningStreakIdCounter = 1;

    this.initializeData();
  }

  private initializeData() {
    // Create subjects
    const mathSubject: Subject = {
      id: this.subjectIdCounter++,
      name: "Mathematics",
      description: "Learn algebra, calculus, and more",
      icon: "calculate",
      color: "primary"
    };
    this.subjects.set(mathSubject.id, mathSubject);

    const scienceSubject: Subject = {
      id: this.subjectIdCounter++,
      name: "Science",
      description: "Physics, chemistry, and biology",
      icon: "science",
      color: "secondary"
    };
    this.subjects.set(scienceSubject.id, scienceSubject);

    const languageSubject: Subject = {
      id: this.subjectIdCounter++,
      name: "Languages",
      description: "Learn Spanish, French, and more",
      icon: "language",
      color: "accent"
    };
    this.subjects.set(languageSubject.id, languageSubject);

    const historySubject: Subject = {
      id: this.subjectIdCounter++,
      name: "History",
      description: "World history and civilizations",
      icon: "history_edu",
      color: "info"
    };
    this.subjects.set(historySubject.id, historySubject);

    // Create user
    const user: User = {
      id: this.userIdCounter++,
      username: "alex",
      password: "password123",
      displayName: "Alex Morgan",
      email: "alex@example.com",
      bio: "Learning enthusiast exploring new subjects",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      role: "student",
      createdAt: new Date()
    };
    this.users.set(user.id, user);

    // Create courses
    const algebraCourse: Course = {
      id: this.courseIdCounter++,
      subjectId: mathSubject.id,
      name: "Advanced Algebra",
      description: "Master algebraic concepts and equations",
      totalLessons: 24,
      level: "Intermediate",
      imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb"
    };
    this.courses.set(algebraCourse.id, algebraCourse);

    const chemistryCourse: Course = {
      id: this.courseIdCounter++,
      subjectId: scienceSubject.id,
      name: "Organic Chemistry",
      description: "Study of carbon compounds and reactions",
      totalLessons: 30,
      level: "Advanced",
      imageUrl: "https://images.unsplash.com/photo-1532094349884-543bc11b234d"
    };
    this.courses.set(chemistryCourse.id, chemistryCourse);

    const spanishCourse: Course = {
      id: this.courseIdCounter++,
      subjectId: languageSubject.id,
      name: "Spanish Intermediate",
      description: "Conversation and grammar for intermediate speakers",
      totalLessons: 20,
      level: "Intermediate",
      imageUrl: "https://images.unsplash.com/photo-1544717297-fa95b6ee9643"
    };
    this.courses.set(spanishCourse.id, spanishCourse);

    // Create user progress
    const progress1: UserProgress = {
      id: this.userProgressIdCounter++,
      userId: user.id,
      courseId: algebraCourse.id,
      completedLessons: 8,
      progress: 33.3,
      lastActivity: new Date()
    };
    this.userProgress.set(progress1.id, progress1);

    const progress2: UserProgress = {
      id: this.userProgressIdCounter++,
      userId: user.id,
      courseId: chemistryCourse.id,
      completedLessons: 12,
      progress: 40.0,
      lastActivity: new Date()
    };
    this.userProgress.set(progress2.id, progress2);

    const progress3: UserProgress = {
      id: this.userProgressIdCounter++,
      userId: user.id,
      courseId: spanishCourse.id,
      completedLessons: 5,
      progress: 25.0,
      lastActivity: new Date()
    };
    this.userProgress.set(progress3.id, progress3);

    // Create user stats
    const userStats: UserStats = {
      id: this.userStatsIdCounter++,
      userId: user.id,
      learningHours: 12.5,
      completedLessons: 25,
      streak: 7,
      bestStreak: 12,
      quizAverage: 87.5
    };
    this.userStats.set(userStats.id, userStats);

    // Create resources
    const resource1: Resource = {
      id: this.resourceIdCounter++,
      subjectId: mathSubject.id,
      title: "Algebra Foundations",
      description: "Comprehensive guide to algebraic principles",
      type: "PDF",
      url: "/resources/algebra-foundations.pdf",
      imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb",
      metadata: { pages: 45 }
    };
    this.resources.set(resource1.id, resource1);

    const resource2: Resource = {
      id: this.resourceIdCounter++,
      subjectId: scienceSubject.id,
      title: "Interactive Periodic Table",
      description: "Explore elements and their properties",
      type: "Interactive",
      url: "/resources/periodic-table",
      imageUrl: "https://images.unsplash.com/photo-1532094349884-543bc11b234d",
      metadata: { elements: 118 }
    };
    this.resources.set(resource2.id, resource2);

    const resource3: Resource = {
      id: this.resourceIdCounter++,
      subjectId: languageSubject.id,
      title: "Spanish Conversation Practice",
      description: "Practice dialogues with native speakers",
      type: "Audio",
      url: "/resources/spanish-conversations",
      imageUrl: "https://images.unsplash.com/photo-1544717297-fa95b6ee9643",
      metadata: { dialogues: 24, duration: "3h 45m" }
    };
    this.resources.set(resource3.id, resource3);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const newUser: User = { 
      id, 
      createdAt, 
      username: user.username,
      password: user.password,
      displayName: user.displayName,
      email: user.email || null,
      bio: user.bio || null,
      avatar: user.avatar || null,
      role: user.role || "student"
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) {
      return undefined;
    }
    
    const updatedUser: User = {
      ...user,
      ...updates,
      id, // Ensure ID is not changed
      createdAt: user.createdAt // Preserve creation date
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Subject methods
  async getSubjects(): Promise<Subject[]> {
    return Array.from(this.subjects.values());
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    return this.subjects.get(id);
  }

  async createSubject(subject: InsertSubject): Promise<Subject> {
    const id = this.subjectIdCounter++;
    const newSubject: Subject = { 
      id, 
      name: subject.name,
      description: subject.description,
      icon: subject.icon,
      color: subject.color || "primary"
    };
    this.subjects.set(id, newSubject);
    return newSubject;
  }

  // Course methods
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCoursesBySubject(subjectId: number): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      course => course.subjectId === subjectId
    );
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const id = this.courseIdCounter++;
    const newCourse: Course = { 
      id, 
      name: course.name,
      description: course.description,
      totalLessons: course.totalLessons,
      level: course.level,
      subjectId: course.subjectId || null,
      imageUrl: course.imageUrl || null
    };
    this.courses.set(id, newCourse);
    return newCourse;
  }

  // Lesson methods
  async getLessonsByCourse(courseId: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter(lesson => lesson.courseId === courseId)
      .sort((a, b) => a.order - b.order);
  }

  async getLesson(id: number): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async createLesson(lesson: InsertLesson): Promise<Lesson> {
    const id = this.lessonIdCounter++;
    const newLesson: Lesson = { 
      id, 
      title: lesson.title,
      content: lesson.content,
      order: lesson.order,
      courseId: lesson.courseId || null
    };
    this.lessons.set(id, newLesson);
    return newLesson;
  }

  // UserProgress methods
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(
      progress => progress.userId === userId
    );
  }

  async getUserProgressByCourse(userId: number, courseId: number): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values()).find(
      progress => progress.userId === userId && progress.courseId === courseId
    );
  }

  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const id = this.userProgressIdCounter++;
    const lastActivity = new Date();
    const newProgress: UserProgress = { 
      id, 
      lastActivity,
      userId: progress.userId || null,
      courseId: progress.courseId || null,
      completedLessons: progress.completedLessons || 0,
      progress: progress.progress || 0
    };
    this.userProgress.set(id, newProgress);
    return newProgress;
  }

  async updateUserProgress(id: number, progress: Partial<UserProgress>): Promise<UserProgress> {
    const currentProgress = this.userProgress.get(id);
    if (!currentProgress) {
      throw new Error("Progress not found");
    }
    const updatedProgress: UserProgress = { 
      ...currentProgress, 
      ...progress,
      lastActivity: new Date()
    };
    this.userProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  // UserStats methods
  async getUserStats(userId: number): Promise<UserStats | undefined> {
    return Array.from(this.userStats.values()).find(
      stats => stats.userId === userId
    );
  }

  async createUserStats(stats: InsertUserStats): Promise<UserStats> {
    const id = this.userStatsIdCounter++;
    const newStats: UserStats = { 
      id,
      userId: stats.userId || null,
      completedLessons: stats.completedLessons || 0,
      learningHours: stats.learningHours || 0,
      streak: stats.streak || 0,
      bestStreak: stats.bestStreak || 0,
      quizAverage: stats.quizAverage || 0
    };
    this.userStats.set(id, newStats);
    return newStats;
  }

  async updateUserStats(userId: number, stats: Partial<UserStats>): Promise<UserStats> {
    const currentStats = Array.from(this.userStats.values()).find(
      s => s.userId === userId
    );
    if (!currentStats) {
      throw new Error("User stats not found");
    }
    const updatedStats: UserStats = { ...currentStats, ...stats };
    this.userStats.set(currentStats.id, updatedStats);
    return updatedStats;
  }

  // Resource methods
  async getResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }

  async getResourcesBySubject(subjectId: number): Promise<Resource[]> {
    return Array.from(this.resources.values()).filter(
      resource => resource.subjectId === subjectId
    );
  }

  async getResource(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const newResource: Resource = { 
      id,
      type: resource.type,
      description: resource.description,
      title: resource.title,
      url: resource.url,
      subjectId: resource.subjectId || null,
      imageUrl: resource.imageUrl || null,
      metadata: resource.metadata || null
    };
    this.resources.set(id, newResource);
    return newResource;
  }

  // AiChatHistory methods
  async getChatHistory(userId: number): Promise<AiChatHistory[]> {
    return Array.from(this.aiChatHistory.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async getChatHistoryBySubject(userId: number, subjectId: number): Promise<AiChatHistory[]> {
    return Array.from(this.aiChatHistory.values())
      .filter(entry => entry.userId === userId && entry.subjectId === subjectId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createChatHistory(entry: InsertAiChatHistory): Promise<AiChatHistory> {
    const id = this.aiChatHistoryIdCounter++;
    const timestamp = new Date();
    const newEntry: AiChatHistory = { 
      id, 
      timestamp,
      message: entry.message,
      response: entry.response,
      subjectId: entry.subjectId || null,
      userId: entry.userId || null
    };
    this.aiChatHistory.set(id, newEntry);
    return newEntry;
  }

  // Mood and Motivation Tracking methods
  async getMoodEntries(userId: number): Promise<MoodEntry[]> {
    return Array.from(this.moodEntries.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  async getMoodEntriesByDateRange(userId: number, startDate: Date, endDate: Date): Promise<MoodEntry[]> {
    return Array.from(this.moodEntries.values())
      .filter(entry => 
        entry.userId === userId && 
        entry.date >= startDate && 
        entry.date <= endDate
      )
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }

  async createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry> {
    const id = this.moodEntryIdCounter++;
    const date = new Date();
    const newEntry: MoodEntry = {
      id,
      date,
      userId: entry.userId,
      moodScore: entry.moodScore,
      energyLevel: entry.energyLevel,
      motivationLevel: entry.motivationLevel,
      stressLevel: entry.stressLevel,
      notes: entry.notes || null,
      tags: (entry.tags || []) as string[],
      studySessionId: entry.studySessionId || null
    };
    this.moodEntries.set(id, newEntry);
    return newEntry;
  }

  async getStudySessions(userId: number): Promise<StudySession[]> {
    return Array.from(this.studySessions.values())
      .filter(session => session.userId === userId)
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
  }

  async getActiveStudySession(userId: number): Promise<StudySession | undefined> {
    return Array.from(this.studySessions.values())
      .find(session => session.userId === userId && !session.endTime);
  }

  async createStudySession(session: InsertStudySession): Promise<StudySession> {
    const id = this.studySessionIdCounter++;
    const newSession: StudySession = {
      id,
      userId: session.userId,
      subjectId: session.subjectId || null,
      duration: session.duration,
      completedTasks: session.completedTasks || 0,
      plannedTasks: session.plannedTasks || 0,
      focusScore: session.focusScore || null,
      productivityScore: session.productivityScore || null,
      startTime: session.startTime,
      endTime: session.endTime || null,
      breaks: (session.breaks || []) as {start: string, end: string, type: string}[],
      notes: session.notes || null
    };
    this.studySessions.set(id, newSession);
    return newSession;
  }

  async updateStudySession(id: number, session: Partial<StudySession>): Promise<StudySession> {
    const currentSession = this.studySessions.get(id);
    if (!currentSession) {
      throw new Error("Study session not found");
    }
    const updatedSession: StudySession = { ...currentSession, ...session };
    this.studySessions.set(id, updatedSession);
    return updatedSession;
  }

  async getMotivationGoals(userId: number): Promise<MotivationGoal[]> {
    return Array.from(this.motivationGoals.values())
      .filter(goal => goal.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getActiveMotivationGoals(userId: number): Promise<MotivationGoal[]> {
    return Array.from(this.motivationGoals.values())
      .filter(goal => goal.userId === userId && !goal.isCompleted)
      .sort((a, b) => a.priority === 'high' ? -1 : b.priority === 'high' ? 1 : 0);
  }

  async createMotivationGoal(goal: InsertMotivationGoal): Promise<MotivationGoal> {
    const id = this.motivationGoalIdCounter++;
    const createdAt = new Date();
    const newGoal: MotivationGoal = {
      id,
      createdAt,
      userId: goal.userId,
      title: goal.title,
      description: goal.description || null,
      targetValue: goal.targetValue,
      currentValue: goal.currentValue || 0,
      unit: goal.unit,
      category: goal.category,
      deadline: goal.deadline || null,
      isCompleted: goal.isCompleted || false,
      priority: goal.priority || "medium",
      completedAt: null
    };
    this.motivationGoals.set(id, newGoal);
    return newGoal;
  }

  async updateMotivationGoal(id: number, goal: Partial<MotivationGoal>): Promise<MotivationGoal> {
    const currentGoal = this.motivationGoals.get(id);
    if (!currentGoal) {
      throw new Error("Motivation goal not found");
    }
    const updatedGoal: MotivationGoal = { ...currentGoal, ...goal };
    this.motivationGoals.set(id, updatedGoal);
    return updatedGoal;
  }

  async getAiMotivationInsights(userId: number): Promise<AiMotivationInsight[]> {
    return Array.from(this.aiMotivationInsights.values())
      .filter(insight => insight.userId === userId)
      .sort((a, b) => b.generatedAt.getTime() - a.generatedAt.getTime());
  }

  async getUnreadAiInsights(userId: number): Promise<AiMotivationInsight[]> {
    return Array.from(this.aiMotivationInsights.values())
      .filter(insight => insight.userId === userId && !insight.isRead)
      .sort((a, b) => b.generatedAt.getTime() - a.generatedAt.getTime());
  }

  async createAiMotivationInsight(insight: InsertAiMotivationInsight): Promise<AiMotivationInsight> {
    const id = this.aiMotivationInsightIdCounter++;
    const generatedAt = new Date();
    const newInsight: AiMotivationInsight = {
      id,
      generatedAt,
      userId: insight.userId,
      insightType: insight.insightType,
      content: insight.content,
      recommendations: (insight.recommendations || []) as string[],
      confidence: insight.confidence,
      isRead: insight.isRead || false,
      isHelpful: insight.isHelpful || null,
      expiresAt: insight.expiresAt || null
    };
    this.aiMotivationInsights.set(id, newInsight);
    return newInsight;
  }

  async updateAiInsightRead(id: number, isRead: boolean): Promise<AiMotivationInsight> {
    const insight = this.aiMotivationInsights.get(id);
    if (!insight) {
      throw new Error("AI motivation insight not found");
    }
    const updatedInsight: AiMotivationInsight = { ...insight, isRead };
    this.aiMotivationInsights.set(id, updatedInsight);
    return updatedInsight;
  }

  async getLearningStreak(userId: number): Promise<LearningStreak | undefined> {
    return Array.from(this.learningStreaks.values())
      .find(streak => streak.userId === userId);
  }

  async createLearningStreak(streak: InsertLearningStreak): Promise<LearningStreak> {
    const id = this.learningStreakIdCounter++;
    const newStreak: LearningStreak = {
      id,
      userId: streak.userId,
      currentStreak: streak.currentStreak || 0,
      longestStreak: streak.longestStreak || 0,
      lastStudyDate: streak.lastStudyDate || null,
      streakType: streak.streakType || "daily",
      streakStartDate: streak.streakStartDate || null
    };
    this.learningStreaks.set(id, newStreak);
    return newStreak;
  }

  async updateLearningStreak(userId: number, streak: Partial<LearningStreak>): Promise<LearningStreak> {
    const currentStreak = Array.from(this.learningStreaks.values())
      .find(s => s.userId === userId);
    if (!currentStreak) {
      throw new Error("Learning streak not found");
    }
    const updatedStreak: LearningStreak = { ...currentStreak, ...streak };
    this.learningStreaks.set(currentStreak.id, updatedStreak);
    return updatedStreak;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }

  async getSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject || undefined;
  }

  async createSubject(insertSubject: InsertSubject): Promise<Subject> {
    const [subject] = await db
      .insert(subjects)
      .values(insertSubject)
      .returning();
    return subject;
  }

  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCoursesBySubject(subjectId: number): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.subjectId, subjectId));
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course || undefined;
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db
      .insert(courses)
      .values(insertCourse)
      .returning();
    return course;
  }

  async getLessonsByCourse(courseId: number): Promise<Lesson[]> {
    return await db.select().from(lessons).where(eq(lessons.courseId, courseId));
  }

  async getLesson(id: number): Promise<Lesson | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson || undefined;
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const [lesson] = await db
      .insert(lessons)
      .values(insertLesson)
      .returning();
    return lesson;
  }

  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getUserProgressByCourse(userId: number, courseId: number): Promise<UserProgress | undefined> {
    const [progress] = await db.select().from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.courseId, courseId)));
    return progress || undefined;
  }

  async createUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const [progress] = await db
      .insert(userProgress)
      .values(insertProgress)
      .returning();
    return progress;
  }

  async updateUserProgress(id: number, updateProgress: Partial<UserProgress>): Promise<UserProgress> {
    const [progress] = await db
      .update(userProgress)
      .set(updateProgress)
      .where(eq(userProgress.id, id))
      .returning();
    return progress;
  }

  async getUserStats(userId: number): Promise<UserStats | undefined> {
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    return stats || undefined;
  }

  async createUserStats(insertStats: InsertUserStats): Promise<UserStats> {
    const [stats] = await db
      .insert(userStats)
      .values(insertStats)
      .returning();
    return stats;
  }

  async updateUserStats(userId: number, updateStats: Partial<UserStats>): Promise<UserStats> {
    const [stats] = await db
      .update(userStats)
      .set(updateStats)
      .where(eq(userStats.userId, userId))
      .returning();
    return stats;
  }

  async getResources(): Promise<Resource[]> {
    return await db.select().from(resources);
  }

  async getResourcesBySubject(subjectId: number): Promise<Resource[]> {
    return await db.select().from(resources).where(eq(resources.subjectId, subjectId));
  }

  async getResource(id: number): Promise<Resource | undefined> {
    const [resource] = await db.select().from(resources).where(eq(resources.id, id));
    return resource || undefined;
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const [resource] = await db
      .insert(resources)
      .values(insertResource)
      .returning();
    return resource;
  }

  async getChatHistory(userId: number): Promise<AiChatHistory[]> {
    return await db.select().from(aiChatHistory).where(eq(aiChatHistory.userId, userId));
  }

  async getChatHistoryBySubject(userId: number, subjectId: number): Promise<AiChatHistory[]> {
    return await db.select().from(aiChatHistory)
      .where(and(eq(aiChatHistory.userId, userId), eq(aiChatHistory.subjectId, subjectId)));
  }

  async createChatHistory(insertEntry: InsertAiChatHistory): Promise<AiChatHistory> {
    const [entry] = await db
      .insert(aiChatHistory)
      .values(insertEntry)
      .returning();
    return entry;
  }

  // Mood and Motivation Tracking methods
  async getMoodEntries(userId: number): Promise<MoodEntry[]> {
    return await db.select().from(moodEntries).where(eq(moodEntries.userId, userId));
  }

  async getMoodEntriesByDateRange(userId: number, startDate: Date, endDate: Date): Promise<MoodEntry[]> {
    return await db.select().from(moodEntries)
      .where(and(
        eq(moodEntries.userId, userId),
        and(
          eq(moodEntries.date, startDate),
          eq(moodEntries.date, endDate)
        )
      ));
  }

  async createMoodEntry(insertEntry: InsertMoodEntry): Promise<MoodEntry> {
    const entryData = {
      userId: insertEntry.userId,
      moodScore: insertEntry.moodScore,
      energyLevel: insertEntry.energyLevel,
      motivationLevel: insertEntry.motivationLevel,
      stressLevel: insertEntry.stressLevel,
      notes: insertEntry.notes,
      tags: insertEntry.tags || null,
      studySessionId: insertEntry.studySessionId
    };
    const [entry] = await db
      .insert(moodEntries)
      .values(entryData)
      .returning();
    return entry;
  }

  async getStudySessions(userId: number): Promise<StudySession[]> {
    return await db.select().from(studySessions).where(eq(studySessions.userId, userId));
  }

  async getActiveStudySession(userId: number): Promise<StudySession | undefined> {
    const [session] = await db.select().from(studySessions)
      .where(and(eq(studySessions.userId, userId), isNull(studySessions.endTime)));
    return session || undefined;
  }

  async createStudySession(insertSession: InsertStudySession): Promise<StudySession> {
    const [session] = await db
      .insert(studySessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async updateStudySession(id: number, updateSession: Partial<StudySession>): Promise<StudySession> {
    const [session] = await db
      .update(studySessions)
      .set(updateSession)
      .where(eq(studySessions.id, id))
      .returning();
    return session;
  }

  async getMotivationGoals(userId: number): Promise<MotivationGoal[]> {
    return await db.select().from(motivationGoals).where(eq(motivationGoals.userId, userId));
  }

  async getActiveMotivationGoals(userId: number): Promise<MotivationGoal[]> {
    return await db.select().from(motivationGoals)
      .where(and(eq(motivationGoals.userId, userId), eq(motivationGoals.isCompleted, false)));
  }

  async createMotivationGoal(insertGoal: InsertMotivationGoal): Promise<MotivationGoal> {
    const [goal] = await db
      .insert(motivationGoals)
      .values(insertGoal)
      .returning();
    return goal;
  }

  async updateMotivationGoal(id: number, updateGoal: Partial<MotivationGoal>): Promise<MotivationGoal> {
    const [goal] = await db
      .update(motivationGoals)
      .set(updateGoal)
      .where(eq(motivationGoals.id, id))
      .returning();
    return goal;
  }

  async getAiMotivationInsights(userId: number): Promise<AiMotivationInsight[]> {
    return await db.select().from(aiMotivationInsights).where(eq(aiMotivationInsights.userId, userId));
  }

  async getUnreadAiInsights(userId: number): Promise<AiMotivationInsight[]> {
    return await db.select().from(aiMotivationInsights)
      .where(and(eq(aiMotivationInsights.userId, userId), eq(aiMotivationInsights.isRead, false)));
  }

  async createAiMotivationInsight(insertInsight: InsertAiMotivationInsight): Promise<AiMotivationInsight> {
    const [insight] = await db
      .insert(aiMotivationInsights)
      .values(insertInsight)
      .returning();
    return insight;
  }

  async updateAiInsightRead(id: number, isRead: boolean): Promise<AiMotivationInsight> {
    const [insight] = await db
      .update(aiMotivationInsights)
      .set({ isRead })
      .where(eq(aiMotivationInsights.id, id))
      .returning();
    return insight;
  }

  async getLearningStreak(userId: number): Promise<LearningStreak | undefined> {
    const [streak] = await db.select().from(learningStreaks).where(eq(learningStreaks.userId, userId));
    return streak || undefined;
  }

  async createLearningStreak(insertStreak: InsertLearningStreak): Promise<LearningStreak> {
    const [streak] = await db
      .insert(learningStreaks)
      .values(insertStreak)
      .returning();
    return streak;
  }

  async updateLearningStreak(userId: number, updateStreak: Partial<LearningStreak>): Promise<LearningStreak> {
    const [streak] = await db
      .update(learningStreaks)
      .set(updateStreak)
      .where(eq(learningStreaks.userId, userId))
      .returning();
    return streak;
  }
}

export const storage = new DatabaseStorage();