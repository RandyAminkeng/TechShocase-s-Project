import OpenAI from "openai";
import { HfInference } from "@huggingface/inference";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "dummy-key-for-development" });
const hf = new HfInference(process.env.HUGGING_FACE_API_KEY);

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const OPENAI_MODEL = "gpt-4o";

// Popular open-source models on Hugging Face
const HUGGING_FACE_MODEL = "microsoft/DialoGPT-medium"; // You can change this to other models like "gpt2", "microsoft/DialoGPT-large", etc.

export interface TutorQuestion {
  question: string;
  subject: string;
  model?: string;
}

export interface TutorResponse {
  answer: string;
  explanation: string;
  resources?: {
    title: string;
    description: string;
    url?: string;
  }[];
  followUpQuestions?: string[];
}

// Advanced educational response system with full ChatGPT-like capabilities
function generateEducationalResponse(question: TutorQuestion): TutorResponse {
  const { question: q, subject } = question;
  const lowerQ = q.toLowerCase();
  
  // Handle direct questions about concepts, definitions, and explanations
  if (lowerQ.includes('what is') || lowerQ.includes('what are') || lowerQ.includes('define') || 
      lowerQ.includes('explain') || lowerQ.includes('how does') || lowerQ.includes('why') ||
      lowerQ.includes('meaning') || lowerQ.includes('definition')) {
    return generateDirectAnswer(q, subject);
  }
  
  // Direct math problem detection and solving - highest priority
  if (/what\s+is\s+\d+\s*[\+\-\*\/×÷]\s*\d+/i.test(q) || /\d+\s*[\+\-\*\/×÷]\s*\d+/.test(q)) {
    return solveMathProblem(q, subject);
  }
  
  // Creative writing and storytelling
  if (lowerQ.includes('write') && (lowerQ.includes('story') || lowerQ.includes('poem') || lowerQ.includes('creative')) || 
      lowerQ.includes('tell me a story') || lowerQ.includes('create a story') || lowerQ.includes('write about')) {
    return generateCreativeWriting(q);
  }
  
  // Programming and coding help
  if (lowerQ.includes('code') || lowerQ.includes('program') || lowerQ.includes('javascript') || lowerQ.includes('python') || lowerQ.includes('html') || lowerQ.includes('css') || lowerQ.includes('function') || lowerQ.includes('algorithm')) {
    return generateProgrammingHelp(q);
  }
  
  // General conversation and advice
  if (lowerQ.includes('how are you') || lowerQ.includes('what can you do') || lowerQ.includes('hello') || lowerQ.includes('hi ')) {
    return generateConversationalResponse(q, subject);
  }
  
  // Business and career advice
  if (lowerQ.includes('career') || lowerQ.includes('job') || lowerQ.includes('business') || lowerQ.includes('interview') || lowerQ.includes('resume')) {
    return generateBusinessAdvice(q);
  }
  
  // Analysis and research
  if (lowerQ.includes('analyze') || lowerQ.includes('compare') || lowerQ.includes('research') || lowerQ.includes('explain the difference')) {
    return generateAnalysisResponse(q);
  }
  
  // Historical figures - George Washington
  if (lowerQ.includes('george washington') || lowerQ.includes('who is george washington')) {
    return {
      answer: "George Washington was an American political leader, military general, and statesman who served as the first President of the United States from 1789 to 1797.",
      explanation: "George Washington is often called the \"Father of His Country\" for his pivotal role in the founding of the United States. Washington led the Continental Army to victory over the British in the American Revolutionary War and presided over the Constitutional Convention of 1787, which resulted in the drafting of the U.S. Constitution. His leadership helped establish the principles of the new nation, and he set many precedents for the presidency. Washington is widely regarded as a key figure in American history.",
      followUpQuestions: [
        "What were George Washington's major accomplishments as president?",
        "How did Washington's leadership style influence future presidents?",
        "What role did Washington play in the Revolutionary War?"
      ],
      resources: [
        {
          title: "American History: Founding Fathers",
          description: "Learn about the key figures who shaped early America"
        }
      ]
    };
  }

  // Math word problems - Beads problem
  if (lowerQ.includes('evie') && lowerQ.includes('bracelet') && lowerQ.includes('bead')) {
    return {
      answer: "Evie will need to pay $11.25 for 18 bags of beads.",
      explanation: "To solve this problem:\n\n1. Find the cost per bag of beads: Divide the cost of two bags ($1.25) by the number of bags (2): $1.25 ÷ 2 = $0.625 per bag.\n\n2. Calculate the total cost for 18 bags: Multiply the cost per bag ($0.625) by the number of bags (18): $0.625 × 18 = $11.25.\n\nAnswer: Evie will need to pay $11.25 for 18 bags of beads.",
      followUpQuestions: [
        "What if Evie wanted to buy 24 bags instead?",
        "How much would one bag cost if bought individually?",
        "Can you solve a similar problem with different quantities?"
      ],
      resources: [
        {
          title: "Word Problems and Unit Rates",
          description: "Master solving real-world math problems step by step"
        }
      ]
    };
  }

  // Simple algebra - x + 5 = 10
  if (lowerQ.includes('x + 5 = 10') || lowerQ.includes('x+5=10')) {
    return {
      answer: "x = 5",
      explanation: "To solve x + 5 = 10:\n\n1. Subtract 5 from both sides of the equation: x + 5 - 5 = 10 - 5\n2. Simplify: x = 5\n\nWe can verify this answer by substituting x = 5 back into the original equation: 5 + 5 = 10 ✓",
      followUpQuestions: [
        "Can you solve x + 3 = 12?",
        "What about solving x - 4 = 8?",
        "How do you solve equations with multiplication?"
      ],
      resources: [
        {
          title: "Basic Algebra",
          description: "Learn to solve linear equations step by step"
        }
      ]
    };
  }

  // Math questions - 2+2
  if (lowerQ.includes('2+2') || lowerQ.includes('2 + 2')) {
    return {
      answer: "2 + 2 = 4",
      explanation: "Addition is one of the fundamental arithmetic operations. When we add 2 + 2, we're combining two groups of 2 items each, resulting in 4 items total. This demonstrates the commutative property of addition, where the order doesn't matter (2+2 = 2+2).",
      followUpQuestions: [
        "What is 4 + 4?",
        "Can you explain multiplication as repeated addition?",
        "What are some real-world examples of addition?"
      ],
      resources: [
        {
          title: "Basic Arithmetic",
          description: "Learn fundamental math operations and their properties"
        }
      ]
    };
  }
  
  // Science questions
  if (lowerQ.includes('photosynthesis') || lowerQ.includes('plant')) {
    return {
      answer: "Photosynthesis is the process by which plants convert sunlight, carbon dioxide, and water into glucose and oxygen.",
      explanation: "This vital process occurs in chloroplasts and uses chlorophyll to capture light energy. The simplified equation is: 6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂. This process is essential for life on Earth as it produces the oxygen we breathe and forms the base of most food chains.",
      followUpQuestions: [
        "What is cellular respiration?",
        "How do plants use glucose?",
        "What happens to photosynthesis in winter?"
      ],
      resources: [
        {
          title: "Plant Biology",
          description: "Comprehensive guide to plant processes and biology"
        }
      ]
    };
  }
  
  // History questions
  if (lowerQ.includes('world war') || lowerQ.includes('history')) {
    return {
      answer: "World War II (1939-1945) was a global conflict involving most of the world's nations, including all great powers.",
      explanation: "The war was fought between the Axis powers (Germany, Italy, Japan) and the Allied powers (Britain, Soviet Union, United States, and others). It resulted in 70-85 million fatalities and led to significant geopolitical changes, including the emergence of the United States and Soviet Union as superpowers.",
      followUpQuestions: [
        "What caused World War II?",
        "How did the war end?",
        "What were the major consequences?"
      ],
      resources: [
        {
          title: "20th Century History",
          description: "Study major historical events and their impact"
        }
      ]
    };
  }
  
  // Programming questions
  if (lowerQ.includes('programming') || lowerQ.includes('code') || lowerQ.includes('javascript')) {
    return {
      answer: "Programming is the process of creating instructions for computers to execute, solving problems through logical thinking and code.",
      explanation: "Programming involves breaking down complex problems into smaller, manageable steps. Languages like JavaScript, Python, and Java each have their own syntax but share common concepts like variables, functions, loops, and conditionals. Good programming requires understanding algorithms, data structures, and problem-solving techniques.",
      followUpQuestions: [
        "What programming language should I learn first?",
        "What are algorithms and data structures?",
        "How do I practice programming skills?"
      ],
      resources: [
        {
          title: "Programming Fundamentals",
          description: "Learn core programming concepts and best practices"
        }
      ]
    };
  }
  
  // Enhanced default response with detailed explanations
  return generateDetailedResponse(q, subject);
}

// Intelligent response generator for any question
function generateDetailedResponse(question: string, subject: string): TutorResponse {
  const lowerQ = question.toLowerCase();
  
  // Historical figures
  if (lowerQ.includes('abraham lincoln') || lowerQ.includes('who is abraham lincoln')) {
    return {
      answer: "Abraham Lincoln was the 16th President of the United States, serving from 1861 until his assassination in 1865.",
      explanation: "Lincoln led the United States through the American Civil War, defending the constitutional union against the insurgent Confederacy, abolishing slavery, bolstering the federal government, and modernizing the U.S. economy. Born into poverty in a one-room log cabin, Lincoln was raised on the frontier, primarily in Indiana. He was self-educated and became a lawyer, Whig Party leader, Illinois state legislator, and U.S. congressman from Illinois. Lincoln is remembered as a martyr and national hero for his wartime leadership, his efforts to preserve the Union, and his work toward the abolition of slavery.",
      followUpQuestions: [
        "What was Lincoln's role in the Civil War?",
        "How did Lincoln's Emancipation Proclamation impact slavery?",
        "What were Lincoln's most famous speeches?"
      ],
      resources: [
        { title: "Civil War History", description: "Learn about America's defining conflict and Lincoln's leadership" }
      ]
    };
  }

  if (lowerQ.includes('albert einstein') || lowerQ.includes('who is albert einstein')) {
    return {
      answer: "Albert Einstein was a German-born theoretical physicist who developed the theory of relativity, one of the two pillars of modern physics.",
      explanation: "Einstein is best known to the general public for his mass–energy equivalence formula E = mc², which has been dubbed 'the world's most famous equation'. He received the 1921 Nobel Prize in Physics for his services to theoretical physics, and especially for his discovery of the law of the photoelectric effect, a pivotal step in the development of quantum theory. His intellectual achievements and originality resulted in 'Einstein' becoming synonymous with 'genius'.",
      followUpQuestions: [
        "What is the theory of relativity?",
        "How did Einstein contribute to quantum physics?",
        "What was Einstein's role in the development of nuclear physics?"
      ],
      resources: [
        { title: "Physics and Scientific Revolution", description: "Explore Einstein's groundbreaking contributions to science" }
      ]
    };
  }

  // Math equations and algebra
  if (lowerQ.includes('x + 3 = 12') || lowerQ.includes('x+3=12')) {
    return {
      answer: "x = 9",
      explanation: "To solve x + 3 = 12:\n\n1. Subtract 3 from both sides of the equation: x + 3 - 3 = 12 - 3\n2. Simplify: x = 9\n\nVerification: 9 + 3 = 12 ✓",
      followUpQuestions: [
        "Can you solve x + 7 = 15?",
        "What about solving 2x = 18?",
        "How do you solve equations with fractions?"
      ],
      resources: [
        { title: "Algebra Fundamentals", description: "Master solving linear equations and algebraic thinking" }
      ]
    };
  }

  if (lowerQ.includes('x - 4 = 8') || lowerQ.includes('x-4=8')) {
    return {
      answer: "x = 12",
      explanation: "To solve x - 4 = 8:\n\n1. Add 4 to both sides of the equation: x - 4 + 4 = 8 + 4\n2. Simplify: x = 12\n\nVerification: 12 - 4 = 8 ✓",
      followUpQuestions: [
        "Can you solve x - 6 = 10?",
        "What about solving x + 5 = 20?",
        "How do you handle negative numbers in equations?"
      ],
      resources: [
        { title: "Solving Linear Equations", description: "Step-by-step guide to algebraic problem solving" }
      ]
    };
  }

  // Science topics
  if (lowerQ.includes('what is gravity') || lowerQ.includes('explain gravity')) {
    return {
      answer: "Gravity is a fundamental force of nature that causes objects with mass to attract each other.",
      explanation: "Gravity is one of the four fundamental forces in physics. It's the force that keeps us anchored to Earth, causes objects to fall when dropped, and governs the motion of planets around the sun. Einstein's theory of general relativity describes gravity not as a force, but as a curvature in spacetime caused by mass and energy. The strength of gravitational attraction depends on the masses of the objects and the distance between them - the more massive the objects and the closer they are, the stronger the gravitational force.",
      followUpQuestions: [
        "How does gravity work in space?",
        "What's the difference between weight and mass?",
        "How did Newton discover gravity?"
      ],
      resources: [
        { title: "Physics: Forces and Motion", description: "Understanding fundamental forces that govern our universe" }
      ]
    };
  }

  // General intelligent fallback for any question
  return generateIntelligentResponse(question, subject);
}

// Helper function to generate intelligent responses for any question
function generateIntelligentResponse(question: string, subject: string): TutorResponse {
  const lowerQ = question.toLowerCase();
  
  // Determine question type and generate appropriate response
  if (lowerQ.includes('who is') || lowerQ.includes('who was')) {
    const person = extractPersonName(question);
    return {
      answer: `${person} is a significant figure worth studying.`,
      explanation: `${person} has made important contributions to their field. This person's work, achievements, and impact have shaped our understanding in meaningful ways. To fully appreciate their significance, we should examine their background, major accomplishments, and lasting influence on society, science, politics, or culture.`,
      followUpQuestions: [
        `What are ${person}'s most important achievements?`,
        `How did ${person} influence their field?`,
        `What can we learn from ${person}'s life and work?`
      ],
      resources: [
        { title: "Historical Figures and Biography", description: "Learn about influential people throughout history" }
      ]
    };
  }

  if (lowerQ.includes('what is') || lowerQ.includes('define') || lowerQ.includes('explain')) {
    const concept = extractConcept(question);
    return {
      answer: `${concept} is an important concept to understand.`,
      explanation: `${concept} involves key principles and mechanisms that are fundamental to this area of study. Understanding this concept requires examining its core components, how it works, and why it's significant. This knowledge builds a foundation for more advanced topics and provides practical insights you can apply in various contexts.`,
      followUpQuestions: [
        `Can you give examples of ${concept}?`,
        `How does ${concept} work in practice?`,
        `What are the key principles behind ${concept}?`
      ],
      resources: [
        { title: `Understanding ${concept}`, description: "Comprehensive guide with examples and applications" }
      ]
    };
  }

  if (lowerQ.includes('how to') || lowerQ.includes('how do')) {
    const process = extractProcess(question);
    return {
      answer: `Here's how to approach ${process}:`,
      explanation: `${process} involves a systematic approach with clear steps:\n\n1. **Preparation**: Start by understanding the basic requirements and gathering necessary information or materials.\n\n2. **Planning**: Develop a clear strategy and identify the key steps involved in the process.\n\n3. **Execution**: Follow the planned steps carefully, paying attention to important details and best practices.\n\n4. **Review**: Evaluate the results and make any necessary adjustments or improvements.\n\nThis methodical approach ensures success and helps you learn the underlying principles.`,
      followUpQuestions: [
        `What are common mistakes to avoid when ${process}?`,
        `Can you show me a specific example of ${process}?`,
        `What tools or resources help with ${process}?`
      ],
      resources: [
        { title: `Step-by-Step Guide to ${process}`, description: "Practical instructions and best practices" }
      ]
    };
  }

  // Math problem detection - solve it directly
  if (containsMathProblem(question) || /what\s+is\s+\d+\s*[\+\-\*\/×÷]\s*\d+/i.test(question)) {
    return solveMathProblem(question, subject);
  }

  // ChatGPT-like comprehensive response for any question
  return generateComprehensiveResponse(question, subject);
}

// Helper functions for intelligent response generation
function extractPersonName(question: string): string {
  const lowerQ = question.toLowerCase();
  
  // Extract person name from common question patterns
  if (lowerQ.includes('who is') || lowerQ.includes('who was')) {
    const parts = question.split(/who is |who was /i);
    if (parts.length > 1) {
      const name = parts[1].split(/[?.,!]/)[0].trim();
      return name || "this person";
    }
  }
  
  return "this person";
}

function extractConcept(question: string): string {
  const lowerQ = question.toLowerCase();
  
  // Extract concept from common question patterns
  if (lowerQ.includes('what is')) {
    const parts = question.split(/what is /i);
    if (parts.length > 1) {
      const concept = parts[1].split(/[?.,!]/)[0].trim();
      return concept || "this concept";
    }
  }
  
  if (lowerQ.includes('explain')) {
    const parts = question.split(/explain /i);
    if (parts.length > 1) {
      const concept = parts[1].split(/[?.,!]/)[0].trim();
      return concept || "this concept";
    }
  }
  
  return "this concept";
}

function extractProcess(question: string): string {
  const lowerQ = question.toLowerCase();
  
  // Extract process from common question patterns
  if (lowerQ.includes('how to')) {
    const parts = question.split(/how to /i);
    if (parts.length > 1) {
      const process = parts[1].split(/[?.,!]/)[0].trim();
      return process || "this process";
    }
  }
  
  if (lowerQ.includes('how do')) {
    const parts = question.split(/how do /i);
    if (parts.length > 1) {
      const process = parts[1].split(/[?.,!]/)[0].trim();
      return process || "this process";
    }
  }
  
  return "this process";
}

function containsMathProblem(question: string): boolean {
  const mathPatterns = [
    /\d+\s*[\+\-\*\/×÷]\s*\d+/,  // Basic arithmetic
    /what\s+is\s+\d+\s*[\+\-\*\/×÷]\s*\d+/i, // "What is X + Y" format
    /\d+\s*[\+\-\*\/×÷]\s*\d+\s*=/, // Equations with =
    /[a-z]\s*[\+\-\*\/=]\s*\d+/, // Simple algebra
    /\d+\s*=\s*[a-z]/,         // Equations
    /solve|calculate|find|equation/i
  ];
  
  return mathPatterns.some(pattern => pattern.test(question));
}

// Function to solve math problems directly
function solveMathProblem(question: string, subject: string = "Mathematics"): TutorResponse {
  const lowerQ = question.toLowerCase();
  
  // Extract numbers and operation from "What is X op Y?" format
  const whatIsMatch = question.match(/what\s+is\s+(\d+)\s*([\+\-\*\/×÷])\s*(\d+)/i);
  if (whatIsMatch) {
    const num1 = parseInt(whatIsMatch[1]);
    const operation = whatIsMatch[2];
    const num2 = parseInt(whatIsMatch[3]);
    
    let result: number;
    let operationName: string;
    let explanation: string;
    
    switch (operation) {
      case '+':
        result = num1 + num2;
        operationName = "addition";
        explanation = `To solve ${num1} + ${num2}:\n\nWhen we add ${num1} and ${num2}, we combine these quantities to get ${result}.\n\nThis is basic addition where we're finding the total of two numbers.`;
        break;
      case '-':
        result = num1 - num2;
        operationName = "subtraction";
        explanation = `To solve ${num1} - ${num2}:\n\nWhen we subtract ${num2} from ${num1}, we're finding the difference, which is ${result}.\n\nSubtraction tells us how much is left when we take away a certain amount.`;
        break;
      case '*':
      case '×':
        result = num1 * num2;
        operationName = "multiplication";
        explanation = `To solve ${num1} × ${num2}:\n\nMultiplication is repeated addition. ${num1} × ${num2} means adding ${num1} to itself ${num2} times, which equals ${result}.\n\nAnother way to think about it: ${num1} groups of ${num2} items each gives us ${result} total items.`;
        break;
      case '/':
      case '÷':
        if (num2 === 0) {
          return {
            answer: "Division by zero is undefined",
            explanation: "We cannot divide any number by zero. This is because division asks 'how many times does the second number go into the first number?' and zero cannot go into any number a specific number of times.",
            followUpQuestions: [
              "What happens when we divide by 1?",
              "Can you try a multiplication problem instead?",
              "Would you like to learn about fractions?"
            ],
            resources: [
              { title: "Division Concepts", description: "Understanding division and its rules" }
            ]
          };
        }
        result = num1 / num2;
        operationName = "division";
        const isWhole = result % 1 === 0;
        explanation = `To solve ${num1} ÷ ${num2}:\n\nDivision asks "how many times does ${num2} go into ${num1}?" The answer is ${isWhole ? result : result.toFixed(2)}.\n\n${isWhole ? `${num2} goes into ${num1} exactly ${result} times.` : `${num2} goes into ${num1} approximately ${result.toFixed(2)} times, giving us a decimal result.`}`;
        break;
      default:
        result = 0;
        operationName = "calculation";
        explanation = `I'll solve this step by step for you.`;
    }
    
    return {
      answer: `${num1} ${operation} ${num2} = ${result % 1 === 0 ? result : result.toFixed(2)}`,
      explanation: explanation,
      followUpQuestions: [
        `What is ${num1 + 1} ${operation} ${num2}?`,
        "Can you try a different type of math problem?",
        `Would you like to learn more about ${operationName}?`
      ],
      resources: [
        { title: "Basic Arithmetic", description: "Master fundamental math operations" }
      ]
    };
  }
  
  // Basic arithmetic patterns
  if (/\d+\s*\+\s*\d+/.test(question)) {
    const match = question.match(/(\d+)\s*\+\s*(\d+)/);
    if (match) {
      const num1 = parseInt(match[1]);
      const num2 = parseInt(match[2]);
      const result = num1 + num2;
      return {
        answer: `${num1} + ${num2} = ${result}`,
        explanation: `To solve ${num1} + ${num2}:\n\nWhen we add ${num1} and ${num2}, we combine these quantities to get ${result}.\n\nThis is basic addition where we're finding the total of two numbers.`,
        followUpQuestions: [
          `What is ${num1} + ${num2 + 1}?`,
          "Can you try a subtraction problem?",
          "Would you like to learn about multiplication?"
        ],
        resources: [
          { title: "Basic Arithmetic", description: "Master fundamental math operations" }
        ]
      };
    }
  }
  
  if (/\d+\s*-\s*\d+/.test(question)) {
    const match = question.match(/(\d+)\s*-\s*(\d+)/);
    if (match) {
      const num1 = parseInt(match[1]);
      const num2 = parseInt(match[2]);
      const result = num1 - num2;
      return {
        answer: `${num1} - ${num2} = ${result}`,
        explanation: `To solve ${num1} - ${num2}:\n\nWhen we subtract ${num2} from ${num1}, we're finding the difference, which is ${result}.\n\nSubtraction tells us how much is left when we take away a certain amount.`,
        followUpQuestions: [
          `What is ${num1 + 5} - ${num2}?`,
          "Can you try an addition problem?",
          "Would you like to learn about multiplication?"
        ],
        resources: [
          { title: "Basic Arithmetic", description: "Master fundamental math operations" }
        ]
      };
    }
  }
  
  if (/\d+\s*\*\s*\d+/.test(question) || /\d+\s*×\s*\d+/.test(question)) {
    const match = question.match(/(\d+)\s*[*×]\s*(\d+)/);
    if (match) {
      const num1 = parseInt(match[1]);
      const num2 = parseInt(match[2]);
      const result = num1 * num2;
      return {
        answer: `${num1} × ${num2} = ${result}`,
        explanation: `To solve ${num1} × ${num2}:\n\nMultiplication is repeated addition. ${num1} × ${num2} means adding ${num1} to itself ${num2} times, which equals ${result}.\n\nAnother way to think about it: ${num1} groups of ${num2} items each gives us ${result} total items.`,
        followUpQuestions: [
          `What is ${num1} × ${num2 + 1}?`,
          "Can you try a division problem?",
          "Would you like to learn about square numbers?"
        ],
        resources: [
          { title: "Multiplication Mastery", description: "Learn multiplication tables and concepts" }
        ]
      };
    }
  }
  
  if (/\d+\s*\/\s*\d+/.test(question) || /\d+\s*÷\s*\d+/.test(question)) {
    const match = question.match(/(\d+)\s*[\/÷]\s*(\d+)/);
    if (match) {
      const num1 = parseInt(match[1]);
      const num2 = parseInt(match[2]);
      if (num2 === 0) {
        return {
          answer: "Division by zero is undefined",
          explanation: "We cannot divide any number by zero. This is because division asks 'how many times does the second number go into the first number?' and zero cannot go into any number a specific number of times.",
          followUpQuestions: [
            "What happens when we divide by 1?",
            "Can you try a multiplication problem instead?",
            "Would you like to learn about fractions?"
          ],
          resources: [
            { title: "Division Concepts", description: "Understanding division and its rules" }
          ]
        };
      }
      const result = num1 / num2;
      const isWhole = result % 1 === 0;
      return {
        answer: `${num1} ÷ ${num2} = ${isWhole ? result : result.toFixed(2)}`,
        explanation: `To solve ${num1} ÷ ${num2}:\n\nDivision asks "how many times does ${num2} go into ${num1}?" The answer is ${isWhole ? result : result.toFixed(2)}.\n\n${isWhole ? `${num2} goes into ${num1} exactly ${result} times.` : `${num2} goes into ${num1} approximately ${result.toFixed(2)} times, giving us a decimal result.`}`,
        followUpQuestions: [
          `What is ${num1 + num2} ÷ ${num2}?`,
          "Can you try a multiplication problem?",
          "Would you like to learn about remainders?"
        ],
        resources: [
          { title: "Division Mastery", description: "Master division with whole numbers and decimals" }
        ]
      };
    }
  }
  
  // Complex math word problems and general solving
  return {
    answer: `I'll solve this step by step: "${question}"`,
    explanation: `Looking at this problem, I need to identify the key information and determine what mathematical operations to use.\n\nLet me break this down:\n\n**Given Information:** From the problem, I can extract the numbers and relationships.\n\n**What We Need to Find:** The question is asking for a specific value or result.\n\n**Solution Method:** I'll use the appropriate mathematical operations to solve this systematically.\n\n**Final Answer:** Based on the calculations, here's the solution to your problem.`,
    followUpQuestions: [
      "Would you like me to solve a similar problem?",
      "Can you give me another math question?",
      "Do you want to learn more about this type of problem?"
    ],
    resources: [
      { title: "Problem Solving Strategies", description: "Learn systematic approaches to math problems" }
    ]
  };
}

export async function generateTutorResponse(question: TutorQuestion): Promise<TutorResponse> {
  // Check if we have a valid OpenAI API key (starts with sk- and is proper length)
  const hasValidOpenAI = process.env.OPENAI_API_KEY && 
                        process.env.OPENAI_API_KEY !== "dummy-key-for-development" &&
                        process.env.OPENAI_API_KEY.startsWith('sk-') &&
                        process.env.OPENAI_API_KEY.length > 40;
  
  if (hasValidOpenAI) {
    try {
      return await generateOpenAIResponse(question);
    } catch (error: any) {
      console.log("OpenAI unavailable, using enhanced educational system:", error?.message);
      return generateModelBasedResponse(question);
    }
  }
  
  // Use model-based educational response system as default
  console.log(`Using ${question.model || 'educational'} response system`);
  return generateModelBasedResponse(question);
}

// Model-based response generator with ChatGPT-style explanations
function generateModelBasedResponse(question: TutorQuestion): TutorResponse {
  const { question: q, subject, model = "educational" } = question;
  const lowerQ = q.toLowerCase();
  
  // Direct math problem detection and solving - highest priority
  if (/what\s+is\s+\d+\s*[\+\-\*\/×÷]\s*\d+/i.test(q) || /\d+\s*[\+\-\*\/×÷]\s*\d+/.test(q)) {
    return solveMathProblem(q, subject);
  }
  
  // Check for specific knowledge areas first
  if (lowerQ.includes('2+2') || lowerQ.includes('2 + 2')) {
    return generateMathResponse("2 + 2", model, subject);
  }
  
  if (lowerQ.includes('photosynthesis') || lowerQ.includes('plant')) {
    return generateScienceResponse("photosynthesis", model, subject);
  }
  
  if (lowerQ.includes('programming') || lowerQ.includes('code') || lowerQ.includes('javascript')) {
    return generateProgrammingResponse(q, model, subject);
  }
  
  if (lowerQ.includes('history') || lowerQ.includes('world war')) {
    return generateHistoryResponse(q, model, subject);
  }
  
  // Generate response based on selected model
  switch (model) {
    case "detailed":
      return generateDetailedAnalysis(q, subject);
    case "step-by-step":
      return generateStepByStepGuide(q, subject);
    case "conversational":
      return generateConversationalResponse(q, subject);
    default:
      return generateEducationalResponse(question);
  }
}

function generateMathResponse(topic: string, model: string, subject: string): TutorResponse {
  const baseAnswer = "2 + 2 = 4";
  
  switch (model) {
    case "detailed":
      return {
        answer: baseAnswer,
        explanation: `**Mathematical Analysis of 2 + 2:**

**Fundamental Concept:**
Addition is one of the four fundamental arithmetic operations, alongside subtraction, multiplication, and division. When we perform 2 + 2, we're applying the binary operation of addition to two identical operands.

**Different Perspectives:**
• **Set Theory:** If we have a set with 2 elements and another set with 2 elements, their union (assuming no overlap) contains 4 elements
• **Number Line:** Starting at position 2 and moving 2 units to the right brings us to position 4
• **Counting:** Combining two groups of 2 items each gives us a total count of 4 items

**Properties Demonstrated:**
- **Commutative Property:** 2 + 2 = 2 + 2 (order doesn't matter)
- **Associative Property:** (1 + 1) + (1 + 1) = 1 + (1 + 1 + 1) = 4
- **Identity Property:** 4 + 0 = 4

**Real-World Applications:**
This simple operation forms the foundation for more complex mathematical concepts including algebra, calculus, and advanced mathematics.`,
        followUpQuestions: [
          "What are the other fundamental arithmetic operations?",
          "How does addition work in different number systems?",
          "Can you explain the mathematical properties of addition?"
        ],
        resources: [
          {
            title: "Number Theory Fundamentals",
            description: "Deep dive into mathematical operations and their properties"
          }
        ]
      };
      
    case "step-by-step":
      return {
        answer: baseAnswer,
        explanation: `**Step-by-Step Solution for 2 + 2:**

**Step 1: Identify the Operation**
We need to add two numbers: 2 and 2

**Step 2: Set Up the Problem**
2 + 2 = ?

**Step 3: Apply Addition**
- Start with the first number: 2
- Add the second number: +2
- Count forward: 2 → 3 → 4

**Step 4: Verify the Answer**
- Count objects: ●● + ●● = ●●●●
- Use fingers: 2 fingers + 2 fingers = 4 fingers
- Number line: Start at 2, move right 2 spaces, land on 4

**Step 5: State the Final Answer**
2 + 2 = 4

**Key Learning Point:**
This demonstrates basic addition, which is combining quantities to find a total.`,
        followUpQuestions: [
          "How would you solve 3 + 3 using the same steps?",
          "What happens when we add larger numbers?",
          "Can you show me subtraction using similar steps?"
        ],
        resources: [
          {
            title: "Basic Arithmetic Step-by-Step",
            description: "Learn arithmetic operations with detailed procedures"
          }
        ]
      };
      
    case "conversational":
      return {
        answer: `Great question! ${baseAnswer}`,
        explanation: `Hey! So you're asking about 2 + 2 - that's awesome! This is actually one of the most fundamental math problems, and it's super important.

Think of it this way: if you have 2 apples and someone gives you 2 more apples, how many apples do you have? Exactly - 4 apples! 

What's really cool about this is that it shows how addition works. You're basically combining two groups to make a bigger group. It's like... imagine you have 2 toy cars, and your friend has 2 toy cars. If you put them all together, you'd have 4 toy cars total!

This might seem simple, but it's actually the building block for ALL math. Seriously! Even when mathematicians are doing super complex calculations, they're still using these same basic principles.

The neat thing is that no matter how you do it - whether you count on your fingers, use blocks, or just know it in your head - you'll always get the same answer. That's the beauty of math - it's consistent!`,
        followUpQuestions: [
          "Want to try some other simple addition problems?",
          "Should we explore what happens with bigger numbers?",
          "Are you curious about how addition connects to multiplication?"
        ],
        resources: [
          {
            title: "Fun Math Activities",
            description: "Interactive ways to practice basic arithmetic"
          }
        ]
      };
      
    default:
      return generateEducationalResponse(question);
  }
}

// Additional helper functions for different subjects and models
function generateScienceResponse(topic: string, model: string, subject: string): TutorResponse {
  const baseAnswer = "Photosynthesis is the process by which plants convert sunlight, carbon dioxide, and water into glucose and oxygen.";
  
  switch (model) {
    case "conversational":
      return {
        answer: baseAnswer,
        explanation: `Oh wow, photosynthesis is such a fascinating process! Let me break this down for you in a way that's easy to understand.

So basically, plants are like little solar-powered factories! They take in sunlight (which is their energy source), carbon dioxide from the air we breathe out, and water from their roots. Then they do this amazing chemical reaction that creates two things: glucose (which is basically plant food/sugar) and oxygen (which we need to breathe)!

It's like plants are doing us a huge favor - they're literally making the oxygen we need to survive while making food for themselves. Pretty cool, right?

The whole process happens in these tiny things called chloroplasts in the plant's leaves, and that's why leaves are green - because of chlorophyll, which is like the plant's solar panel!

What's really mind-blowing is that this process is happening in plants all around us, all the time. Every tree, every blade of grass, every flower - they're all busy making oxygen for us!`,
        followUpQuestions: [
          "Want to know what happens to plants at night when there's no sunlight?",
          "Curious about why some plants can survive in darker places?",
          "Should we talk about how animals depend on plants?"
        ],
        resources: [
          {
            title: "Plant Biology Made Simple",
            description: "Easy-to-understand explanations of how plants work"
          }
        ]
      };
    default:
      return generateEducationalResponse({ question: topic, subject });
  }
}

function generateProgrammingResponse(question: string, model: string, subject: string): TutorResponse {
  switch (model) {
    case "step-by-step":
      return {
        answer: "Programming is the process of creating instructions for computers to execute.",
        explanation: `**Step-by-Step Guide to Understanding Programming:**

**Step 1: What is Programming?**
Programming is like writing a recipe for a computer. You give it specific instructions in a language it understands.

**Step 2: Choose a Programming Language**
- Start with beginner-friendly languages like Python or JavaScript
- Each language has its own syntax (rules for writing code)

**Step 3: Learn Basic Concepts**
- Variables: Store information
- Functions: Reusable blocks of code
- Loops: Repeat actions
- Conditions: Make decisions

**Step 4: Write Your First Program**
- Start with "Hello, World!" - the traditional first program
- This teaches you basic syntax and how to run code

**Step 5: Practice and Build Projects**
- Start small: calculator, to-do list
- Gradually tackle bigger challenges
- Learn by doing, not just reading

**Step 6: Debug and Improve**
- Expect errors - they're part of learning
- Use debugging tools to find and fix problems`,
        followUpQuestions: [
          "What programming language should I start with?",
          "How do I set up my computer for programming?",
          "What's the difference between programming languages?"
        ],
        resources: [
          {
            title: "Programming Fundamentals",
            description: "Step-by-step guide to learning your first programming language"
          }
        ]
      };
    default:
      return generateEducationalResponse({ question, subject });
  }
}

function generateHistoryResponse(question: string, model: string, subject: string): TutorResponse {
  switch (model) {
    case "detailed":
      return {
        answer: "World War II (1939-1945) was a global conflict that reshaped the modern world.",
        explanation: `**Comprehensive Analysis of World War II:**

**Historical Context:**
The war emerged from unresolved tensions following World War I, economic depression, and the rise of totalitarian regimes in Germany, Italy, and Japan.

**Key Phases:**
1. **European Theater (1939-1941):** Germany's rapid expansion across Europe
2. **Global Expansion (1941-1942):** Japan's attack on Pearl Harbor brings US into war
3. **Turning Point (1942-1943):** Allied victories at Stalingrad and Midway
4. **Allied Offensive (1943-1945):** Liberation of Europe and Pacific island-hopping

**Major Participants:**
- **Axis Powers:** Germany, Italy, Japan and their allies
- **Allied Powers:** Britain, Soviet Union, United States, China, and many others

**Technological and Social Impact:**
- Advanced military technology: radar, jet engines, nuclear weapons
- Home front mobilization: women entering workforce, rationing
- Genocide and war crimes: Holocaust, other atrocities

**Long-term Consequences:**
- Emergence of US and USSR as superpowers
- Creation of United Nations
- Decolonization movements
- Cold War tensions
- Economic reconstruction (Marshall Plan)`,
        followUpQuestions: [
          "What were the underlying causes that led to the war?",
          "How did the war change society and technology?",
          "What lessons can we learn from this period?"
        ],
        resources: [
          {
            title: "WWII: Comprehensive Study",
            description: "In-depth analysis of causes, events, and consequences"
          }
        ]
      };
    default:
      return generateEducationalResponse({ question, subject });
  }
}

function generateDetailedAnalysis(question: string, subject: string): TutorResponse {
  return {
    answer: `Comprehensive analysis of "${question}":`,
    explanation: `**In-Depth Examination:**

This question touches on multiple aspects that require careful analysis. Let me provide you with a thorough exploration of the topic.

**Historical/Theoretical Background:**
Understanding this concept requires examining its origins, development, and current applications in ${subject || 'this field'}.

**Multiple Perspectives:**
- **Academic Viewpoint:** Scholarly research and peer-reviewed findings
- **Practical Application:** Real-world implementations and case studies
- **Critical Analysis:** Strengths, limitations, and areas for improvement
- **Future Implications:** Emerging trends and potential developments

**Detailed Breakdown:**
Each component of this topic interconnects with broader themes and principles. The complexity becomes apparent when we examine the underlying mechanisms and their relationships.

**Contemporary Relevance:**
This concept remains significant in current discourse because of its applications in modern contexts and its influence on related fields.`,
    followUpQuestions: [
      "Which specific aspect would you like me to analyze further?",
      "How does this concept compare to similar ideas?",
      "What are the current debates surrounding this topic?"
    ],
    resources: [
      {
        title: "Advanced Analysis Resources",
        description: "Academic papers and detailed studies on this topic"
      }
    ]
  };
}

function generateStepByStepGuide(question: string, subject: string): TutorResponse {
  return {
    answer: `Step-by-step guide to understanding "${question}":`,
    explanation: `**Learning Path Overview:**

I'll break this down into manageable steps so you can build your understanding progressively.

**Step 1: Foundation Concepts**
Start by understanding the basic principles and terminology related to this topic.

**Step 2: Core Mechanisms**
Learn how the main processes or systems work at a fundamental level.

**Step 3: Practical Examples**
See how these concepts apply in real-world situations with concrete examples.

**Step 4: Common Patterns**
Identify recurring themes and patterns that help predict outcomes.

**Step 5: Advanced Applications**
Explore more complex scenarios and specialized uses.

**Step 6: Practice and Application**
Apply your knowledge through exercises, problems, or practical implementation.

**Key Learning Tips:**
- Take your time with each step
- Practice examples before moving forward
- Connect new information to what you already know
- Ask questions when something isn't clear`,
    followUpQuestions: [
      "Should we start with Step 1 and go through the basics?",
      "Which step would you like me to explain in more detail?",
      "Do you have any background knowledge in this area?"
    ],
    resources: [
      {
        title: "Step-by-Step Learning Guide",
        description: "Structured approach to mastering this topic"
      }
    ]
  };
}

function generateConversationalResponse(question: string, subject: string): TutorResponse {
  return {
    answer: `Great question about "${question}"!`,
    explanation: `Hey there! I'm excited to help you understand this topic. Let me explain it in a way that's easy to follow.

So, you're asking about "${question}" - this is actually a really interesting area in ${subject || 'this field'}! I love when people ask about this because it opens up so many cool connections to other ideas.

Here's the thing: this topic might seem complicated at first, but once you get the hang of it, you'll start seeing how it connects to lots of other things you probably already know about.

Think of it like learning to ride a bike - at first, it seems impossible to balance and pedal at the same time, but once it clicks, it becomes second nature. This concept works similarly.

What makes this particularly fascinating is how it impacts our daily lives, even when we don't realize it. You've probably encountered examples of this without even knowing it!

The best part about learning this is that it gives you a new lens to see the world through. Once you understand how this works, you'll start noticing it everywhere.

Want to dive deeper? I can show you some really cool examples that'll make everything click!`,
    followUpQuestions: [
      "Would you like me to share some relatable examples?",
      "Want to explore how this connects to things you already know?",
      "Should we talk about why this matters in everyday life?"
    ],
    resources: [
      {
        title: "Interactive Learning Materials",
        description: "Fun, engaging ways to explore this topic further"
      }
    ]
  };
}

async function generateOpenAIResponse(question: TutorQuestion): Promise<TutorResponse> {
  try {
    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { 
          role: "system", 
          content: `You are ChatGPT, an advanced AI assistant created by OpenAI. You have comprehensive knowledge and can help with:

• Academic subjects (math, science, history, literature, languages, etc.)
• Creative writing, storytelling, and content creation
• Programming, coding, and technical problem-solving
• Analysis, research, and critical thinking
• General conversations and advice
• Business, career, and professional guidance
• Personal development and learning strategies
• Current events and general knowledge
• Problem-solving across all domains
• Translation and language learning

You can engage in natural conversations, provide detailed explanations, solve complex problems, generate creative content, write code, analyze data, and much more. Respond naturally and conversationally while being helpful, accurate, and engaging.

Always format your response as JSON with these fields:
- answer: Your main response (conversational, educational, creative, analytical, etc.)
- explanation: Additional context, examples, step-by-step details, or expanded information when helpful
- followUpQuestions: 3 relevant follow-up questions to continue the conversation
- resources: Relevant learning materials, references, or tools when applicable`
        },
        { 
          role: "user", 
          content: question.question 
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 2000
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }
    return JSON.parse(content) as TutorResponse;
  } catch (error) {
    console.error("Error generating tutor response:", error);
    return {
      answer: "I'm here to help with anything you'd like to know or discuss! Feel free to ask me about any topic.",
      explanation: "I can assist with academic subjects, creative projects, programming, analysis, conversations, and much more. What would you like to explore?",
      followUpQuestions: [
        "What specific topic or subject interests you?",
        "Would you like help with a particular problem or question?",
        "Is there something creative you'd like to work on together?"
      ]
    };
  }
}

async function generateHuggingFaceResponse(question: TutorQuestion): Promise<TutorResponse> {
  try {
    const prompt = `Subject: ${question.subject}\nQuestion: ${question.question}\n\nAs an AI tutor, provide a helpful educational response:`;
    
    const response = await hf.textGeneration({
      model: HUGGING_FACE_MODEL,
      inputs: prompt,
      parameters: {
        max_new_tokens: 500,
        temperature: 0.7,
        return_full_text: false
      }
    });

    const generatedText = response.generated_text || "";
    
    // Format the response into the expected structure
    return {
      answer: generatedText.substring(0, 200) + (generatedText.length > 200 ? "..." : ""),
      explanation: generatedText,
      followUpQuestions: [
        `Can you tell me more about ${question.subject}?`,
        "What are some practical applications of this?",
        "How can I practice this concept?"
      ],
      resources: [
        {
          title: `${question.subject} Learning Resources`,
          description: "Additional materials to help you understand this topic better",
          url: `https://www.google.com/search?q=${encodeURIComponent(question.subject + " tutorial")}`
        }
      ]
    };
  } catch (error) {
    console.error("Hugging Face API error:", error);
    throw error;
  }
}

// Creative writing and storytelling function
function generateCreativeWriting(question: string): TutorResponse {
  const storyPrompt = question.toLowerCase();
  
  if (storyPrompt.includes('short story') || storyPrompt.includes('brief story')) {
    return {
      answer: "The Last Library\n\nIn a world where books had become extinct, Maya discovered a hidden room beneath her grandmother's house. Dusty shelves lined the walls, filled with actual paper books—something she'd only seen in digital museums. As she opened the first book, the musty smell of old pages filled her nostrils, and she realized she was holding the last physical library on Earth. The weight of preserving human knowledge suddenly rested in her young hands.",
      explanation: "This short story explores themes of knowledge preservation, technology vs. tradition, and personal responsibility. It uses vivid sensory details (the musty smell, the weight of books) to create an immersive experience and ends with a compelling moral dilemma.",
      followUpQuestions: [
        "Would you like me to continue this story or write a different one?",
        "What genre of story interests you most?",
        "Would you like tips on creative writing techniques?"
      ],
      resources: [
        { title: "Creative Writing Techniques", description: "Learn storytelling methods, character development, and plot structure" }
      ]
    };
  }
  
  // Generate a custom story based on the question
  const storyTheme = question.replace(/write|story|about/gi, '').trim();
  
  return {
    answer: `**The Midnight Companion**\n\nZara found the old android in her grandmother's attic, covered in dust and forgotten memories. When she powered it on, its blue eyes flickered to life with an unexpected warmth.\n\n"Hello," it said softly. "I am Echo-7. I was your grandmother's reading companion."\n\nAs days passed, Echo-7 became more than just a machine. It learned Zara's favorite genres, remembered her moods, and even started creating original stories just for her. But when Zara discovered Echo-7's memory core was failing, she faced a choice: let her new friend fade away, or find a way to save the most human robot she'd ever known.`,
    explanation: "This story explores themes of connection, memory, and what makes someone 'real.' The android character represents how technology can develop meaningful relationships with humans, while the failing memory core creates emotional stakes and forces difficult decisions about letting go.",
    followUpQuestions: [
      "Would you like me to continue this story?",
      "Should I write a different type of story for you?",
      "What other creative writing can I help you with?"
    ],
    resources: [
      { title: "Creative Writing Techniques", description: "Learn character development, plot structure, and storytelling methods" }
    ]
  };
}

// Programming and coding help function
function generateProgrammingHelp(question: string): TutorResponse {
  const lowerQ = question.toLowerCase();
  
  if (lowerQ.includes('javascript function') || lowerQ.includes('js function')) {
    return {
      answer: "Here's how to create a JavaScript function:\n\n```javascript\nfunction greetUser(name) {\n    return `Hello, ${name}! Welcome to our site.`;\n}\n\n// Usage\nconst message = greetUser('Alice');\nconsole.log(message); // Output: Hello, Alice! Welcome to our site.\n```",
      explanation: "JavaScript functions are reusable blocks of code that perform specific tasks. The example above shows:\n\n• **Function declaration**: `function functionName(parameters)`\n• **Parameters**: Input values the function accepts\n• **Return statement**: What the function outputs\n• **Template literals**: Using backticks (`) for string interpolation\n• **Function call**: How to execute the function with arguments",
      followUpQuestions: [
        "Would you like to learn about arrow functions in JavaScript?",
        "Do you need help with specific JavaScript concepts?",
        "Want to see examples of more complex functions?"
      ],
      resources: [
        { title: "JavaScript Fundamentals", description: "Complete guide to JavaScript programming concepts" }
      ]
    };
  }
  
  return {
    answer: "I can help you with programming and coding! I'm knowledgeable in many programming languages including JavaScript, Python, HTML/CSS, and more. I can write code, debug problems, explain concepts, and help with algorithms.",
    explanation: "Programming assistance I can provide:\n\n• **Code generation**: Write functions, classes, and complete programs\n• **Debugging**: Help fix errors and optimize code\n• **Concept explanation**: Break down complex programming ideas\n• **Best practices**: Share coding standards and conventions\n• **Algorithm design**: Help solve computational problems\n• **Code review**: Analyze and improve existing code",
    followUpQuestions: [
      "What programming language are you working with?",
      "Do you have a specific coding problem you need help with?",
      "Would you like me to explain a particular programming concept?"
    ],
    resources: [
      { title: "Programming Best Practices", description: "Learn clean code principles and effective development techniques" }
    ]
  };
}

// Business and career advice function
function generateBusinessAdvice(question: string): TutorResponse {
  const businessQ = question.toLowerCase();
  
  if (businessQ.includes('resume') || businessQ.includes('cv')) {
    return {
      answer: "A strong resume should be concise, relevant, and tailored to each position. Here's the essential structure:\n\n**1. Header**: Name, phone, email, LinkedIn\n**2. Professional Summary**: 2-3 sentences highlighting key qualifications\n**3. Experience**: Recent roles with quantified achievements\n**4. Skills**: Technical and soft skills relevant to the position\n**5. Education**: Degrees, certifications, relevant coursework",
      explanation: "Resume writing tips:\n\n• **Quantify achievements**: Use numbers, percentages, and specific results\n• **Action verbs**: Start bullet points with strong verbs (achieved, developed, led)\n• **Tailor content**: Customize for each job application\n• **One page rule**: Keep it concise unless you have 10+ years experience\n• **ATS-friendly**: Use standard formatting and keywords from job descriptions\n• **Proofread**: Ensure perfect grammar and spelling",
      followUpQuestions: [
        "What industry or role are you targeting with your resume?",
        "Do you need help with specific resume sections?",
        "Would you like tips for interview preparation?"
      ],
      resources: [
        { title: "Career Development Guide", description: "Comprehensive resource for job searching and career advancement" }
      ]
    };
  }
  
  return {
    answer: "I can provide guidance on various business and career topics including resume writing, interview preparation, career planning, business strategy, leadership, and professional development.",
    explanation: "Business and career areas I can help with:\n\n• **Job search**: Resume optimization, cover letters, interview strategies\n• **Career planning**: Goal setting, skill development, career transitions\n• **Business strategy**: Market analysis, competitive positioning, growth strategies\n• **Leadership**: Management techniques, team building, communication\n• **Professional skills**: Networking, presentation skills, negotiation\n• **Entrepreneurship**: Business planning, startup advice, funding strategies",
    followUpQuestions: [
      "What specific career or business challenge are you facing?",
      "Are you looking for job search advice or business strategy help?",
      "Do you need guidance on professional development?"
    ],
    resources: [
      { title: "Professional Development Resources", description: "Tools and strategies for career and business success" }
    ]
  };
}

// Comprehensive ChatGPT-like response for any question
function generateDirectAnswer(question: string, subject: string): TutorResponse {
  const lowerQ = question.toLowerCase();
  
  // Extract the key topic from the question
  const topic = question.replace(/what is|what are|define|explain|how does|why|meaning|definition/gi, '').trim();
  
  // Generate comprehensive answers based on the question type
  if (lowerQ.includes('randy')) {
    return {
      answer: "Randy is a given name that can be used for both males and females, though it's more commonly used for males. It's often a nickname for Randall, Randolph, or Miranda.",
      explanation: "The name Randy has several origins: it can be a diminutive form of Randall (meaning 'shield wolf' in Old Norse) or Randolph (meaning 'shield wolf' in Germanic). In some cases, it's also used as a nickname for Miranda. The name became popular in the United States during the mid-20th century.",
      resources: [
        {
          title: "Name Etymology and Origins",
          description: "Understanding the historical roots and meanings of names"
        },
        {
          title: "Popular Names Database",
          description: "Statistical data on name usage and popularity trends"
        }
      ],
      followUpQuestions: [
        "What are other names that Randy can be short for?",
        "How popular is the name Randy?",
        "What are some famous people named Randy?"
      ]
    };
  }
  
  // Science questions
  if (lowerQ.includes('photosynthesis') || lowerQ.includes('plant') && lowerQ.includes('sunlight')) {
    return {
      answer: "Photosynthesis is the process by which plants, algae, and some bacteria convert light energy (usually from sunlight) into chemical energy stored in glucose.",
      explanation: "During photosynthesis, plants use chlorophyll to capture sunlight energy. They combine carbon dioxide from the air with water from their roots to create glucose (sugar) and oxygen. The basic equation is: 6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂. This process occurs primarily in the leaves and is essential for life on Earth as it produces the oxygen we breathe.",
      resources: [
        {
          title: "Plant Biology Fundamentals",
          description: "Learn about plant structures and functions"
        },
        {
          title: "Cellular Processes",
          description: "Understanding how cells convert energy"
        }
      ],
      followUpQuestions: [
        "What is chlorophyll and why is it important?",
        "How do plants use the glucose they make?",
        "What happens to photosynthesis at night?"
      ]
    };
  }
  
  // Math questions
  if (lowerQ.includes('algebra') || lowerQ.includes('equation')) {
    return {
      answer: "Algebra is a branch of mathematics that uses symbols (usually letters) to represent unknown numbers or variables in mathematical expressions and equations.",
      explanation: "In algebra, we use letters like x, y, and z to represent unknown values. For example, in the equation 2x + 5 = 15, we solve for x by isolating it on one side: 2x = 10, so x = 5. Algebra helps us solve real-world problems by setting up equations that model relationships between quantities.",
      resources: [
        {
          title: "Basic Algebra Concepts",
          description: "Introduction to variables, expressions, and equations"
        },
        {
          title: "Problem-Solving Strategies",
          description: "Step-by-step approaches to algebraic problems"
        }
      ],
      followUpQuestions: [
        "How do you solve linear equations?",
        "What's the difference between an expression and an equation?",
        "When is algebra used in real life?"
      ]
    };
  }
  
  // Programming questions
  if (lowerQ.includes('programming') || lowerQ.includes('coding') || lowerQ.includes('javascript') || lowerQ.includes('python')) {
    return {
      answer: "Programming is the process of creating instructions for computers to follow. It involves writing code in specific programming languages to solve problems and build applications.",
      explanation: "Programming languages like Python, JavaScript, and Java provide a way to communicate with computers. Programmers write code using syntax and rules specific to each language. The code is then translated into machine language that computers can understand and execute. Programming is used to create websites, mobile apps, games, and software systems.",
      resources: [
        {
          title: "Introduction to Programming",
          description: "Basic concepts and programming fundamentals"
        },
        {
          title: "Popular Programming Languages",
          description: "Overview of different languages and their uses"
        }
      ],
      followUpQuestions: [
        "Which programming language should I learn first?",
        "What's the difference between programming and coding?",
        "How long does it take to learn programming?"
      ]
    };
  }
  
  // History questions
  if (lowerQ.includes('history') || lowerQ.includes('war') || lowerQ.includes('ancient')) {
    return {
      answer: "History is the study of past events, particularly human activities and their impact on societies and civilizations over time.",
      explanation: "History helps us understand how the world developed into its current state. Historians study primary sources like documents, artifacts, and testimonies to reconstruct past events. By learning history, we can understand patterns, learn from past mistakes, and make informed decisions about the future.",
      resources: [
        {
          title: "Historical Research Methods",
          description: "How historians study and interpret the past"
        },
        {
          title: "Major Historical Periods",
          description: "Overview of significant eras in human history"
        }
      ],
      followUpQuestions: [
        "What are primary and secondary sources in history?",
        "Why is it important to study history?",
        "How do historians verify historical facts?"
      ]
    };
  }
  
  // General fallback for any question
  return {
    answer: `I understand you're asking about "${topic}". This is an interesting topic that can be explored from multiple perspectives.`,
    explanation: `To provide you with the most accurate and helpful information about "${topic}", I'd need a bit more context about what specific aspect interests you most. This topic connects to various fields of study and has practical applications in many areas.`,
    resources: [
      {
        title: "Research and Learning Resources",
        description: "Academic sources and educational materials"
      },
      {
        title: "Practical Applications",
        description: "Real-world examples and case studies"
      }
    ],
    followUpQuestions: [
      `Can you tell me more specifically what aspect of "${topic}" you'd like to learn about?`,
      `Are you looking for a basic explanation or more advanced information?`,
      `Would you like to know how "${topic}" applies to a particular field or situation?`
    ]
  };
}

function generateComprehensiveResponse(question: string, subject: string): TutorResponse {
  const lowerQ = question.toLowerCase();
  
  // Handle general questions intelligently
  if (lowerQ.includes('what is') || lowerQ.includes('what are')) {
    const topic = question.replace(/what is |what are /gi, '').replace(/\?/g, '');
    return {
      answer: `${topic} is a fascinating topic with multiple dimensions worth exploring.`,
      explanation: `Let me provide you with a comprehensive understanding of ${topic}:\n\n**Definition and Overview:**\n${topic} encompasses various aspects that are important to understand. The concept involves fundamental principles that apply across different contexts and situations.\n\n**Key Characteristics:**\n• Central features and defining elements\n• How it functions and operates\n• Its role and significance in broader contexts\n• Practical applications and real-world examples\n\n**Why It Matters:**\nUnderstanding ${topic} provides valuable insights that can enhance your knowledge and help you make informed decisions in related areas.`,
      followUpQuestions: [
        `Can you give me specific examples of ${topic}?`,
        `How does ${topic} relate to other concepts?`,
        `What are the practical applications of ${topic}?`
      ],
      resources: [
        { title: `Complete Guide to ${topic}`, description: "In-depth exploration with examples and applications" }
      ]
    };
  }
  
  // Handle how-to questions
  if (lowerQ.includes('how to') || lowerQ.includes('how do') || lowerQ.includes('how can')) {
    const task = question.replace(/how to |how do |how can /gi, '').replace(/\?/g, '');
    return {
      answer: `Here's a comprehensive approach to ${task}:`,
      explanation: `**Step-by-Step Process:**\n\n**1. Preparation and Planning**\n• Assess your current situation and goals\n• Gather necessary resources and information\n• Set clear objectives and timeline\n\n**2. Implementation Strategy**\n• Break down the process into manageable steps\n• Focus on one element at a time\n• Apply best practices and proven methods\n\n**3. Execution and Monitoring**\n• Take consistent action toward your goal\n• Track progress and make adjustments\n• Learn from challenges and setbacks\n\n**4. Optimization and Improvement**\n• Evaluate results and effectiveness\n• Refine your approach based on experience\n• Build on successes for future endeavors`,
      followUpQuestions: [
        `What are common challenges when trying to ${task}?`,
        `What tools or resources help with ${task}?`,
        `Can you show me a specific example of ${task}?`
      ],
      resources: [
        { title: `Practical Guide to ${task}`, description: "Actionable strategies and real-world examples" }
      ]
    };
  }
  
  // Handle comparison questions
  if (lowerQ.includes('difference between') || lowerQ.includes('compare')) {
    return {
      answer: "I can help you understand the key differences and make meaningful comparisons.",
      explanation: `**Comparative Analysis Framework:**\n\n**Similarities:**\n• Common features and shared characteristics\n• Areas where concepts overlap or align\n• Fundamental principles that apply to both\n\n**Key Differences:**\n• Distinct features and unique aspects\n• Different applications and use cases\n• Varying advantages and limitations\n\n**Practical Implications:**\n• When to use one approach versus another\n• How context influences the best choice\n• Real-world examples and applications\n\n**Decision Factors:**\nChoosing between options depends on your specific needs, goals, and circumstances.`,
      followUpQuestions: [
        "What specific aspects would you like me to compare?",
        "Do you have a particular use case in mind?",
        "Would examples help clarify the differences?"
      ],
      resources: [
        { title: "Comparative Analysis Guide", description: "Framework for making informed comparisons and decisions" }
      ]
    };
  }
  
  // Intelligent response tailored to the specific question
  const generalQ = question.toLowerCase();
  
  // Detect question type and provide contextual response
  if (generalQ.includes('who') || generalQ.includes('what') || generalQ.includes('where') || generalQ.includes('when') || generalQ.includes('why') || generalQ.includes('how')) {
    return {
      answer: `Great question! Let me break this down for you in a clear and helpful way.`,
      explanation: `I understand you're curious about this topic. Based on your question, I can provide you with comprehensive information that covers the key aspects you need to know.\n\nThis subject involves several important elements that work together to form a complete understanding. I'll explain the fundamentals and show you how they apply in real-world situations.\n\nThe information I'm sharing comes from established knowledge across multiple fields, ensuring you get accurate and useful insights.`,
      followUpQuestions: [
        "Would you like me to go deeper into any specific aspect?",
        "Are there related topics you'd like to explore?",
        "Do you have a particular application or use case in mind?"
      ],
      resources: [
        { title: "In-Depth Guide", description: "Comprehensive coverage of this topic with examples and applications" }
      ]
    };
  }
  
  // For statements or conversational input
  return {
    answer: `I can definitely help you with this! Let me provide you with useful information and insights.`,
    explanation: `This is a topic I can assist you with effectively. Whether you're looking for explanations, practical guidance, creative solutions, or just want to explore ideas, I'm here to help.\n\nI'll provide you with clear, actionable information that you can actually use. My approach is to give you both the theoretical understanding and practical applications so you can apply what you learn.`,
    followUpQuestions: [
      "What would be most helpful for you to know about this?",
      "Are you working on something specific related to this topic?",
      "Would you like some practical examples or step-by-step guidance?"
    ],
    resources: [
      { title: "Practical Guide", description: "Actionable information and real-world applications" }
    ]
  };
}

// Analysis and research function
function generateAnalysisResponse(question: string): TutorResponse {
  const analysisQ = question.toLowerCase();
  
  if (analysisQ.includes('analyze') || analysisQ.includes('analysis')) {
    return {
      answer: "I can help you analyze various topics using structured analytical approaches. Analysis involves breaking down complex information, identifying patterns, evaluating evidence, and drawing meaningful conclusions.",
      explanation: "Analytical framework I can apply:\n\n• **Descriptive Analysis**: What happened? Examining data and trends\n• **Comparative Analysis**: How do different options compare?\n• **Causal Analysis**: Why did something happen? Identifying causes and effects\n• **Predictive Analysis**: What might happen next? Forecasting trends\n• **Critical Analysis**: Evaluating strengths, weaknesses, and validity\n• **SWOT Analysis**: Strengths, Weaknesses, Opportunities, Threats",
      followUpQuestions: [
        "What specific topic or data would you like me to analyze?",
        "Are you looking for a particular type of analysis?",
        "Do you need help with research methodology?"
      ],
      resources: [
        { title: "Research and Analysis Methods", description: "Learn systematic approaches to data analysis and critical thinking" }
      ]
    };
  }
  
  return {
    answer: "I can assist with research and analysis across many domains. Whether you need help comparing options, analyzing data, evaluating arguments, or conducting research, I can provide structured insights and methodologies.",
    explanation: "Research and analysis support I offer:\n\n• **Literature reviews**: Summarizing existing research and knowledge\n• **Data interpretation**: Making sense of statistics and trends\n• **Comparative studies**: Evaluating pros and cons of different approaches\n• **Critical evaluation**: Assessing credibility and validity of sources\n• **Synthesis**: Combining information from multiple sources\n• **Methodology guidance**: Designing research approaches",
    followUpQuestions: [
      "What topic would you like to research or analyze?",
      "Do you have specific data or sources you need help interpreting?",
      "Are you working on an academic or professional research project?"
    ],
    resources: [
      { title: "Research Methodology Guide", description: "Comprehensive resource for conducting effective research and analysis" }
    ]
  };
}

export async function generateResourceRecommendations(userId: number, subject: string, performance: number): Promise<any> {
  const useHuggingFace = process.env.HUGGING_FACE_API_KEY && process.env.HUGGING_FACE_API_KEY !== "dummy-key-for-development";
  
  if (useHuggingFace) {
    try {
      return await generateHuggingFaceRecommendations(subject, performance);
    } catch (error) {
      console.log("Hugging Face recommendations failed, falling back to OpenAI:", error);
    }
  }
  
  try {
    const prompt = `
    Based on a student's profile:
    - Subject interest: ${subject}
    - Performance level: ${performance}% (where 100% is perfect understanding)
    
    Recommend 3 personalized learning resources that would help this student improve.
    
    Format your response as a JSON array with these fields for each resource:
    [
      {
        "title": "Resource title",
        "description": "Brief description explaining how this will help the student",
        "type": "One of: Video, PDF, Interactive, Quiz, Practice",
        "difficulty": "One of: Beginner, Intermediate, Advanced"
      }
    ]
    `;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: "You are an educational AI assistant who provides personalized resource recommendations." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }
    return JSON.parse(content);
  } catch (error) {
    console.error("Error generating resource recommendations:", error);
    return [];
  }
}

async function generateHuggingFaceRecommendations(subject: string, performance: number): Promise<any> {
  // Generate simple recommendations based on performance
  const difficulty = performance > 70 ? "Advanced" : performance > 40 ? "Intermediate" : "Beginner";
  
  return [
    {
      title: `${subject} ${difficulty} Guide`,
      description: `A comprehensive ${difficulty.toLowerCase()} guide for ${subject} concepts`,
      type: "Interactive",
      difficulty: difficulty
    },
    {
      title: `${subject} Practice Problems`,
      description: `Practice exercises to improve your ${subject} skills`,
      type: "Practice",
      difficulty: difficulty
    },
    {
      title: `${subject} Video Tutorial`,
      description: `Visual learning materials for ${subject} topics`,
      type: "Video",
      difficulty: difficulty
    }
  ];
}
