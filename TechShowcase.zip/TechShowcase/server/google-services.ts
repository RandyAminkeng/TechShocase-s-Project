import fetch from 'node-fetch';

// Google Search API Integration
export interface GoogleSearchResult {
  kind: string;
  title: string;
  htmlTitle: string;
  link: string;
  displayLink: string;
  snippet: string;
  htmlSnippet: string;
  cacheId?: string;
  formattedUrl: string;
  htmlFormattedUrl: string;
  pagemap?: {
    cse_thumbnail?: Array<{
      src: string;
      width: string;
      height: string;
    }>;
    metatags?: Array<{
      [key: string]: string;
    }>;
    cse_image?: Array<{
      src: string;
    }>;
  };
}

export interface GoogleSearchResponse {
  kind: string;
  url: {
    type: string;
    template: string;
  };
  queries: {
    request: Array<{
      title: string;
      totalResults: string;
      searchTerms: string;
      count: number;
      startIndex: number;
      inputEncoding: string;
      outputEncoding: string;
      safe: string;
      cx: string;
    }>;
    nextPage?: Array<{
      title: string;
      totalResults: string;
      searchTerms: string;
      count: number;
      startIndex: number;
      inputEncoding: string;
      outputEncoding: string;
      safe: string;
      cx: string;
    }>;
  };
  context: {
    title: string;
  };
  searchInformation: {
    searchTime: number;
    formattedSearchTime: string;
    totalResults: string;
    formattedTotalResults: string;
  };
  items: GoogleSearchResult[];
}

// Real Google Search API
export async function performGoogleSearch(
  query: string, 
  searchType: 'web' | 'image' = 'web',
  options: {
    num?: number;
    start?: number;
    safe?: 'active' | 'off';
    dateRestrict?: string;
    siteSearch?: string;
    exactTerms?: string;
    excludeTerms?: string;
    fileType?: string;
    rights?: string;
    gl?: string; // geolocation
    hl?: string; // interface language
    imgSize?: string;
    imgType?: string;
    imgColorType?: string;
    tbm?: string;
    [key: string]: any;
  } = {}
): Promise<GoogleSearchResponse | null> {
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;
  const cx = process.env.GOOGLE_CUSTOM_SEARCH_ENGINE_ID;

  if (!apiKey || !cx) {
    console.warn('Google Search API credentials not configured');
    return null;
  }

  try {
    const params = new URLSearchParams({
      key: apiKey,
      cx: cx,
      q: query,
      num: (options.num || 10).toString(),
      start: (options.start || 1).toString(),
      safe: options.safe || 'active',
      ...Object.fromEntries(
        Object.entries(options).filter(([_, v]) => v !== undefined && v !== null)
      )
    });

    if (searchType === 'image') {
      params.append('searchType', 'image');
    }

    const response = await fetch(
      `https://www.googleapis.com/customsearch/v1?${params}`,
      {
        method: 'GET',
        headers: {
          'User-Agent': 'Educational-Platform/1.0'
        }
      }
    );

    if (!response.ok) {
      throw new Error(`Google Search API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as GoogleSearchResponse;
    return data;
  } catch (error) {
    console.error('Google Search API error:', error);
    return null;
  }
}

// Google Images Search
export async function searchGoogleImages(
  query: string,
  options: {
    imageSize?: 'huge' | 'icon' | 'large' | 'medium' | 'small' | 'xlarge' | 'xxlarge';
    imageType?: 'clipart' | 'face' | 'lineart' | 'stock' | 'photo' | 'animated';
    imageColorType?: 'color' | 'gray' | 'mono' | 'trans';
    rights?: 'cc_publicdomain' | 'cc_attribute' | 'cc_sharealike' | 'cc_noncommercial' | 'cc_nonderived';
    safe?: 'active' | 'off';
    num?: number;
  } = {}
) {
  const searchOptions: any = { ...options };
  if (options.imageSize) searchOptions.imgSize = options.imageSize;
  if (options.imageType) searchOptions.imgType = options.imageType;
  if (options.imageColorType) searchOptions.imgColorType = options.imageColorType;
  
  return await performGoogleSearch(query, 'image', searchOptions);
}

// Google Scholar Search (using Custom Search with Scholar site restriction)
export async function searchGoogleScholar(query: string, options: { num?: number; start?: number } = {}) {
  return await performGoogleSearch(query, 'web', {
    ...options,
    siteSearch: 'scholar.google.com',
  });
}

// Google News Search
export async function searchGoogleNews(
  query: string, 
  options: { 
    num?: number; 
    start?: number; 
    dateRestrict?: string; // e.g., 'd1', 'w1', 'm1', 'y1'
    sortBy?: 'date' | 'relevance';
  } = {}
) {
  const searchOptions: any = { ...options, siteSearch: 'news.google.com', tbm: 'nws' };
  return await performGoogleSearch(query, 'web', searchOptions);
}

// Google Books Search
export async function searchGoogleBooks(query: string, options: { num?: number; start?: number } = {}) {
  return await performGoogleSearch(query, 'web', {
    ...options,
    siteSearch: 'books.google.com',
  });
}

// Google Maps Places API Integration
export interface GooglePlace {
  place_id: string;
  name: string;
  formatted_address: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  rating?: number;
  user_ratings_total?: number;
  types: string[];
  photos?: Array<{
    photo_reference: string;
    height: number;
    width: number;
  }>;
  opening_hours?: {
    open_now: boolean;
    weekday_text: string[];
  };
}

export async function searchGooglePlaces(
  query: string,
  location?: { lat: number; lng: number; radius?: number },
  type?: string
): Promise<GooglePlace[]> {
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;

  if (!apiKey) {
    console.warn('Google Places API key not configured');
    return [];
  }

  try {
    let url = `https://maps.googleapis.com/maps/api/place/textsearch/json?key=${apiKey}&query=${encodeURIComponent(query)}`;
    
    if (location) {
      url += `&location=${location.lat},${location.lng}`;
      if (location.radius) {
        url += `&radius=${location.radius}`;
      }
    }
    
    if (type) {
      url += `&type=${type}`;
    }

    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'OK') {
      return data.results as GooglePlace[];
    } else {
      console.error('Google Places API error:', data.status, data.error_message);
      return [];
    }
  } catch (error) {
    console.error('Google Places search error:', error);
    return [];
  }
}

// Google Translate API Integration
export async function translateText(
  text: string,
  targetLanguage: string,
  sourceLanguage?: string
): Promise<{ translatedText: string; detectedSourceLanguage?: string } | null> {
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;

  if (!apiKey) {
    console.warn('Google Translate API key not configured');
    return null;
  }

  try {
    const params = new URLSearchParams({
      key: apiKey,
      q: text,
      target: targetLanguage,
      format: 'text'
    });

    if (sourceLanguage) {
      params.append('source', sourceLanguage);
    }

    const response = await fetch(
      `https://translation.googleapis.com/language/translate/v2?${params}`,
      { method: 'POST' }
    );

    const data = await response.json();

    if (data.data && data.data.translations && data.data.translations[0]) {
      const translation = data.data.translations[0];
      return {
        translatedText: translation.translatedText,
        detectedSourceLanguage: translation.detectedSourceLanguage
      };
    }

    return null;
  } catch (error) {
    console.error('Google Translate error:', error);
    return null;
  }
}

// Google Knowledge Graph API
export interface KnowledgeGraphEntity {
  '@type': string[];
  result: {
    '@id': string;
    name: string;
    '@type': string[];
    description: string;
    image?: {
      contentUrl: string;
      url: string;
    };
    detailedDescription?: {
      articleBody: string;
      url: string;
      license: string;
    };
    url?: string;
  };
  resultScore: number;
}

export async function searchKnowledgeGraph(query: string): Promise<KnowledgeGraphEntity[]> {
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;

  if (!apiKey) {
    console.warn('Google Knowledge Graph API key not configured');
    return [];
  }

  try {
    const params = new URLSearchParams({
      key: apiKey,
      query: query,
      limit: '10',
      indent: 'true'
    });

    const response = await fetch(
      `https://kgsearch.googleapis.com/v1/entities:search?${params}`
    );

    const data = await response.json();

    if (data.itemListElement) {
      return data.itemListElement as KnowledgeGraphEntity[];
    }

    return [];
  } catch (error) {
    console.error('Knowledge Graph search error:', error);
    return [];
  }
}

// YouTube Data API Integration
export interface YouTubeVideo {
  id: {
    videoId: string;
  };
  snippet: {
    title: string;
    description: string;
    channelTitle: string;
    publishedAt: string;
    thumbnails: {
      default: { url: string; width: number; height: number; };
      medium: { url: string; width: number; height: number; };
      high: { url: string; width: number; height: number; };
    };
  };
}

export async function searchYouTube(
  query: string, 
  options: { 
    maxResults?: number;
    order?: 'date' | 'rating' | 'relevance' | 'title' | 'videoCount' | 'viewCount';
    publishedAfter?: string;
    publishedBefore?: string;
    videoDuration?: 'any' | 'long' | 'medium' | 'short';
  } = {}
): Promise<YouTubeVideo[]> {
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;

  if (!apiKey) {
    console.warn('YouTube Data API key not configured');
    return [];
  }

  try {
    const params = new URLSearchParams({
      key: apiKey,
      part: 'snippet',
      type: 'video',
      q: query,
      maxResults: (options.maxResults || 10).toString(),
      order: options.order || 'relevance',
      ...Object.fromEntries(
        Object.entries(options).filter(([_, v]) => v !== undefined && v !== null)
      )
    });

    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/search?${params}`
    );

    const data = await response.json();

    if (data.items) {
      return data.items as YouTubeVideo[];
    }

    return [];
  } catch (error) {
    console.error('YouTube search error:', error);
    return [];
  }
}