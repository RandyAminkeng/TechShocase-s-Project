import { pgTable, text, serial, integer, boolean, timestamp, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  email: text("email"),
  bio: text("bio"),
  avatar: text("avatar"),
  role: text("role").notNull().default("student"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull().default("primary"),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").references(() => subjects.id),
  name: text("name").notNull(),
  description: text("description").notNull(),
  totalLessons: integer("total_lessons").notNull(),
  level: text("level").notNull(),
  imageUrl: text("image_url"),
});

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  order: integer("order").notNull(),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  courseId: integer("course_id").references(() => courses.id),
  completedLessons: integer("completed_lessons").notNull().default(0),
  progress: real("progress").notNull().default(0),
  lastActivity: timestamp("last_activity").notNull().defaultNow(),
});

export const userStats = pgTable("user_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  learningHours: real("learning_hours").notNull().default(0),
  completedLessons: integer("completed_lessons").notNull().default(0),
  streak: integer("streak").notNull().default(0),
  bestStreak: integer("best_streak").notNull().default(0),
  quizAverage: real("quiz_average").notNull().default(0),
});

export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").references(() => subjects.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  url: text("url").notNull(),
  imageUrl: text("image_url"),
  metadata: json("metadata"),
});

export const aiChatHistory = pgTable("ai_chat_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  subjectId: integer("subject_id").references(() => subjects.id),
  message: text("message").notNull(),
  response: text("response").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Mood and Motivation Tracking Tables
export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  moodScore: integer("mood_score").notNull(), // 1-10 scale
  energyLevel: integer("energy_level").notNull(), // 1-10 scale
  motivationLevel: integer("motivation_level").notNull(), // 1-10 scale
  stressLevel: integer("stress_level").notNull(), // 1-10 scale
  notes: text("notes"),
  tags: json("tags").$type<string[]>(),
  date: timestamp("date").notNull().defaultNow(),
  studySessionId: integer("study_session_id").references(() => studySessions.id),
});

export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  subjectId: integer("subject_id").references(() => subjects.id),
  duration: integer("duration").notNull(), // in minutes
  completedTasks: integer("completed_tasks").notNull().default(0),
  plannedTasks: integer("planned_tasks").notNull().default(0),
  focusScore: integer("focus_score"), // 1-10 scale
  productivityScore: integer("productivity_score"), // 1-10 scale
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  breaks: json("breaks").$type<{start: string, end: string, type: string}[]>().default([]),
  notes: text("notes"),
});

export const motivationGoals = pgTable("motivation_goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  targetValue: integer("target_value").notNull(),
  currentValue: integer("current_value").notNull().default(0),
  unit: text("unit").notNull(), // "hours", "lessons", "points", etc.
  category: text("category").notNull(), // "daily", "weekly", "monthly", "custom"
  deadline: timestamp("deadline"),
  isCompleted: boolean("is_completed").notNull().default(false),
  priority: text("priority").notNull().default("medium"), // "low", "medium", "high"
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const aiMotivationInsights = pgTable("ai_motivation_insights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  insightType: text("insight_type").notNull(), // "mood_pattern", "productivity_tip", "motivation_boost"
  content: text("content").notNull(),
  recommendations: json("recommendations").$type<string[]>().default([]),
  confidence: real("confidence").notNull(), // AI confidence score 0-1
  isRead: boolean("is_read").notNull().default(false),
  isHelpful: boolean("is_helpful"),
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const learningStreaks = pgTable("learning_streaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  lastStudyDate: timestamp("last_study_date"),
  streakType: text("streak_type").notNull().default("daily"), // "daily", "weekly"
  streakStartDate: timestamp("streak_start_date"),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertSubjectSchema = createInsertSchema(subjects).omit({
  id: true,
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
});

export const insertLessonSchema = createInsertSchema(lessons).omit({
  id: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
  lastActivity: true,
});

export const insertUserStatsSchema = createInsertSchema(userStats).omit({
  id: true,
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
});

export const insertAiChatHistorySchema = createInsertSchema(aiChatHistory).omit({
  id: true,
  timestamp: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  date: true,
});

export const insertStudySessionSchema = createInsertSchema(studySessions).omit({
  id: true,
});

export const insertMotivationGoalSchema = createInsertSchema(motivationGoals).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertAiMotivationInsightSchema = createInsertSchema(aiMotivationInsights).omit({
  id: true,
  generatedAt: true,
});

export const insertLearningStreakSchema = createInsertSchema(learningStreaks).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = z.infer<typeof insertLessonSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

export type AiChatHistory = typeof aiChatHistory.$inferSelect;
export type InsertAiChatHistory = z.infer<typeof insertAiChatHistorySchema>;

export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;

export type StudySession = typeof studySessions.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;

export type MotivationGoal = typeof motivationGoals.$inferSelect;
export type InsertMotivationGoal = z.infer<typeof insertMotivationGoalSchema>;

export type AiMotivationInsight = typeof aiMotivationInsights.$inferSelect;
export type InsertAiMotivationInsight = z.infer<typeof insertAiMotivationInsightSchema>;

export type LearningStreak = typeof learningStreaks.$inferSelect;
export type InsertLearningStreak = z.infer<typeof insertLearningStreakSchema>;
