interface SubjectButtonProps {
  name: string;
  icon: string;
  color: string;
  isSelected?: boolean;
  onClick: () => void;
}

const SubjectButton = ({ name, icon, color, isSelected = false, onClick }: SubjectButtonProps) => {
  const colorClasses = {
    primary: {
      bg: "bg-primary bg-opacity-10",
      text: "text-primary",
      hover: "hover:border-primary"
    },
    secondary: {
      bg: "bg-secondary bg-opacity-10",
      text: "text-secondary",
      hover: "hover:border-secondary"
    },
    accent: {
      bg: "bg-accent bg-opacity-10",
      text: "text-accent",
      hover: "hover:border-accent"
    },
    info: {
      bg: "bg-info bg-opacity-10",
      text: "text-info",
      hover: "hover:border-info"
    }
  };

  return (
    <button 
      className={`
        bg-white rounded-xl p-4 border transition-all flex flex-col items-center justify-center text-center gap-2 
        dark:bg-neutral-800 
        ${isSelected 
          ? `border-${color} shadow-md` 
          : 'border-neutral-200 dark:border-neutral-700 hover:shadow-md ' + colorClasses[color].hover
        }
      `}
      onClick={onClick}
    >
      <div className={`w-12 h-12 rounded-full ${colorClasses[color].bg} flex items-center justify-center`}>
        <span className={`material-icons ${colorClasses[color].text}`}>{icon}</span>
      </div>
      <span className="font-medium dark:text-white">{name}</span>
    </button>
  );
};

export default SubjectButton;
