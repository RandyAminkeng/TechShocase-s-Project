import { useState, useEffect } from 'react';

interface ChatMessageProps {
  isUser: boolean;
  content: string;
  isTyping?: boolean;
}

const ChatMessage = ({ isUser, content, isTyping = false }: ChatMessageProps) => {
  const [displayContent, setDisplayContent] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);

  // Simulates typing effect for AI responses
  useEffect(() => {
    if (isTyping && !isUser && currentIndex < content.length) {
      const timer = setTimeout(() => {
        setDisplayContent(prev => prev + content[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, 15); // Adjust speed as needed
      
      return () => clearTimeout(timer);
    }
  }, [isTyping, isUser, content, currentIndex]);

  // Reset when content changes
  useEffect(() => {
    if (!isTyping) {
      setDisplayContent(content);
      setCurrentIndex(content.length);
    } else if (isTyping && !isUser) {
      setDisplayContent('');
      setCurrentIndex(0);
    }
  }, [content, isTyping, isUser]);

  if (isUser) {
    return (
      <div className="flex max-w-3xl ml-auto">
        <div className="bg-primary text-white rounded-lg rounded-tr-none p-3 dark:bg-primary-dark">
          <p>{content}</p>
        </div>
        <div className="w-8 h-8 rounded-full bg-neutral-200 flex items-center justify-center ml-3 flex-shrink-0 mt-1 dark:bg-neutral-700">
          <span className="material-icons text-neutral-500 dark:text-neutral-400 text-sm">person</span>
        </div>
      </div>
    );
  }

  if (isTyping && displayContent === '') {
    return (
      <div className="flex max-w-3xl typing-indicator">
        <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3 flex-shrink-0 mt-1 dark:bg-primary-dark">
          <span className="material-icons text-primary text-sm dark:text-primary-light">smart_toy</span>
        </div>
        <div className="bg-neutral-100 rounded-lg rounded-tl-none p-3 dark:bg-neutral-700">
          <div className="flex space-x-2">
            <span className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500"></span>
            <span className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500"></span>
            <span className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500"></span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex max-w-3xl">
      <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3 flex-shrink-0 mt-1 dark:bg-primary-dark">
        <span className="material-icons text-primary text-sm dark:text-primary-light">smart_toy</span>
      </div>
      <div className="bg-neutral-100 rounded-lg rounded-tl-none p-3 dark:bg-neutral-700 dark:text-white">
        {isTyping ? (
          <p dangerouslySetInnerHTML={{ __html: displayContent.replace(/\n/g, '<br/>') }} />
        ) : (
          <div dangerouslySetInnerHTML={{ __html: content.replace(/\n/g, '<br/>') }} />
        )}
      </div>
    </div>
  );
};

export default ChatMessage;
