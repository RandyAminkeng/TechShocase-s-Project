import { Link } from "wouter";

interface CourseProgressCardProps {
  id: number;
  title: string;
  subject: string;
  icon: string;
  iconColor: string;
  lessonsCompleted: number;
  totalLessons: number;
  progress: number;
  lastActivity: string;
  quizzesPassed: number;
}

const CourseProgressCard = ({
  id,
  title,
  subject,
  icon,
  iconColor,
  lessonsCompleted,
  totalLessons,
  progress,
  lastActivity,
  quizzesPassed
}: CourseProgressCardProps) => {
  const colorClasses = {
    primary: {
      bg: "bg-primary bg-opacity-10",
      text: "text-primary",
      bar: "bg-primary",
      button: "text-primary"
    },
    secondary: {
      bg: "bg-secondary bg-opacity-10",
      text: "text-secondary",
      bar: "bg-secondary",
      button: "text-secondary"
    },
    accent: {
      bg: "bg-accent bg-opacity-10",
      text: "text-accent",
      bar: "bg-accent",
      button: "text-accent"
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 dark:bg-neutral-800 dark:border-neutral-700">
      <div className="flex items-start justify-between mb-4">
        <div className="flex">
          <div className={`w-12 h-12 rounded-lg ${colorClasses[iconColor].bg} flex items-center justify-center mr-4`}>
            <span className={`material-icons ${colorClasses[iconColor].text}`}>{icon}</span>
          </div>
          <div>
            <h4 className="font-medium dark:text-white">{title}</h4>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">{subject} • {totalLessons} lessons</p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-medium dark:text-white">{progress}%</p>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">Last activity: {lastActivity}</p>
        </div>
      </div>
      
      <div className="w-full bg-neutral-200 rounded-full h-2 mb-4 dark:bg-neutral-700">
        <div 
          className={`${colorClasses[iconColor].bar} h-2 rounded-full`} 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      
      <div className="flex flex-wrap justify-between gap-y-2">
        <div className="flex items-center">
          <span className="material-icons text-success text-sm mr-1">check_circle</span>
          <span className="text-sm dark:text-neutral-300">{lessonsCompleted} lessons completed</span>
        </div>
        <div className="flex items-center">
          <span className="material-icons text-neutral-400 text-sm mr-1 dark:text-neutral-500">pending</span>
          <span className="text-sm dark:text-neutral-300">{totalLessons - lessonsCompleted} lessons remaining</span>
        </div>
        <div className="flex items-center">
          <span className="material-icons text-secondary text-sm mr-1">emoji_events</span>
          <span className="text-sm dark:text-neutral-300">{quizzesPassed} quizzes passed</span>
        </div>
        <Link href={`/courses/${id}`}>
          <a className={`${colorClasses[iconColor].button} text-sm font-medium flex items-center dark:text-primary-light`}>
            Continue Learning
            <span className="material-icons text-sm ml-1">arrow_forward</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default CourseProgressCard;
