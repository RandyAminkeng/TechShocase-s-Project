interface ProgressCardProps {
  icon: string;
  iconColor: string;
  title: string;
  value: number | string;
  total?: number;
  unit?: string;
  percentage: number;
}

const ProgressCard = ({ 
  icon, 
  iconColor, 
  title, 
  value, 
  total, 
  unit = "", 
  percentage 
}: ProgressCardProps) => {
  const colorClasses = {
    primary: {
      bg: "bg-primary bg-opacity-10",
      text: "text-primary",
      bar: "bg-primary"
    },
    secondary: {
      bg: "bg-secondary bg-opacity-10",
      text: "text-secondary",
      bar: "bg-secondary"
    },
    accent: {
      bg: "bg-accent bg-opacity-10",
      text: "text-accent",
      bar: "bg-accent"
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-200 dark:bg-neutral-800 dark:border-neutral-700">
      <div className="flex items-center mb-4">
        <div className={`w-10 h-10 rounded-full ${colorClasses[iconColor].bg} flex items-center justify-center mr-3`}>
          <span className={`material-icons ${colorClasses[iconColor].text}`}>{icon}</span>
        </div>
        <div>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">{title}</p>
          <h3 className="text-2xl font-bold dark:text-white">{value}{unit}</h3>
        </div>
      </div>
      <div className="w-full bg-neutral-200 rounded-full h-2 mb-2 dark:bg-neutral-700">
        <div 
          className={`${colorClasses[iconColor].bar} h-2 rounded-full`} 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      <p className="text-xs text-neutral-500 dark:text-neutral-400">
        {total ? `${value} of ${total} ${unit}` : ''} ({percentage}%)
      </p>
    </div>
  );
};

export default ProgressCard;
