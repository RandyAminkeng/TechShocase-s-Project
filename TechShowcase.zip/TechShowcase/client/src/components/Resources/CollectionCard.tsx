import { Link } from "wouter";

interface Resource {
  title: string;
  type: string;
  duration?: string;
  pages?: number;
  items?: number;
}

interface CollectionCardProps {
  id: number;
  title: string;
  subjectName: string;
  icon: string;
  color: string;
  resourceCount: number;
  updateFrequency: string;
  resources: Resource[];
}

const CollectionCard = ({
  id,
  title,
  subjectName,
  icon,
  color,
  resourceCount,
  updateFrequency,
  resources
}: CollectionCardProps) => {
  const colorClasses = {
    primary: {
      bg: "bg-primary bg-opacity-10",
      text: "text-primary",
      button: "bg-primary bg-opacity-10 text-primary hover:bg-opacity-20"
    },
    secondary: {
      bg: "bg-secondary bg-opacity-10",
      text: "text-secondary",
      button: "bg-secondary bg-opacity-10 text-secondary hover:bg-opacity-20"
    },
    accent: {
      bg: "bg-accent bg-opacity-10",
      text: "text-accent",
      button: "bg-accent bg-opacity-10 text-accent hover:bg-opacity-20"
    }
  };

  const typeToIcon = {
    "Video": "play_circle",
    "PDF": "description",
    "Interactive": "extension",
    "Quiz": "quiz",
    "Practice": "assignment"
  };

  const getResourceDetails = (resource: Resource) => {
    if (resource.duration) return resource.duration;
    if (resource.pages) return `${resource.pages} pages`;
    if (resource.items) return `${resource.items} items`;
    return "";
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden dark:bg-neutral-800 dark:border-neutral-700">
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className={`w-12 h-12 rounded-lg ${colorClasses[color].bg} flex items-center justify-center mr-4`}>
            <span className={`material-icons ${colorClasses[color].text}`}>{icon}</span>
          </div>
          <div>
            <h4 className="font-medium dark:text-white">{title}</h4>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">
              {resourceCount} resources • {updateFrequency}
            </p>
          </div>
        </div>
        
        <div className="space-y-3 mb-4">
          {resources.slice(0, 3).map((resource, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="material-icons text-neutral-400 mr-2 dark:text-neutral-500">
                  {typeToIcon[resource.type] || "article"}
                </span>
                <span className="text-sm dark:text-neutral-300">{resource.title}</span>
              </div>
              <span className="text-xs text-neutral-500 dark:text-neutral-400">
                {getResourceDetails(resource)}
              </span>
            </div>
          ))}
        </div>
        
        <Link href={`/collections/${id}`}>
          <a className={`w-full ${colorClasses[color].button} py-2 rounded-lg flex items-center justify-center transition-colors`}>
            View Collection
            <span className="material-icons text-sm ml-1">arrow_forward</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default CollectionCard;
