import { Link } from "wouter";

interface ResourceItemProps {
  id: number;
  title: string;
  description: string;
  type: string;
  subjectName: string;
  subjectColor: string;
  imageUrl: string;
  metadata?: {
    duration?: string;
    pages?: number;
    items?: number;
  };
}

const ResourceItem = ({
  id,
  title,
  description,
  type,
  subjectName,
  subjectColor,
  imageUrl,
  metadata
}: ResourceItemProps) => {
  const colorClasses = {
    primary: "bg-primary bg-opacity-10 text-primary",
    secondary: "bg-secondary bg-opacity-10 text-secondary",
    accent: "bg-accent bg-opacity-10 text-accent"
  };

  const typeToAction = {
    "Video": "View",
    "PDF": "Download",
    "Interactive": "Practice",
    "Quiz": "Start Quiz",
    "Practice": "Practice"
  };

  const typeToIcon = {
    "Video": "play_circle",
    "PDF": "description",
    "Interactive": "extension",
    "Quiz": "quiz",
    "Practice": "assignment"
  };

  const action = typeToAction[type] || "View";
  const icon = typeToIcon[type] || "description";

  const getMetadataText = () => {
    if (!metadata) return "";
    if (metadata.duration) return metadata.duration;
    if (metadata.pages) return `${metadata.pages} pages`;
    if (metadata.items) return `${metadata.items} items`;
    return "";
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden dark:bg-neutral-800 dark:border-neutral-700">
      <img 
        src={imageUrl} 
        alt={title} 
        className="w-full h-36 object-cover"
      />
      <div className="p-4">
        <span className={`inline-block px-2 py-1 rounded-full text-xs ${colorClasses[subjectColor]} mb-2`}>
          {subjectName}
        </span>
        <div className="flex items-center justify-between mb-2">
          <h4 className="font-medium dark:text-white">{title}</h4>
          <span className="bg-neutral-100 px-2 py-1 rounded text-xs dark:bg-neutral-700 dark:text-neutral-300">{type}</span>
        </div>
        <p className="text-sm text-neutral-500 mb-3 dark:text-neutral-400">{description}</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center text-xs text-neutral-500 dark:text-neutral-400">
            <span className="material-icons text-xs mr-1">{icon}</span>
            <span>{getMetadataText()}</span>
          </div>
          <Link href={`/resources/${id}`}>
            <a className="text-primary text-sm font-medium flex items-center dark:text-primary-light">
              {action}
              <span className="material-icons text-sm ml-1">chevron_right</span>
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ResourceItem;
