import { useEffect, useRef, useState } from 'react';

declare global {
  interface Window {
    google: any;
  }
}
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Navigation, Search } from 'lucide-react';

interface Place {
  place_id: string;
  name: string;
  formatted_address: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  rating?: number;
  user_ratings_total?: number;
  types: string[];
}

interface GoogleMapsProps {
  query?: string;
  showSearch?: boolean;
}

export default function GoogleMaps({ query = '', showSearch = true }: GoogleMapsProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [searchQuery, setSearchQuery] = useState(query);
  const [places, setPlaces] = useState<Place[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Get user's current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.warn('Geolocation error:', error);
          // Default to New York City
          setUserLocation({ lat: 40.7128, lng: -74.0060 });
        }
      );
    } else {
      setUserLocation({ lat: 40.7128, lng: -74.0060 });
    }
  }, []);

  // Search for places
  const searchPlaces = async (searchTerm: string) => {
    if (!searchTerm.trim()) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/google/places', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: searchTerm,
          location: userLocation
        })
      });

      if (response.ok) {
        const data = await response.json();
        setPlaces(data.places || []);
      }
    } catch (error) {
      console.error('Places search error:', error);
    }
    setIsLoading(false);
  };

  // Initialize Google Maps
  useEffect(() => {
    if (!mapRef.current || !userLocation) return;

    const initMap = () => {
      const map = new window.google.maps.Map(mapRef.current!, {
        center: userLocation,
        zoom: 13,
        styles: [
          {
            featureType: 'poi',
            elementType: 'labels',
            stylers: [{ visibility: 'on' }]
          }
        ]
      });

      // Add markers for places
      places.forEach((place) => {
        const marker = new window.google.maps.Marker({
          position: place.geometry.location,
          map: map,
          title: place.name,
          icon: {
            url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
            scaledSize: new window.google.maps.Size(32, 32)
          }
        });

        const infoWindow = new window.google.maps.InfoWindow({
          content: `
            <div style="padding: 8px; max-width: 200px;">
              <h3 style="margin: 0 0 4px 0; font-size: 14px; font-weight: bold;">${place.name}</h3>
              <p style="margin: 0 0 4px 0; font-size: 12px; color: #666;">${place.formatted_address}</p>
              ${place.rating ? `<p style="margin: 0; font-size: 12px;">★ ${place.rating} (${place.user_ratings_total || 0} reviews)</p>` : ''}
            </div>
          `
        });

        marker.addListener('click', () => {
          infoWindow.open(map, marker);
        });
      });

      // Add user location marker
      new window.google.maps.Marker({
        position: userLocation,
        map: map,
        title: 'Your Location',
        icon: {
          url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png',
          scaledSize: new window.google.maps.Size(32, 32)
        }
      });
    };

    // Load Google Maps API if not already loaded
    if (typeof window.google === 'undefined') {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}&libraries=places`;
      script.onload = initMap;
      document.head.appendChild(script);
    } else {
      initMap();
    }
  }, [userLocation, places]);

  // Search on initial query
  useEffect(() => {
    if (query && userLocation) {
      searchPlaces(query);
    }
  }, [query, userLocation]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    searchPlaces(searchQuery);
  };

  return (
    <div className="space-y-4">
      {showSearch && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Google Maps Search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="flex gap-2">
              <Input
                type="text"
                placeholder="Search for places, restaurants, schools..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" disabled={isLoading}>
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-0">
          <div 
            ref={mapRef} 
            className="w-full h-96 rounded-lg"
            style={{ minHeight: '400px' }}
          />
        </CardContent>
      </Card>

      {places.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Search Results ({places.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {places.map((place) => (
                <div key={place.place_id} className="flex items-start justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium text-sm">{place.name}</h3>
                    <p className="text-xs text-gray-600 mt-1">{place.formatted_address}</p>
                    {place.rating && (
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-yellow-500">★</span>
                        <span className="text-xs">{place.rating}</span>
                        {place.user_ratings_total && (
                          <span className="text-xs text-gray-500">({place.user_ratings_total})</span>
                        )}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {place.types.slice(0, 3).map((type) => (
                        <span key={type} className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {type.replace(/_/g, ' ')}
                        </span>
                      ))}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      window.open(
                        `https://www.google.com/maps/place/?q=place_id:${place.place_id}`,
                        '_blank'
                      );
                    }}
                  >
                    <Navigation className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}