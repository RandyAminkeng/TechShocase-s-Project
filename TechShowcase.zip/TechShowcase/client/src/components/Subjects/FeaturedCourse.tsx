import { Link } from "wouter";

interface FeaturedCourseProps {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  duration: string;
  level: string;
  enrolledCount: number;
  tags: string[];
  isNew?: boolean;
  isPopular?: boolean;
}

const FeaturedCourse = ({
  id,
  title,
  description,
  imageUrl,
  duration,
  level,
  enrolledCount,
  tags,
  isNew = false,
  isPopular = false
}: FeaturedCourseProps) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden dark:bg-neutral-800 dark:border-neutral-700">
      <div className="md:flex">
        <div className="md:w-2/5">
          <img 
            src={imageUrl} 
            alt={title} 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="p-6 md:w-3/5">
          <div className="flex items-center mb-4">
            {isNew && (
              <span className="px-2 py-1 text-xs rounded-full bg-primary text-white mr-2 dark:bg-primary-dark">New</span>
            )}
            {isPopular && (
              <span className="px-2 py-1 text-xs rounded-full bg-secondary bg-opacity-10 text-secondary dark:bg-secondary-dark dark:text-secondary-light">Popular</span>
            )}
          </div>
          
          <h3 className="font-heading text-xl font-semibold mb-2 dark:text-white">{title}</h3>
          <p className="text-neutral-500 mb-4 dark:text-neutral-400">{description}</p>
          
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex items-center">
              <span className="material-icons text-neutral-400 mr-1 text-sm dark:text-neutral-500">schedule</span>
              <span className="text-sm dark:text-neutral-300">{duration}</span>
            </div>
            <div className="flex items-center">
              <span className="material-icons text-neutral-400 mr-1 text-sm dark:text-neutral-500">signal_cellular_alt</span>
              <span className="text-sm dark:text-neutral-300">{level}</span>
            </div>
            <div className="flex items-center">
              <span className="material-icons text-neutral-400 mr-1 text-sm dark:text-neutral-500">people</span>
              <span className="text-sm dark:text-neutral-300">{enrolledCount.toLocaleString()} enrolled</span>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-6">
            {tags.map((tag, index) => (
              <span key={index} className="px-3 py-1 text-sm rounded-full bg-neutral-100 dark:bg-neutral-700 dark:text-neutral-300">
                {tag}
              </span>
            ))}
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <Link href={`/courses/${id}`}>
              <a className="bg-primary text-white py-2 px-6 rounded-lg flex items-center justify-center hover:bg-primary-dark transition-colors">
                <span className="material-icons text-sm mr-2">play_arrow</span>
                Start Learning
              </a>
            </Link>
            <Link href={`/courses/${id}/details`}>
              <a className="border border-primary text-primary py-2 px-6 rounded-lg flex items-center justify-center hover:bg-primary hover:bg-opacity-5 transition-colors dark:text-primary-light dark:border-primary-light">
                <span className="material-icons text-sm mr-2">info</span>
                View Details
              </a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeaturedCourse;
