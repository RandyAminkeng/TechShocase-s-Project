import { Link } from "wouter";

interface SubjectCardProps {
  id: number;
  name: string;
  icon: string;
  color: string;
  courseCount: number;
  courses: {
    name: string;
  }[];
}

const SubjectCard = ({ id, name, icon, color, courseCount, courses }: SubjectCardProps) => {
  const colorClasses = {
    primary: {
      bar: "bg-primary",
      iconBg: "bg-primary bg-opacity-10",
      icon: "text-primary",
      button: "text-primary"
    },
    secondary: {
      bar: "bg-secondary",
      iconBg: "bg-secondary bg-opacity-10",
      icon: "text-secondary",
      button: "text-secondary"
    },
    accent: {
      bar: "bg-accent",
      iconBg: "bg-accent bg-opacity-10",
      icon: "text-accent",
      button: "text-accent"
    },
    info: {
      bar: "bg-info",
      iconBg: "bg-info bg-opacity-10",
      icon: "text-info",
      button: "text-info"
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden dark:bg-neutral-800 dark:border-neutral-700">
      <div className={`h-2 ${colorClasses[color].bar} w-full`}></div>
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className={`w-12 h-12 rounded-lg ${colorClasses[color].iconBg} flex items-center justify-center mr-4`}>
            <span className={`material-icons ${colorClasses[color].icon}`}>{icon}</span>
          </div>
          <div>
            <h3 className="font-heading font-semibold text-lg dark:text-white">{name}</h3>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">{courseCount} courses available</p>
          </div>
        </div>
        
        <ul className="space-y-3 mb-4">
          {courses.slice(0, 4).map((course, index) => (
            <li key={index} className="flex items-center text-sm dark:text-neutral-300">
              <span className="material-icons text-sm mr-2 text-neutral-400 dark:text-neutral-500">arrow_right</span>
              <span>{course.name}</span>
            </li>
          ))}
        </ul>
        
        <Link href={`/subjects/${id}`}>
          <a className={`${colorClasses[color].button} text-sm font-medium flex items-center`}>
            Explore all {name.toLowerCase()} courses
            <span className="material-icons text-sm ml-1">chevron_right</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default SubjectCard;
