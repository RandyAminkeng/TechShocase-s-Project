interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  icon: string;
  iconColor: "primary" | "secondary" | "accent";
}

const StatCard = ({ title, value, change, icon, iconColor }: StatCardProps) => {
  const colorClasses = {
    primary: "bg-primary bg-opacity-10 text-primary",
    secondary: "bg-secondary bg-opacity-10 text-secondary",
    accent: "bg-accent bg-opacity-10 text-accent"
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-200 dark:bg-neutral-800 dark:border-neutral-700">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-neutral-500 text-sm mb-1 dark:text-neutral-400">{title}</p>
          <h3 className="text-2xl font-bold text-neutral-800 dark:text-white">{value}</h3>
          {change && (
            <p className="text-accent text-sm flex items-center mt-1 dark:text-accent-light">
              <span className="material-icons text-sm mr-1">arrow_upward</span>
              <span>{change}</span>
            </p>
          )}
        </div>
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${colorClasses[iconColor]}`}>
          <span className="material-icons">{icon}</span>
        </div>
      </div>
    </div>
  );
};

export default StatCard;
