import { useState } from "react";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { askTutorQuestion } from "@/lib/api";
import { toast } from "@/hooks/use-toast";

const AiTutorCard = () => {
  const [question, setQuestion] = useState("");
  
  const mutation = useMutation({
    mutationFn: askTutorQuestion,
    onSuccess: (data) => {
      toast({
        title: "Question sent!",
        description: data.answer,
      });
      setQuestion("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "There was a problem processing your question. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    
    // Using default subject and user for demo
    mutation.mutate({
      userId: 1,
      subjectId: 1,
      question
    });
  };

  const quickQuestions = [
    "Help with math problem",
    "Explain scientific concept",
    "Grammar check"
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 dark:bg-neutral-800 dark:border-neutral-700">
      <div className="flex items-center mb-6">
        <div className="w-12 h-12 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-4 dark:bg-primary-dark">
          <span className="material-icons text-primary text-2xl">smart_toy</span>
        </div>
        <div>
          <h4 className="font-medium text-lg dark:text-white">Ask your AI tutor a question</h4>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Get instant help with any topic</p>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="mb-4">
        <div className="relative">
          <input 
            type="text" 
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            className="w-full px-4 py-3 pr-12 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary dark:bg-neutral-700 dark:border-neutral-600 dark:text-white" 
            placeholder="E.g., Explain photosynthesis in simple terms"
          />
          <button 
            type="submit"
            disabled={mutation.isPending || !question.trim()}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-primary dark:text-primary-light disabled:text-neutral-300 dark:disabled:text-neutral-500"
          >
            <span className="material-icons">{mutation.isPending ? "hourglass_empty" : "send"}</span>
          </button>
        </div>
      </form>
      
      <div className="flex flex-wrap gap-2">
        {quickQuestions.map((q, index) => (
          <button 
            key={index}
            onClick={() => setQuestion(q)}
            className="bg-neutral-100 hover:bg-neutral-200 transition-colors px-3 py-1.5 rounded-full text-sm text-neutral-700 dark:bg-neutral-700 dark:text-neutral-200 dark:hover:bg-neutral-600"
          >
            {q}
          </button>
        ))}
      </div>
      
      <div className="mt-4 text-right">
        <Link href="/ai-tutor">
          <a className="text-primary text-sm font-medium flex items-center justify-end dark:text-primary-light">
            Full mode
            <span className="material-icons text-sm ml-1">chevron_right</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default AiTutorCard;
