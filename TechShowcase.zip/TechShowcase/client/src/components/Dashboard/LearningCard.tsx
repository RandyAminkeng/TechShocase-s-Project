import { Link } from "wouter";

interface LearningCardProps {
  id: number;
  title: string;
  subject: string;
  progress: number;
  icon: string;
  color: "primary" | "secondary" | "accent";
}

const LearningCard = ({ id, title, subject, progress, icon, color }: LearningCardProps) => {
  const colorClasses = {
    primary: {
      bar: "bg-primary",
      iconBg: "bg-primary bg-opacity-10",
      icon: "text-primary",
      button: "bg-primary text-white hover:bg-primary-dark"
    },
    secondary: {
      bar: "bg-secondary",
      iconBg: "bg-secondary bg-opacity-10",
      icon: "text-secondary",
      button: "bg-secondary text-white hover:bg-secondary-dark"
    },
    accent: {
      bar: "bg-accent",
      iconBg: "bg-accent bg-opacity-10",
      icon: "text-accent",
      button: "bg-accent text-white hover:bg-accent-dark"
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden dark:bg-neutral-800 dark:border-neutral-700">
      <div className={`h-3 w-full ${colorClasses[color].bar}`}></div>
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 ${colorClasses[color].iconBg}`}>
            <span className={`material-icons ${colorClasses[color].icon}`}>{icon}</span>
          </div>
          <div>
            <h4 className="font-medium dark:text-white">{title}</h4>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">{subject}</p>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm text-neutral-600 dark:text-neutral-300">Progress</span>
            <span className="text-sm font-medium text-neutral-700 dark:text-neutral-200">{progress}%</span>
          </div>
          <div className="w-full bg-neutral-200 rounded-full h-2 dark:bg-neutral-700">
            <div className={`${colorClasses[color].bar} h-2 rounded-full`} style={{ width: `${progress}%` }}></div>
          </div>
        </div>
        
        <Link href={`/courses/${id}`}>
          <a className={`${colorClasses[color].button} py-2 px-4 rounded-lg w-full flex items-center justify-center transition-colors`}>
            <span className="material-icons text-sm mr-2">play_arrow</span>
            Continue
          </a>
        </Link>
      </div>
    </div>
  );
};

export default LearningCard;
