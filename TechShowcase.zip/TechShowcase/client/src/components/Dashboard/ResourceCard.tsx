import { Link } from "wouter";

interface ResourceCardProps {
  id: number;
  title: string;
  description: string;
  subject: string;
  subjectColor: string;
  imageUrl: string;
}

const ResourceCard = ({ 
  id, 
  title, 
  description, 
  subject, 
  subjectColor, 
  imageUrl 
}: ResourceCardProps) => {
  const colorClasses = {
    primary: "bg-primary bg-opacity-10 text-primary",
    secondary: "bg-secondary bg-opacity-10 text-secondary",
    accent: "bg-accent bg-opacity-10 text-accent",
    info: "bg-info bg-opacity-10 text-info"
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden dark:bg-neutral-800 dark:border-neutral-700">
      <img 
        src={imageUrl} 
        alt={title} 
        className="w-full h-36 object-cover"
      />
      <div className="p-4">
        <span className={`inline-block px-2 py-1 rounded-full text-xs ${colorClasses[subjectColor]} mb-2`}>
          {subject}
        </span>
        <h4 className="font-medium mb-1 dark:text-white">{title}</h4>
        <p className="text-sm text-neutral-500 mb-3 dark:text-neutral-400">{description}</p>
        <Link href={`/resources/${id}`}>
          <a className="text-primary text-sm font-medium flex items-center dark:text-primary-light">
            View resource
            <span className="material-icons text-sm ml-1">chevron_right</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default ResourceCard;
