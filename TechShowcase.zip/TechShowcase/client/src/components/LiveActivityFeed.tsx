import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Activity {
  id: string;
  type: string;
  message: string;
  timestamp: string;
  userId?: number;
  icon: string;
  color: string;
}

export default function LiveActivityFeed() {
  const { data: rawActivities = [], isLoading } = useQuery({
    queryKey: ['/api/live/activities'],
    refetchInterval: 3000, // Refresh every 3 seconds for live updates
    staleTime: 0
  });

  const activities = Array.isArray(rawActivities) ? rawActivities : [];

  // Add initial demo activities on first load
  useEffect(() => {
    const addInitialActivities = async () => {
      const demoActivities = [
        {
          type: 'user_online',
          message: 'Randy came online',
          userId: 1,
          icon: 'person',
          color: 'text-green-600'
        },
        {
          type: 'progress',
          message: 'Progress updated to 85% in Advanced Algebra',
          userId: 1,
          icon: 'trending_up',
          color: 'text-blue-600'
        },
        {
          type: 'tutor',
          message: 'AI Tutor session started for Mathematics',
          userId: 1,
          icon: 'psychology',
          color: 'text-purple-600'
        }
      ];

      for (const activity of demoActivities) {
        await fetch('/api/live/activity', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(activity)
        });
      }
    };

    // Only add demo activities if none exist
    if (activities.length === 0) {
      addInitialActivities();
    }
  }, [activities.length]);

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Live Activity</CardTitle>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${!isLoading ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
            <span className="text-xs text-neutral-500 dark:text-neutral-400">
              {!isLoading ? 'Live' : 'Updating...'}
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {activities.length > 0 ? (
            activities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors">
                <div className={`mt-1 ${activity.color}`}>
                  <span className="material-icons text-sm">{activity.icon}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-neutral-800 dark:text-neutral-200 leading-relaxed">
                    {activity.message}
                  </p>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                    {formatTime(activity.timestamp)}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-neutral-500 dark:text-neutral-400">
              <span className="material-icons text-2xl mb-2 block">activity_zone</span>
              <p className="text-sm">Waiting for live updates...</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}