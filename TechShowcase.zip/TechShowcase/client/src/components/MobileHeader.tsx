import { Button } from "@/components/ui/button";
import { Menu, Search, MessageCircle, Brain, Calculator, Atom } from "lucide-react";
import { Link } from "wouter";

interface MobileHeaderProps {
  toggleSidebar: () => void;
}

const MobileHeader = ({ toggleSidebar }: MobileHeaderProps) => {
  return (
    <header className="md:hidden bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-4 py-3">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
            <Brain className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-gray-900 dark:text-white">EduAI Pro</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">Advanced Learning</p>
          </div>
        </div>
        
        <Button
          variant="ghost"
          size="lg"
          onClick={toggleSidebar}
          className="p-3 hover:bg-gray-100 dark:hover:bg-gray-800 min-h-[48px] min-w-[48px]"
        >
          <Menu className="h-6 w-6" />
        </Button>
      </div>

      {/* Touch-Friendly Quick Access */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        <Link href="/search">
          <Button variant="outline" size="sm" className="flex items-center space-x-2 whitespace-nowrap px-4 py-3 min-h-[48px] text-sm font-medium">
            <Search className="h-4 w-4" />
            <span>Search</span>
          </Button>
        </Link>
        <Link href="/chatgpt">
          <Button variant="outline" size="sm" className="flex items-center space-x-2 whitespace-nowrap px-4 py-3 min-h-[48px] text-sm font-medium">
            <MessageCircle className="h-4 w-4" />
            <span>ChatGPT</span>
          </Button>
        </Link>
        <Link href="/mathematics">
          <Button variant="outline" size="sm" className="flex items-center space-x-2 whitespace-nowrap px-4 py-3 min-h-[48px] text-sm font-medium">
            <Calculator className="h-4 w-4" />
            <span>Math</span>
          </Button>
        </Link>
        <Link href="/science">
          <Button variant="outline" size="sm" className="flex items-center space-x-2 whitespace-nowrap px-4 py-3 min-h-[48px] text-sm font-medium">
            <Atom className="h-4 w-4" />
            <span>Science</span>
          </Button>
        </Link>
      </div>
    </header>
  );
};

export default MobileHeader;
