import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { 
  Home, 
  BookOpen, 
  BarChart3, 
  Menu,
  Search,
  MessageCircle,
  Palette,
  Globe,
  Brain,
  Calculator,
  Beaker,
  Trophy,
  Clock,
  Lightbulb,
  Atom,
  History,
  Feather,
  Languages,
  Heart,
  Scale,
  Microscope,
  Music,
  DollarSign,
  Briefcase,
  Computer,
  TreePine,
  Camera,
  ChevronDown,
  ChevronRight,
  Settings as SettingsIcon
} from "lucide-react";

const mainNavigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Search", href: "/search", icon: Search },
  { name: "ChatGPT", href: "/chatgpt", icon: MessageCircle },
  { name: "Whiteboard", href: "/whiteboard", icon: Palette },
  { name: "AI Tutor", href: "/tutor", icon: Lightbulb },
  { name: "Study Buddy", href: "/study-buddy", icon: Heart },
  { name: "Mood Tracker", href: "/mood-tracker", icon: Heart },
  { name: "Settings", href: "/settings", icon: SettingsIcon },
];

const subjects = [
  { name: "Mathematics", href: "/mathematics", icon: Calculator },
  { name: "Science", href: "/science", icon: Atom },
  { name: "Physics", href: "/physics", icon: Atom },
  { name: "Chemistry", href: "/chemistry", icon: Beaker },
  { name: "History", href: "/history", icon: History },
  { name: "Literature", href: "/literature", icon: Feather },
  { name: "Languages", href: "/languages", icon: Languages },
  { name: "Psychology", href: "/psychology", icon: Brain },
  { name: "Philosophy", href: "/philosophy", icon: Scale },
  { name: "Biology", href: "/biology", icon: Microscope },
  { name: "Music", href: "/music", icon: Music },
  { name: "Economics", href: "/economics", icon: DollarSign },
  { name: "Business", href: "/business", icon: Briefcase },
  { name: "Computer Science", href: "/computer-science", icon: Computer },
  { name: "Environmental Science", href: "/environmental", icon: TreePine },
  { name: "Art & Design", href: "/art", icon: Camera }
];

const tools = [
  { name: "Progress", href: "/progress", icon: BarChart3 },
  { name: "Resources", href: "/resources", icon: BookOpen },
  { name: "Quiz Center", href: "/quiz", icon: Trophy },
  { name: "Study Timer", href: "/timer", icon: Clock },
  { name: "Science Labs", href: "/labs", icon: Beaker }
];

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

interface NavigationSectionProps {
  title: string;
  items: Array<{ name: string; href: string; icon: any }>;
  location: string;
}

function NavigationSection({ title, items, location }: NavigationSectionProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="py-2">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full justify-between px-3 py-2 h-auto font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
      >
        <span className="text-sm font-semibold">{title}</span>
        {isExpanded ? (
          <ChevronDown className="h-4 w-4" />
        ) : (
          <ChevronRight className="h-4 w-4" />
        )}
      </Button>
      
      {isExpanded && (
        <div className="space-y-1 mt-1">
          {items.map((item) => {
            const IconComponent = item.icon;
            const isActive = location === item.href;
            
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  size="sm"
                  className={cn(
                    "w-full justify-start px-4 py-2 h-auto font-medium",
                    isActive 
                      ? "bg-blue-100 text-blue-900 dark:bg-blue-900 dark:text-blue-100 border-l-4 border-blue-500" 
                      : "text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-100"
                  )}
                >
                  <IconComponent className="mr-3 h-4 w-4" />
                  <span className="text-sm">{item.name}</span>
                </Button>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

function SidebarContent({ location }: { location: string }) {
  return (
    <div className="h-full flex flex-col bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800">
      {/* Logo Area */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
            <Brain className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-xl text-gray-900 dark:text-white">EduAI Pro</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">Advanced Learning Platform</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <ScrollArea className="flex-1 px-3">
        <div className="py-2">
          <NavigationSection 
            title="Main Features" 
            items={mainNavigation} 
            location={location} 
          />
          
          <Separator className="my-3" />
          
          <NavigationSection 
            title="Academic Subjects" 
            items={subjects} 
            location={location} 
          />
          
          <Separator className="my-3" />
          
          <NavigationSection 
            title="Learning Tools" 
            items={tools} 
            location={location} 
          />
        </div>
      </ScrollArea>
      
      {/* User Info */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-800">
        <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
            <span className="text-white text-sm font-medium">U</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 dark:text-white truncate">Student</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">Learning Mode</p>
          </div>
        </div>
      </div>
    </div>
  );
}

const Sidebar = ({ isOpen, onToggle }: SidebarProps) => {
  const [location] = useLocation();

  return (
    <>
      {/* Desktop Sidebar */}
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-72 transition-transform duration-300 ease-in-out md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <SidebarContent location={location} />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={isOpen} onOpenChange={onToggle}>
        <SheetContent side="left" className="p-0 w-72">
          <SidebarContent location={location} />
        </SheetContent>
      </Sheet>

      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-30 bg-black bg-opacity-50 md:hidden"
          onClick={onToggle}
        />
      )}
    </>
  );
};

export default Sidebar;