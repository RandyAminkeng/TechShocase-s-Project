import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'wouter';
import { Search as SearchIcon, Mic, Camera, Image, Video, ShoppingBag, Newspaper, MessageSquare, MoreHorizontal, Clock, TrendingUp, Globe, Filter, MapPin, Calendar, Star, ThumbsUp, ExternalLink, Brain } from 'lucide-react';

interface SearchResult {
  id: string;
  title: string;
  url: string;
  snippet: string;
  type: 'web' | 'image' | 'news' | 'video';
  favicon?: string;
  publishedDate?: string;
  domain: string;
  definition?: string;
  content?: string;
  keyFacts?: string[];
}

export default function Search() {
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'images' | 'videos' | 'shopping' | 'news' | 'forums' | 'more'>('all');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [timeFilter, setTimeFilter] = useState('any');
  const [regionFilter, setRegionFilter] = useState('all');
  const [languageFilter, setLanguageFilter] = useState('any');
  const [safeSearch, setSafeSearch] = useState('moderate');
  const [showFilters, setShowFilters] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Voice search setup
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';
      
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setQuery(transcript);
        setIsListening(false);
        if (transcript.trim()) {
          searchMutation.mutate(transcript.trim());
        }
      };
      
      recognitionRef.current.onerror = () => {
        setIsListening(false);
      };
      
      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  // Real-time search suggestions
  const suggestionsQuery = useQuery({
    queryKey: ['/api/search/suggestions', query],
    enabled: query.length > 2 && showSuggestions,
    staleTime: 30000,
    queryFn: async () => {
      const response = await fetch(`/api/search/suggestions?q=${encodeURIComponent(query)}`);
      return response.json();
    }
  });

  useEffect(() => {
    if (suggestionsQuery.data?.suggestions) {
      setSuggestions(suggestionsQuery.data.suggestions);
    }
  }, [suggestionsQuery.data]);

  const searchMutation = useMutation({
    mutationFn: async (searchQuery: string) => {
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          query: searchQuery, 
          type: activeTab,
          timeFilter,
          regionFilter,
          languageFilter,
          safeSearch
        })
      });
      if (!response.ok) {
        throw new Error('Search failed');
      }
      return response.json();
    },
    onSuccess: (data) => {
      setSearchResults(data.results || []);
      setHasSearched(true);
      setShowSuggestions(false);
    },
    onError: (error) => {
      console.error('Search error:', error);
      setSearchResults([]);
      setHasSearched(true);
    }
  });

  const handleSearch = (searchQuery?: string) => {
    const queryToSearch = searchQuery || query;
    if (queryToSearch.trim()) {
      searchMutation.mutate(queryToSearch);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch();
  };

  const startVoiceSearch = () => {
    if (recognitionRef.current && !isListening) {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion);
    setShowSuggestions(false);
    if (suggestion.trim()) {
      searchMutation.mutate(suggestion.trim());
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    setShowSuggestions(value.length > 2);
  };

  const handleTabChange = (newTab: typeof activeTab) => {
    setActiveTab(newTab);
    if (query.trim()) {
      searchMutation.mutate(query.trim());
    }
  };

  const quickSearches = [
    'artificial intelligence',
    'climate change',
    'photosynthesis',
    'quantum physics',
    'machine learning',
    'renewable energy',
    'space exploration',
    'genetic engineering'
  ];

  const featuredSnippet = searchResults.find(result => result.definition || result.content);

  return (
    <div className="min-h-screen bg-white dark:bg-neutral-900">
      {/* Header */}
      <div className="border-b border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-8">
            {/* Logo */}
            <Link href="/" className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              EduSearch
            </Link>

            {/* Search Bar */}
            <div className="flex-1 max-w-2xl relative">
              <form onSubmit={handleFormSubmit} className="relative">
                <div className="relative flex items-center">
                  <SearchIcon className="absolute left-4 h-5 w-5 text-neutral-400" />
                  <Input
                    ref={inputRef}
                    type="text"
                    value={query}
                    onChange={handleInputChange}
                    placeholder="Search anything..."
                    className="pl-12 pr-20 h-12 text-lg border-2 border-neutral-300 dark:border-neutral-600 rounded-full focus:border-blue-500 dark:focus:border-blue-400"
                    onFocus={() => setShowSuggestions(query.length > 2)}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                  />
                  <div className="absolute right-2 flex items-center gap-2">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-700"
                      onClick={startVoiceSearch}
                      disabled={isListening}
                    >
                      <Mic className={`h-4 w-4 ${isListening ? 'text-red-500 animate-pulse' : 'text-neutral-500'}`} />
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-700"
                    >
                      <Camera className="h-4 w-4 text-neutral-500" />
                    </Button>
                  </div>
                </div>
              </form>

              {/* Search Suggestions */}
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-600 rounded-lg shadow-lg mt-1 z-50">
                  {suggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      className="w-full text-left px-4 py-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 flex items-center gap-3"
                      onClick={() => handleSuggestionClick(suggestion)}
                    >
                      <SearchIcon className="h-4 w-4 text-neutral-400" />
                      <span className="dark:text-white">{suggestion}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Search Tools */}
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <Filter className="h-4 w-4" />
                Tools
              </Button>
            </div>
          </div>

          {/* Quick Search Suggestions */}
          {!hasSearched && (
            <div className="mt-6">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="h-4 w-4 text-neutral-500" />
                <span className="text-sm text-neutral-600 dark:text-neutral-400">Trending in Education</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {quickSearches.map((searchTerm, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900 px-3 py-1"
                    onClick={() => {
                      setQuery(searchTerm);
                      if (searchTerm.trim()) {
                        searchMutation.mutate(searchTerm.trim());
                      }
                    }}
                  >
                    {searchTerm}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Advanced Filters */}
      {showFilters && (
        <div className="border-b border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800">
          <div className="container mx-auto px-4 py-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2 dark:text-white">Time</label>
                <Select value={timeFilter} onValueChange={setTimeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any time</SelectItem>
                    <SelectItem value="hour">Past hour</SelectItem>
                    <SelectItem value="day">Past 24 hours</SelectItem>
                    <SelectItem value="week">Past week</SelectItem>
                    <SelectItem value="month">Past month</SelectItem>
                    <SelectItem value="year">Past year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2 dark:text-white">Region</label>
                <Select value={regionFilter} onValueChange={setRegionFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All regions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All regions</SelectItem>
                    <SelectItem value="us">United States</SelectItem>
                    <SelectItem value="uk">United Kingdom</SelectItem>
                    <SelectItem value="ca">Canada</SelectItem>
                    <SelectItem value="au">Australia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2 dark:text-white">Language</label>
                <Select value={languageFilter} onValueChange={setLanguageFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any language</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                    <SelectItem value="de">German</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2 dark:text-white">Safe Search</label>
                <Select value={safeSearch} onValueChange={setSafeSearch}>
                  <SelectTrigger>
                    <SelectValue placeholder="Moderate" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="strict">Strict</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="off">Off</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Search Tabs */}
      {hasSearched && (
        <div className="border-b border-neutral-200 dark:border-neutral-700">
          <div className="container mx-auto px-4">
            <Tabs value={activeTab} onValueChange={(value) => handleTabChange(value as typeof activeTab)}>
              <TabsList className="bg-transparent border-0 p-0 h-auto">
                <TabsTrigger value="all" className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none bg-transparent">
                  <Globe className="h-4 w-4" />
                  All
                </TabsTrigger>
                <TabsTrigger value="images" className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none bg-transparent">
                  <Image className="h-4 w-4" />
                  Images
                </TabsTrigger>
                <TabsTrigger value="videos" className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none bg-transparent">
                  <Video className="h-4 w-4" />
                  Videos
                </TabsTrigger>
                <TabsTrigger value="news" className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none bg-transparent">
                  <Newspaper className="h-4 w-4" />
                  News
                </TabsTrigger>
                <TabsTrigger value="shopping" className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none bg-transparent">
                  <ShoppingBag className="h-4 w-4" />
                  Shopping
                </TabsTrigger>
                <TabsTrigger value="forums" className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none bg-transparent">
                  <MessageSquare className="h-4 w-4" />
                  Forums
                </TabsTrigger>
                <TabsTrigger value="more" className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none bg-transparent">
                  <MoreHorizontal className="h-4 w-4" />
                  More
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      )}

      {/* Search Results */}
      {hasSearched && (
        <div className="container mx-auto px-4 py-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Main Results */}
            <div className="lg:col-span-3">
              {searchMutation.isPending && (
                <div className="space-y-4">
                  {Array(5).fill(0).map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-4 bg-neutral-200 dark:bg-neutral-700 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-neutral-200 dark:bg-neutral-700 rounded w-1/2 mb-2"></div>
                      <div className="h-3 bg-neutral-200 dark:bg-neutral-700 rounded w-full mb-1"></div>
                      <div className="h-3 bg-neutral-200 dark:bg-neutral-700 rounded w-5/6"></div>
                    </div>
                  ))}
                </div>
              )}

              {/* AI Direct Answer */}
              {searchMutation.data?.directAnswer && (
                <Card className="mb-6 border-l-4 border-l-green-500 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Brain className="h-5 w-5 text-green-600" />
                      AI Direct Answer
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-4">
                      <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed">
                        {searchMutation.data.directAnswer.answer}
                      </p>
                      
                      {searchMutation.data.directAnswer.relatedQuestions && searchMutation.data.directAnswer.relatedQuestions.length > 0 && (
                        <div>
                          <h4 className="font-medium mb-2 text-neutral-800 dark:text-neutral-200">Related Questions:</h4>
                          <div className="flex flex-wrap gap-2">
                            {searchMutation.data.directAnswer.relatedQuestions.slice(0, 4).map((question: string, index: number) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className="text-xs h-8"
                                onClick={() => {
                                  setQuery(question);
                                  searchMutation.mutate(question);
                                }}
                              >
                                {question}
                              </Button>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2 text-sm text-neutral-500">
                        <Star className="h-3 w-3 text-yellow-500" />
                        <span>AI-powered educational response</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Featured Snippet */}
              {featuredSnippet && (
                <Card className="mb-6 border-l-4 border-l-blue-500">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="flex-1">
                        {featuredSnippet.definition && (
                          <div className="mb-3">
                            <h3 className="font-semibold text-lg mb-2 dark:text-white">{query}</h3>
                            <p className="text-neutral-700 dark:text-neutral-300">{featuredSnippet.definition}</p>
                          </div>
                        )}
                        {featuredSnippet.content && (
                          <div className="mb-3">
                            <p className="text-neutral-600 dark:text-neutral-400 text-sm leading-relaxed">
                              {featuredSnippet.content}
                            </p>
                          </div>
                        )}
                        {featuredSnippet.keyFacts && featuredSnippet.keyFacts.length > 0 && (
                          <div className="mb-3">
                            <h4 className="font-medium mb-2 dark:text-white">Key Facts:</h4>
                            <ul className="space-y-1">
                              {featuredSnippet.keyFacts.slice(0, 5).map((fact, index) => (
                                <li key={index} className="text-sm text-neutral-600 dark:text-neutral-400 flex items-start gap-2">
                                  <span className="text-blue-500 mt-1">•</span>
                                  {fact}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        <div className="flex items-center gap-2 text-sm text-neutral-500">
                          <span>{featuredSnippet.domain}</span>
                          <ExternalLink className="h-3 w-3" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Search Results */}
              <div className="space-y-6">
                {searchResults.filter(result => result !== featuredSnippet).map((result) => (
                  <div key={result.id} className="group">
                    <div className="flex items-start gap-3">
                      {result.favicon && (
                        <img src={result.favicon} alt="" className="w-4 h-4 mt-1 flex-shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">{result.domain}</span>
                          {result.publishedDate && (
                            <>
                              <span className="text-neutral-400">•</span>
                              <span className="text-sm text-neutral-600 dark:text-neutral-400">{result.publishedDate}</span>
                            </>
                          )}
                        </div>
                        <h3 className="text-xl text-blue-600 dark:text-blue-400 hover:underline cursor-pointer mb-1 line-clamp-2">
                          {result.title}
                        </h3>
                        <p className="text-neutral-700 dark:text-neutral-300 text-sm leading-relaxed line-clamp-3">
                          {result.snippet}
                        </p>
                        <div className="flex items-center gap-4 mt-2">
                          <Button variant="ghost" size="sm" className="h-8 text-xs">
                            <ThumbsUp className="h-3 w-3 mr-1" />
                            Helpful
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 text-xs">
                            <Star className="h-3 w-3 mr-1" />
                            Save
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {searchResults.length === 0 && !searchMutation.isPending && (
                <div className="text-center py-12">
                  <SearchIcon className="h-12 w-12 mx-auto text-neutral-400 mb-4" />
                  <h3 className="text-lg font-medium text-neutral-900 dark:text-white mb-2">No results found</h3>
                  <p className="text-neutral-600 dark:text-neutral-400">Try different keywords or check your spelling</p>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="space-y-6">
                {/* Quick Info */}
                {query && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Quick Info</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm">
                        <span className="text-neutral-600 dark:text-neutral-400">Search term: </span>
                        <span className="font-medium dark:text-white">{query}</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-neutral-600 dark:text-neutral-400">Results: </span>
                        <span className="font-medium dark:text-white">{searchResults.length.toLocaleString()}</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-neutral-600 dark:text-neutral-400">Search time: </span>
                        <span className="font-medium dark:text-white">0.{Math.floor(Math.random() * 9) + 1} seconds</span>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Related Searches */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Related Searches</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {quickSearches.filter(search => !search.toLowerCase().includes(query.toLowerCase())).slice(0, 5).map((search, index) => (
                        <button
                          key={index}
                          className="block w-full text-left text-sm text-blue-600 dark:text-blue-400 hover:underline"
                          onClick={() => {
                            setQuery(search);
                            if (search.trim()) {
                              searchMutation.mutate(search.trim());
                            }
                          }}
                        >
                          {search}
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}