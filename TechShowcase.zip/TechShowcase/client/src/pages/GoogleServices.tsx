import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import GoogleMaps from '@/components/GoogleMaps';
import { 
  Search, 
  MapPin, 
  Languages, 
  GraduationCap, 
  Image, 
  Video, 
  Newspaper,
  BookOpen,
  Globe
} from 'lucide-react';

export default function GoogleServices() {
  const [translateText, setTranslateText] = useState('');
  const [translatedResult, setTranslatedResult] = useState('');
  const [targetLanguage, setTargetLanguage] = useState('es');
  const [isTranslating, setIsTranslating] = useState(false);

  const handleTranslate = async () => {
    if (!translateText.trim()) return;

    setIsTranslating(true);
    try {
      const response = await fetch('/api/google/translate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: translateText,
          targetLanguage: targetLanguage
        })
      });

      if (response.ok) {
        const data = await response.json();
        setTranslatedResult(data.translatedText);
      }
    } catch (error) {
      console.error('Translation error:', error);
    }
    setIsTranslating(false);
  };

  const languages = [
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'it', name: 'Italian' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'ru', name: 'Russian' },
    { code: 'ja', name: 'Japanese' },
    { code: 'ko', name: 'Korean' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ar', name: 'Arabic' }
  ];

  const googleFeatures = [
    {
      icon: <Search className="h-6 w-6" />,
      title: "Google Search",
      description: "Access real Google search results with advanced filtering",
      route: "/search"
    },
    {
      icon: <Image className="h-6 w-6" />,
      title: "Google Images",
      description: "Search millions of images with Google's image search",
      route: "/search?type=images"
    },
    {
      icon: <Video className="h-6 w-6" />,
      title: "YouTube Videos",
      description: "Find educational videos from YouTube's vast library",
      route: "/search?type=videos"
    },
    {
      icon: <Newspaper className="h-6 w-6" />,
      title: "Google News",
      description: "Get the latest news from Google News sources",
      route: "/search?type=news"
    },
    {
      icon: <GraduationCap className="h-6 w-6" />,
      title: "Google Scholar",
      description: "Academic papers and scholarly articles",
      route: "/search?type=scholar"
    },
    {
      icon: <BookOpen className="h-6 w-6" />,
      title: "Google Books",
      description: "Search inside millions of books",
      route: "/search?type=books"
    }
  ];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Globe className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold">Google Services Integration</h1>
          <p className="text-gray-600">Access real Google services for comprehensive search and learning</p>
        </div>
      </div>

      <Tabs defaultValue="search" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="search">Search Services</TabsTrigger>
          <TabsTrigger value="maps">Google Maps</TabsTrigger>
          <TabsTrigger value="translate">Google Translate</TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Google Search Services
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {googleFeatures.map((feature, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="text-blue-600 mt-1">
                          {feature.icon}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-sm mb-1">{feature.title}</h3>
                          <p className="text-xs text-gray-600 mb-3">{feature.description}</p>
                          <Button 
                            size="sm" 
                            onClick={() => window.location.href = feature.route}
                            className="w-full"
                          >
                            Try Now
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Search Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">10M+</div>
                  <div className="text-sm text-gray-600">Web Results</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">Real-time</div>
                  <div className="text-sm text-gray-600">News Updates</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">HD</div>
                  <div className="text-sm text-gray-600">Image Quality</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">Scholarly</div>
                  <div className="text-sm text-gray-600">Academic Papers</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maps" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Google Maps & Places
              </CardTitle>
            </CardHeader>
            <CardContent>
              <GoogleMaps showSearch={true} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="translate" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Languages className="h-5 w-5" />
                Google Translate
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Text to Translate</label>
                  <textarea
                    className="w-full h-32 p-3 border rounded-lg resize-none"
                    placeholder="Enter text to translate..."
                    value={translateText}
                    onChange={(e) => setTranslateText(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Translation</label>
                  <div className="w-full h-32 p-3 border rounded-lg bg-gray-50 overflow-auto">
                    {translatedResult || "Translation will appear here..."}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium mb-2">Target Language</label>
                  <select
                    className="w-full p-2 border rounded-lg"
                    value={targetLanguage}
                    onChange={(e) => setTargetLanguage(e.target.value)}
                  >
                    {languages.map((lang) => (
                      <option key={lang.code} value={lang.code}>
                        {lang.name}
                      </option>
                    ))}
                  </select>
                </div>
                <Button 
                  onClick={handleTranslate} 
                  disabled={isTranslating || !translateText.trim()}
                  className="mt-6"
                >
                  {isTranslating ? 'Translating...' : 'Translate'}
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">100+ Languages</Badge>
                <Badge variant="secondary">Real-time Translation</Badge>
                <Badge variant="secondary">Neural Machine Translation</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}