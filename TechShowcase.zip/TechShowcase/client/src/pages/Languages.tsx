import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Languages, MessageCircle, BookOpen, Volume2, Globe, Users } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function LanguagesPage() {
  const [textToTranslate, setTextToTranslate] = useState("");
  const [sourceLanguage, setSourceLanguage] = useState("auto");
  const [targetLanguage, setTargetLanguage] = useState("es");
  const [translationResult, setTranslationResult] = useState("");

  const translateMutation = useMutation({
    mutationFn: async (data: { text: string; from: string; to: string }) => {
      const response = await fetch("/api/ai/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      return response.json();
    },
    onSuccess: (data) => {
      setTranslationResult(data.translation || data.result || "Translation completed");
    }
  });

  const languages = [
    { code: "en", name: "English", flag: "🇺🇸", speakers: "1.5B", family: "Germanic" },
    { code: "es", name: "Spanish", flag: "🇪🇸", speakers: "500M", family: "Romance" },
    { code: "fr", name: "French", flag: "🇫🇷", speakers: "280M", family: "Romance" },
    { code: "de", name: "German", flag: "🇩🇪", speakers: "100M", family: "Germanic" },
    { code: "it", name: "Italian", flag: "🇮🇹", speakers: "65M", family: "Romance" },
    { code: "pt", name: "Portuguese", flag: "🇵🇹", speakers: "260M", family: "Romance" },
    { code: "ru", name: "Russian", flag: "🇷🇺", speakers: "260M", family: "Slavic" },
    { code: "zh", name: "Chinese", flag: "🇨🇳", speakers: "1.1B", family: "Sino-Tibetan" },
    { code: "ja", name: "Japanese", flag: "🇯🇵", speakers: "125M", family: "Japonic" },
    { code: "ko", name: "Korean", flag: "🇰🇷", speakers: "77M", family: "Koreanic" },
    { code: "ar", name: "Arabic", flag: "🇸🇦", speakers: "420M", family: "Semitic" },
    { code: "hi", name: "Hindi", flag: "🇮🇳", speakers: "600M", family: "Indo-European" }
  ];

  const languageFamilies = [
    {
      name: "Indo-European",
      description: "Largest language family, includes English, Spanish, Russian",
      subfamilies: ["Germanic", "Romance", "Slavic", "Indo-Iranian"],
      speakers: "3.2B"
    },
    {
      name: "Sino-Tibetan",
      description: "Includes Chinese, Tibetan, and Burmese languages",
      subfamilies: ["Sinitic", "Tibeto-Burman"],
      speakers: "1.4B"
    },
    {
      name: "Niger-Congo",
      description: "African language family with over 1,500 languages",
      subfamilies: ["Bantu", "Atlantic", "Volta-Congo"],
      speakers: "700M"
    },
    {
      name: "Afro-Asiatic",
      description: "Includes Arabic, Hebrew, and many African languages",
      subfamilies: ["Semitic", "Berber", "Cushitic", "Chadic"],
      speakers: "500M"
    }
  ];

  const learningResources = [
    { name: "Grammar Fundamentals", description: "Core grammar rules and structures", difficulty: "Beginner" },
    { name: "Vocabulary Builder", description: "Essential words and phrases", difficulty: "All Levels" },
    { name: "Pronunciation Guide", description: "Audio pronunciation training", difficulty: "Intermediate" },
    { name: "Conversation Practice", description: "Real-world dialogue scenarios", difficulty: "Advanced" },
    { name: "Cultural Context", description: "Language in cultural settings", difficulty: "Advanced" },
    { name: "Business Language", description: "Professional communication skills", difficulty: "Expert" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-100 dark:from-gray-900 dark:to-emerald-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            World Languages Center
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Learn languages, explore linguistics, and connect with global cultures through comprehensive language education
          </p>
        </div>

        <Tabs defaultValue="translator" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="translator">AI Translator</TabsTrigger>
            <TabsTrigger value="languages">Languages</TabsTrigger>
            <TabsTrigger value="families">Language Families</TabsTrigger>
            <TabsTrigger value="learning">Learning Resources</TabsTrigger>
            <TabsTrigger value="linguistics">Linguistics</TabsTrigger>
          </TabsList>

          <TabsContent value="translator" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Languages className="h-6 w-6" />
                  AI-Powered Translator
                </CardTitle>
                <CardDescription>
                  Translate text between multiple languages with cultural context
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">From:</label>
                    <select 
                      value={sourceLanguage}
                      onChange={(e) => setSourceLanguage(e.target.value)}
                      className="w-full p-2 border rounded-md"
                    >
                      <option value="auto">Auto-detect</option>
                      {languages.map(lang => (
                        <option key={lang.code} value={lang.code}>
                          {lang.flag} {lang.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">To:</label>
                    <select 
                      value={targetLanguage}
                      onChange={(e) => setTargetLanguage(e.target.value)}
                      className="w-full p-2 border rounded-md"
                    >
                      {languages.map(lang => (
                        <option key={lang.code} value={lang.code}>
                          {lang.flag} {lang.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <Textarea
                  placeholder="Enter text to translate..."
                  value={textToTranslate}
                  onChange={(e) => setTextToTranslate(e.target.value)}
                  className="min-h-[120px]"
                />
                <Button 
                  onClick={() => translateMutation.mutate({ 
                    text: textToTranslate, 
                    from: sourceLanguage, 
                    to: targetLanguage 
                  })}
                  disabled={!textToTranslate.trim() || translateMutation.isPending}
                  className="w-full"
                >
                  {translateMutation.isPending ? "Translating..." : "Translate"}
                </Button>
                {translationResult && (
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <h3 className="font-semibold text-green-800 dark:text-green-200 mb-2">Translation:</h3>
                    <div className="text-green-700 dark:text-green-300">{translationResult}</div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="languages" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {languages.map((language, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <span className="text-3xl">{language.flag}</span>
                      <div>
                        <div className="text-lg">{language.name}</div>
                        <Badge variant="outline" className="text-xs">{language.family}</Badge>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Speakers:</span>
                        <span className="font-medium">{language.speakers}</span>
                      </div>
                      <Button variant="outline" size="sm" className="w-full">
                        Start Learning
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="families" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {languageFamilies.map((family, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {family.name}
                      <Badge variant="secondary">{family.speakers} speakers</Badge>
                    </CardTitle>
                    <CardDescription>{family.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Subfamilies:</p>
                      <div className="flex flex-wrap gap-1">
                        {family.subfamilies.map((subfamily, subIndex) => (
                          <Badge key={subIndex} variant="outline" className="text-xs">
                            {subfamily}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="learning" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {learningResources.map((resource, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {resource.name}
                      <Badge variant="secondary">{resource.difficulty}</Badge>
                    </CardTitle>
                    <CardDescription>{resource.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" size="sm" className="w-full">
                      Access Resource
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="linguistics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Linguistic Analysis Tools</CardTitle>
                <CardDescription>
                  Analyze language patterns, phonetics, and structural elements
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <MessageCircle className="h-8 w-8 text-blue-600 mb-2" />
                      <h3 className="font-semibold mb-2">Phonetic Analysis</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Study sound patterns and pronunciation</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <BookOpen className="h-8 w-8 text-green-600 mb-2" />
                      <h3 className="font-semibold mb-2">Grammar Structure</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Analyze syntax and morphology</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Globe className="h-8 w-8 text-purple-600 mb-2" />
                      <h3 className="font-semibold mb-2">Language Evolution</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Track historical language changes</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}