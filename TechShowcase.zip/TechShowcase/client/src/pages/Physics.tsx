import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Atom, Zap, Globe, Calculator, BookOpen, Users, Search, Play } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Physics() {
  const [searchQuery, setSearchQuery] = useState("");
  const [mathProblem, setMathProblem] = useState("");
  const [chatMessage, setChatMessage] = useState("");

  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      return apiRequest(`/api/search`, {
        method: "POST",
        body: JSON.stringify({ 
          query, 
          type: "all",
          context: "physics education" 
        }),
        headers: { "Content-Type": "application/json" }
      });
    }
  });

  const mathMutation = useMutation({
    mutationFn: async (problem: string) => {
      return apiRequest(`/api/ai/math`, {
        method: "POST",
        body: JSON.stringify({ problem }),
        headers: { "Content-Type": "application/json" }
      });
    }
  });

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      return apiRequest(`/api/ai/chat`, {
        method: "POST",
        body: JSON.stringify({ 
          message,
          conversationHistory: [],
          context: "physics"
        }),
        headers: { "Content-Type": "application/json" }
      });
    }
  });

  const physicsTopics = [
    {
      title: "Classical Mechanics",
      description: "Motion, forces, energy, and momentum in macroscopic systems",
      icon: "⚙️",
      subtopics: ["Newton's Laws", "Kinematics", "Energy Conservation", "Circular Motion", "Oscillations"]
    },
    {
      title: "Electromagnetism",
      description: "Electric and magnetic fields, electromagnetic waves",
      icon: "⚡",
      subtopics: ["Electric Fields", "Magnetic Fields", "Electromagnetic Induction", "Maxwell's Equations", "Wave Propagation"]
    },
    {
      title: "Thermodynamics",
      description: "Heat, temperature, and energy transfer in systems",
      icon: "🌡️",
      subtopics: ["Laws of Thermodynamics", "Heat Engines", "Entropy", "Phase Transitions", "Statistical Mechanics"]
    },
    {
      title: "Quantum Physics",
      description: "Behavior of matter and energy at atomic and subatomic scales",
      icon: "🔬",
      subtopics: ["Wave-Particle Duality", "Quantum States", "Heisenberg Principle", "Schrödinger Equation", "Quantum Entanglement"]
    },
    {
      title: "Relativity",
      description: "Special and general theories of relativity",
      icon: "🌌",
      subtopics: ["Special Relativity", "Time Dilation", "Mass-Energy Equivalence", "General Relativity", "Spacetime Curvature"]
    },
    {
      title: "Optics",
      description: "Light behavior, reflection, refraction, and wave properties",
      icon: "🔆",
      subtopics: ["Geometric Optics", "Wave Optics", "Interference", "Diffraction", "Polarization"]
    }
  ];

  const handleSearch = () => {
    const query = searchQuery.trim();
    if (query) {
      searchMutation.mutate(query);
    }
  };

  const handleMathSolve = () => {
    if (mathProblem.trim()) {
      mathMutation.mutate(mathProblem);
    }
  };

  const handleChat = () => {
    if (chatMessage.trim()) {
      chatMutation.mutate(`Physics question: ${chatMessage}`);
      setChatMessage("");
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
          <Atom className="h-10 w-10 text-blue-600" />
          Physics Learning Center
        </h1>
        <p className="text-xl text-muted-foreground">
          Explore the fundamental laws of the universe through interactive learning
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="search">Research</TabsTrigger>
          <TabsTrigger value="calculator">Physics Calculator</TabsTrigger>
          <TabsTrigger value="chat">AI Tutor</TabsTrigger>
          <TabsTrigger value="experiments">Virtual Labs</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {physicsTopics.map((topic, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">{topic.icon}</span>
                    {topic.title}
                  </CardTitle>
                  <CardDescription>{topic.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {topic.subtopics.map((subtopic, idx) => (
                      <Badge key={idx} variant="secondary" className="mr-2 mb-2">
                        {subtopic}
                      </Badge>
                    ))}
                  </div>
                  <Button className="w-full mt-4" onClick={() => {
                    setSearchQuery(topic.title);
                    handleSearch();
                  }}>
                    <BookOpen className="w-4 h-4 mr-2" />
                    Explore Topic
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Physics Research
              </CardTitle>
              <CardDescription>
                Search for physics concepts, theories, and educational resources
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Search physics topics..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
                <Button onClick={handleSearch} disabled={searchMutation.isPending}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>
              
              {searchMutation.data?.directAnswer && (
                <Card className="border-blue-200 bg-blue-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Direct Answer</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed">
                      {searchMutation.data.directAnswer.answer}
                    </p>
                    {searchMutation.data.directAnswer.relatedQuestions?.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">Related Questions:</h4>
                        <div className="space-y-1">
                          {searchMutation.data.directAnswer.relatedQuestions.map((q: string, idx: number) => (
                            <Button 
                              key={idx} 
                              variant="outline" 
                              size="sm" 
                              className="mr-2 mb-2"
                              onClick={() => setSearchQuery(q)}
                            >
                              {q}
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {searchMutation.data?.results && (
                <div className="space-y-3">
                  <h3 className="font-semibold">Search Results</h3>
                  {searchMutation.data.results.map((result: any, idx: number) => (
                    <Card key={idx} className="hover:shadow-md transition-shadow">
                      <CardContent className="pt-4">
                        <h4 className="font-medium text-blue-600 mb-1">{result.title}</h4>
                        <p className="text-sm text-muted-foreground mb-2">{result.snippet}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="outline">{result.domain}</Badge>
                          <Badge variant="secondary">{result.type}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calculator" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Physics Problem Solver
              </CardTitle>
              <CardDescription>
                Solve physics equations and problems with step-by-step solutions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Enter physics problem (e.g., 'A car accelerates from 0 to 60 mph in 8 seconds. Calculate the acceleration.')"
                value={mathProblem}
                onChange={(e) => setMathProblem(e.target.value)}
                rows={3}
              />
              <Button onClick={handleMathSolve} disabled={mathMutation.isPending} className="w-full">
                <Calculator className="w-4 h-4 mr-2" />
                Solve Problem
              </Button>
              
              {mathMutation.data && (
                <Card className="border-green-200 bg-green-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Solution</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Answer:</h4>
                      <p className="text-lg font-mono bg-white p-2 rounded border">
                        {mathMutation.data.solution}
                      </p>
                    </div>
                    {mathMutation.data.steps && (
                      <div>
                        <h4 className="font-semibold mb-2">Step-by-step solution:</h4>
                        <div className="space-y-2">
                          {mathMutation.data.steps.map((step: string, idx: number) => (
                            <div key={idx} className="bg-white p-3 rounded border">
                              <div className="font-medium text-sm text-blue-600 mb-1">Step {idx + 1}</div>
                              <p className="text-sm">{step}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chat" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Physics AI Tutor
              </CardTitle>
              <CardDescription>
                Ask questions and get detailed explanations about physics concepts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Ask a physics question..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                rows={3}
              />
              <Button onClick={handleChat} disabled={chatMutation.isPending} className="w-full">
                <Users className="w-4 h-4 mr-2" />
                Ask Physics Tutor
              </Button>
              
              {chatMutation.data && (
                <Card className="border-purple-200 bg-purple-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Physics Tutor Response</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {chatMutation.data.message}
                    </p>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="experiments" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5" />
                  Virtual Physics Lab
                </CardTitle>
                <CardDescription>Interactive simulations and experiments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    "Projectile Motion Simulator",
                    "Wave Interference Patterns",
                    "Electric Field Visualization",
                    "Pendulum Oscillations",
                    "Quantum Double-Slit Experiment"
                  ].map((experiment, idx) => (
                    <Button key={idx} variant="outline" className="w-full justify-start">
                      <Play className="w-4 h-4 mr-2" />
                      {experiment}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Physics Constants & Formulas</CardTitle>
                <CardDescription>Quick reference for common physics values</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Speed of light (c):</span>
                    <span className="font-mono">3.00 × 10⁸ m/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Planck constant (h):</span>
                    <span className="font-mono">6.63 × 10⁻³⁴ J⋅s</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gravitational constant (G):</span>
                    <span className="font-mono">6.67 × 10⁻¹¹ N⋅m²/kg²</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Electron charge (e):</span>
                    <span className="font-mono">1.60 × 10⁻¹⁹ C</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Earth gravity (g):</span>
                    <span className="font-mono">9.81 m/s²</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}