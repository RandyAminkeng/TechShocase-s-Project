import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Atom, FlaskConical, Microscope, Telescope, Dna, Zap } from "lucide-react";

export default function Science() {
  const [searchQuery, setSearchQuery] = useState("");

  const scienceFields = [
    { 
      title: "Physics", 
      description: "Motion, energy, matter, and forces",
      icon: Atom,
      color: "text-blue-600",
      topics: ["Mechanics", "Thermodynamics", "Electromagnetism", "Quantum Physics", "Relativity"]
    },
    { 
      title: "Chemistry", 
      description: "Elements, compounds, and reactions",
      icon: FlaskConical,
      color: "text-green-600",
      topics: ["Organic Chemistry", "Inorganic Chemistry", "Physical Chemistry", "Biochemistry", "Analytical Chemistry"]
    },
    { 
      title: "Biology", 
      description: "Living organisms and life processes",
      icon: Dna,
      color: "text-red-600",
      topics: ["Cell Biology", "Genetics", "Evolution", "Ecology", "Human Biology"]
    },
    { 
      title: "Astronomy", 
      description: "Stars, planets, and the universe",
      icon: Telescope,
      color: "text-purple-600",
      topics: ["Solar System", "Stellar Evolution", "Galaxies", "Cosmology", "Exoplanets"]
    },
    { 
      title: "Earth Science", 
      description: "Geology, weather, and climate",
      icon: Microscope,
      color: "text-orange-600",
      topics: ["Geology", "Meteorology", "Oceanography", "Environmental Science", "Climate Change"]
    },
    { 
      title: "Engineering", 
      description: "Applied science and technology",
      icon: Zap,
      color: "text-yellow-600",
      topics: ["Mechanical", "Electrical", "Computer", "Civil", "Aerospace"]
    }
  ];

  const experiments = [
    { title: "Virtual Chemistry Lab", description: "Safe chemical reactions simulation", difficulty: "Beginner" },
    { title: "Physics Simulations", description: "Interactive motion and force demos", difficulty: "Intermediate" },
    { title: "Biology Microscopy", description: "Cell structure exploration", difficulty: "Advanced" },
    { title: "Astronomy Observatory", description: "Virtual telescope observations", difficulty: "All Levels" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 dark:from-gray-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Science Learning Hub
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Explore the wonders of science through interactive experiments, detailed explanations, and cutting-edge research
          </p>
        </div>

        <Tabs defaultValue="fields" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="fields">Science Fields</TabsTrigger>
            <TabsTrigger value="experiments">Virtual Labs</TabsTrigger>
            <TabsTrigger value="research">Research Tools</TabsTrigger>
          </TabsList>
          
          <TabsContent value="fields" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {scienceFields.map((field, index) => {
                const IconComponent = field.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <IconComponent className={`h-8 w-8 ${field.color}`} />
                        <CardTitle className="text-xl">{field.title}</CardTitle>
                      </div>
                      <CardDescription>{field.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Key Topics:</p>
                        <div className="flex flex-wrap gap-1">
                          {field.topics.map((topic, topicIndex) => (
                            <Badge key={topicIndex} variant="outline" className="text-xs">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="experiments" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {experiments.map((experiment, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {experiment.title}
                      <Badge variant="secondary">{experiment.difficulty}</Badge>
                    </CardTitle>
                    <CardDescription>{experiment.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full">Start Experiment</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="research" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Scientific Research Tools</CardTitle>
                <CardDescription>
                  Access journals, papers, and research databases
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Search scientific papers and research..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1"
                  />
                  <Button>Search</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">PubMed Database</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Medical and life science literature</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">arXiv Repository</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Physics, math, and computer science preprints</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">Nature Journals</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Premier scientific publications</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}