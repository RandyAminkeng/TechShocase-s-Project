import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import SubjectCard from "@/components/Subjects/SubjectCard";
import FeaturedCourse from "@/components/Subjects/FeaturedCourse";
import { getSubjects, getCourses, getSubject } from "@/lib/api";

const Subjects = () => {
  const [match, params] = useRoute("/subjects/:id");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLevel, setSelectedLevel] = useState("All Levels");
  
  const subjectId = params?.id ? parseInt(params.id) : null;

  const { data: subjects, isLoading: subjectsLoading } = useQuery({
    queryKey: ['/api/subjects'],
    staleTime: 300000 // 5 minutes
  });

  const { data: courses, isLoading: coursesLoading } = useQuery({
    queryKey: ['/api/courses'],
    staleTime: 300000 // 5 minutes
  });

  // Get specific subject if ID is provided
  const { data: specificSubject, isLoading: specificSubjectLoading } = useQuery({
    queryKey: ['/api/subjects', subjectId],
    enabled: !!subjectId,
    staleTime: 300000
  });

  // Group courses by subject
  const coursesBySubject = subjects?.map(subject => {
    const subjectCourses = courses?.filter(course => course.subjectId === subject.id) || [];
    return {
      ...subject,
      courses: subjectCourses
    };
  });

  const featuredCourse = {
    id: 99,
    title: "Advanced Data Science with AI",
    description: "Learn how to apply AI techniques to analyze complex data sets and derive meaningful insights.",
    imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=800",
    duration: "12 weeks",
    level: "Advanced",
    enrolledCount: 5432,
    tags: ["Machine Learning", "Python", "Data Analysis", "Neural Networks"],
    isNew: true,
    isPopular: true
  };

  // If viewing specific subject, show subject detail page
  if (subjectId && specificSubject) {
    const subjectCourses = courses?.filter((course: any) => course.subjectId === subjectId) || [];
    
    return (
      <div className="p-6">
        {/* Back Navigation */}
        <div className="mb-6">
          <button 
            onClick={() => window.history.back()}
            className="flex items-center gap-2 text-neutral-600 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-neutral-200"
          >
            <span className="material-icons">arrow_back</span>
            Back to Subjects
          </button>
        </div>

        <header className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className={`w-16 h-16 rounded-xl flex items-center justify-center ${(specificSubject as any).color || 'bg-blue-100'}`}>
              <span className="material-icons text-2xl text-white">{(specificSubject as any).icon || 'school'}</span>
            </div>
            <div>
              <h1 className="font-heading text-3xl font-bold text-neutral-800 dark:text-white">
                {(specificSubject as any).name}
              </h1>
              <p className="text-neutral-500 dark:text-neutral-400">
                {(specificSubject as any).description}
              </p>
            </div>
          </div>

          {/* Subject Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white dark:bg-neutral-800 rounded-lg p-4 shadow-sm">
              <div className="text-2xl font-bold text-neutral-800 dark:text-white">{subjectCourses.length}</div>
              <div className="text-sm text-neutral-500 dark:text-neutral-400">Courses</div>
            </div>
            <div className="bg-white dark:bg-neutral-800 rounded-lg p-4 shadow-sm">
              <div className="text-2xl font-bold text-neutral-800 dark:text-white">24</div>
              <div className="text-sm text-neutral-500 dark:text-neutral-400">Lessons</div>
            </div>
            <div className="bg-white dark:bg-neutral-800 rounded-lg p-4 shadow-sm">
              <div className="text-2xl font-bold text-neutral-800 dark:text-white">6.5h</div>
              <div className="text-sm text-neutral-500 dark:text-neutral-400">Total Duration</div>
            </div>
            <div className="bg-white dark:bg-neutral-800 rounded-lg p-4 shadow-sm">
              <div className="text-2xl font-bold text-green-600">85%</div>
              <div className="text-sm text-neutral-500 dark:text-neutral-400">Your Progress</div>
            </div>
          </div>
        </header>

        {/* Courses Section */}
        <section className="mb-8">
          <h2 className="font-heading text-xl font-semibold mb-4 dark:text-white">Available Courses</h2>
          {subjectCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subjectCourses.map((course: any) => (
                <div key={course.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold text-lg dark:text-white">{course.name}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      course.difficulty === 'Beginner' ? 'bg-green-100 text-green-700' :
                      course.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {course.difficulty}
                    </span>
                  </div>
                  <p className="text-neutral-600 text-sm mb-4 dark:text-neutral-300">{course.description}</p>
                  
                  {/* Course Progress */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-neutral-500 dark:text-neutral-400">Progress</span>
                      <span className="text-neutral-700 dark:text-neutral-300">65%</span>
                    </div>
                    <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{width: '65%'}}></div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-neutral-500 dark:text-neutral-400">
                      <span className="material-icons text-sm mr-1">schedule</span>
                      4 lessons remaining
                    </div>
                    <a href={`/lesson/${course.id}`} className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors inline-block text-center">
                      Start Lesson
                    </a>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-neutral-500 dark:text-neutral-400">
              <span className="material-icons text-4xl mb-2">school</span>
              <p>No courses available for this subject yet.</p>
            </div>
          )}
        </section>

        {/* Recent Activity */}
        <section className="mb-8">
          <h2 className="font-heading text-xl font-semibold mb-4 dark:text-white">Recent Activity</h2>
          <div className="bg-white dark:bg-neutral-800 rounded-xl shadow-sm border border-neutral-200 dark:border-neutral-700">
            <div className="p-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                    <span className="material-icons text-blue-600 dark:text-blue-400">check_circle</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium dark:text-white">Completed "Introduction to Algebra"</p>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                    <span className="material-icons text-green-600 dark:text-green-400">quiz</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium dark:text-white">Scored 95% on Linear Equations Quiz</p>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">1 day ago</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center">
                    <span className="material-icons text-purple-600 dark:text-purple-400">auto_awesome</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium dark:text-white">Used AI Tutor for quadratic equations</p>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">3 days ago</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Recommended Resources */}
        <section>
          <h2 className="font-heading text-xl font-semibold mb-4 dark:text-white">Recommended Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-neutral-800 rounded-lg p-4 shadow-sm border border-neutral-200 dark:border-neutral-700">
              <div className="flex items-center gap-3 mb-2">
                <span className="material-icons text-blue-600">article</span>
                <h3 className="font-medium dark:text-white">Study Guide</h3>
              </div>
              <p className="text-sm text-neutral-600 dark:text-neutral-300">Comprehensive notes and examples</p>
            </div>
            <div className="bg-white dark:bg-neutral-800 rounded-lg p-4 shadow-sm border border-neutral-200 dark:border-neutral-700">
              <div className="flex items-center gap-3 mb-2">
                <span className="material-icons text-green-600">video_library</span>
                <h3 className="font-medium dark:text-white">Video Tutorials</h3>
              </div>
              <p className="text-sm text-neutral-600 dark:text-neutral-300">Step-by-step visual explanations</p>
            </div>
            <div className="bg-white dark:bg-neutral-800 rounded-lg p-4 shadow-sm border border-neutral-200 dark:border-neutral-700">
              <div className="flex items-center gap-3 mb-2">
                <span className="material-icons text-purple-600">psychology</span>
                <h3 className="font-medium dark:text-white">AI Tutor</h3>
              </div>
              <p className="text-sm text-neutral-600 dark:text-neutral-300">Get personalized help anytime</p>
            </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="p-6">
      <header className="mb-6">
        <h2 className="font-heading text-2xl font-bold text-neutral-800 dark:text-white">Explore Subjects</h2>
        <p className="text-neutral-500 dark:text-neutral-400">Discover learning paths across different disciplines</p>
      </header>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <input 
            type="text" 
            className="w-full px-4 py-3 pl-10 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary dark:bg-neutral-700 dark:border-neutral-600 dark:text-white" 
            placeholder="Search subjects..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <span className="material-icons absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 dark:text-neutral-500">search</span>
        </div>
        <div className="flex gap-2">
          <select 
            className="bg-white px-4 py-3 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary dark:bg-neutral-700 dark:border-neutral-600 dark:text-white"
            value={selectedLevel}
            onChange={(e) => setSelectedLevel(e.target.value)}
          >
            <option>All Levels</option>
            <option>Beginner</option>
            <option>Intermediate</option>
            <option>Advanced</option>
          </select>
          <button className="bg-neutral-100 px-4 py-3 rounded-lg border border-neutral-300 hover:bg-neutral-200 dark:bg-neutral-700 dark:border-neutral-600 dark:text-white dark:hover:bg-neutral-600">
            <span className="material-icons">filter_list</span>
          </button>
        </div>
      </div>

      {/* Subject Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {subjectsLoading || coursesLoading ? (
          // Skeleton loaders for subjects
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="h-64 bg-white rounded-xl shadow-sm animate-pulse dark:bg-neutral-800"></div>
          ))
        ) : (
          coursesBySubject?.map(subject => (
            <SubjectCard
              key={subject.id}
              id={subject.id}
              name={subject.name}
              icon={subject.icon}
              color={subject.color}
              courseCount={subject.courses.length}
              courses={subject.courses}
            />
          ))
        )}
      </div>

      {/* Featured Course */}
      <section className="mb-10">
        <h3 className="font-heading text-xl font-semibold mb-4 dark:text-white">Featured Course</h3>
        
        <FeaturedCourse
          id={featuredCourse.id}
          title={featuredCourse.title}
          description={featuredCourse.description}
          imageUrl={featuredCourse.imageUrl}
          duration={featuredCourse.duration}
          level={featuredCourse.level}
          enrolledCount={featuredCourse.enrolledCount}
          tags={featuredCourse.tags}
          isNew={featuredCourse.isNew}
          isPopular={featuredCourse.isPopular}
        />
      </section>
    </div>
  );
};

export default Subjects;
