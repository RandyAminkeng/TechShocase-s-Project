import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Heart, Users, Zap, Eye, Lightbulb } from "lucide-react";

export default function Psychology() {
  const [assessmentAnswers, setAssessmentAnswers] = useState<{[key: string]: string}>({});

  const psychologyFields = [
    {
      title: "Cognitive Psychology",
      description: "Memory, perception, thinking, and learning",
      icon: Brain,
      color: "text-blue-600",
      topics: ["Memory Systems", "Attention", "Problem Solving", "Language Processing", "Decision Making"]
    },
    {
      title: "Social Psychology",
      description: "How people interact and influence each other",
      icon: Users,
      color: "text-green-600",
      topics: ["Group Dynamics", "Conformity", "Prejudice", "Attribution Theory", "Social Cognition"]
    },
    {
      title: "Clinical Psychology",
      description: "Mental health, disorders, and treatment",
      icon: Heart,
      color: "text-red-600",
      topics: ["Depression", "Anxiety Disorders", "Therapy Methods", "Diagnostic Criteria", "Treatment Planning"]
    },
    {
      title: "Developmental Psychology",
      description: "Human growth and change across lifespan",
      icon: Lightbulb,
      color: "text-yellow-600",
      topics: ["Child Development", "Adolescence", "Adult Development", "Aging", "Developmental Milestones"]
    },
    {
      title: "Neuropsychology",
      description: "Brain-behavior relationships",
      icon: Zap,
      color: "text-purple-600",
      topics: ["Brain Structure", "Neural Networks", "Brain Injuries", "Cognitive Disorders", "Brain Plasticity"]
    },
    {
      title: "Perception Psychology",
      description: "How we process sensory information",
      icon: Eye,
      color: "text-indigo-600",
      topics: ["Visual Perception", "Auditory Processing", "Sensation", "Perceptual Illusions", "Sensory Integration"]
    }
  ];

  const assessmentQuestions = [
    { id: "stress", question: "How often do you feel stressed?", options: ["Never", "Rarely", "Sometimes", "Often", "Always"] },
    { id: "sleep", question: "How would you rate your sleep quality?", options: ["Excellent", "Good", "Fair", "Poor", "Very Poor"] },
    { id: "mood", question: "How has your mood been lately?", options: ["Very Positive", "Positive", "Neutral", "Negative", "Very Negative"] },
    { id: "social", question: "How connected do you feel to others?", options: ["Very Connected", "Connected", "Somewhat", "Disconnected", "Very Disconnected"] }
  ];

  const theorists = [
    { name: "Sigmund Freud", theory: "Psychoanalysis", contribution: "Unconscious mind, defense mechanisms", period: "1856-1939" },
    { name: "Carl Jung", theory: "Analytical Psychology", contribution: "Collective unconscious, archetypes", period: "1875-1961" },
    { name: "B.F. Skinner", theory: "Behaviorism", contribution: "Operant conditioning, reinforcement", period: "1904-1990" },
    { name: "Jean Piaget", theory: "Cognitive Development", contribution: "Stages of cognitive development", period: "1896-1980" },
    { name: "Abraham Maslow", theory: "Humanistic Psychology", contribution: "Hierarchy of needs, self-actualization", period: "1908-1970" },
    { name: "Albert Bandura", theory: "Social Learning Theory", contribution: "Observational learning, self-efficacy", period: "1925-2021" }
  ];

  const experiments = [
    { name: "Stanford Prison Experiment", researcher: "Philip Zimbardo", year: "1971", focus: "Social roles and authority" },
    { name: "Milgram Obedience Study", researcher: "Stanley Milgram", year: "1961", focus: "Obedience to authority" },
    { name: "Little Albert Experiment", researcher: "John Watson", year: "1920", focus: "Classical conditioning" },
    { name: "Asch Conformity Experiments", researcher: "Solomon Asch", year: "1951", focus: "Social conformity" },
    { name: "Harlow's Monkey Studies", researcher: "Harry Harlow", year: "1958", focus: "Attachment and love" },
    { name: "Pavlov's Dogs", researcher: "Ivan Pavlov", year: "1897", focus: "Classical conditioning" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-100 dark:from-gray-900 dark:to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Psychology & Mental Health
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Explore the human mind, behavior, and mental processes through scientific research and practical applications
          </p>
        </div>

        <Tabs defaultValue="fields" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="fields">Psychology Fields</TabsTrigger>
            <TabsTrigger value="assessment">Mental Health Check</TabsTrigger>
            <TabsTrigger value="theorists">Great Theorists</TabsTrigger>
            <TabsTrigger value="experiments">Famous Studies</TabsTrigger>
            <TabsTrigger value="research">Research Tools</TabsTrigger>
          </TabsList>

          <TabsContent value="fields" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {psychologyFields.map((field, index) => {
                const IconComponent = field.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <IconComponent className={`h-8 w-8 ${field.color}`} />
                        <CardTitle className="text-lg">{field.title}</CardTitle>
                      </div>
                      <CardDescription>{field.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Key Topics:</p>
                        <div className="flex flex-wrap gap-1">
                          {field.topics.map((topic, topicIndex) => (
                            <Badge key={topicIndex} variant="outline" className="text-xs">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="assessment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Mental Health Self-Assessment</CardTitle>
                <CardDescription>
                  A quick check-in with your mental and emotional well-being
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {assessmentQuestions.map((question, index) => (
                  <div key={question.id} className="space-y-3">
                    <p className="font-medium">{question.question}</p>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                      {question.options.map((option, optionIndex) => (
                        <Button
                          key={optionIndex}
                          variant={assessmentAnswers[question.id] === option ? "default" : "outline"}
                          size="sm"
                          onClick={() => setAssessmentAnswers(prev => ({ ...prev, [question.id]: option }))}
                          className="text-xs"
                        >
                          {option}
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
                <Button className="w-full mt-6">Get Assessment Results</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="theorists" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {theorists.map((theorist, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {theorist.name}
                      <Badge variant="outline">{theorist.period}</Badge>
                    </CardTitle>
                    <CardDescription className="font-medium text-blue-600 dark:text-blue-400">
                      {theorist.theory}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{theorist.contribution}</p>
                    <Button variant="outline" size="sm" className="w-full">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="experiments" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {experiments.map((experiment, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-lg">{experiment.name}</CardTitle>
                    <div className="flex gap-2">
                      <Badge variant="outline">{experiment.year}</Badge>
                      <Badge variant="secondary">{experiment.researcher}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{experiment.focus}</p>
                    <Button variant="outline" size="sm" className="w-full">
                      Study Details
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="research" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Psychology Research Tools</CardTitle>
                <CardDescription>
                  Access psychological research databases and analysis tools
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Search psychology research, studies, and theories..."
                    className="flex-1"
                  />
                  <Button>Search</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <Brain className="h-8 w-8 text-blue-600 mb-2" />
                      <h3 className="font-semibold mb-2">PsycINFO Database</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Comprehensive psychology literature</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Heart className="h-8 w-8 text-red-600 mb-2" />
                      <h3 className="font-semibold mb-2">Mental Health Resources</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Clinical and therapeutic materials</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Users className="h-8 w-8 text-green-600 mb-2" />
                      <h3 className="font-semibold mb-2">Behavioral Studies</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Social and behavioral research</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}