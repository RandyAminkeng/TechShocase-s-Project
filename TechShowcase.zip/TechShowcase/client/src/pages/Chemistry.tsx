import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { TestTube, Beaker, Atom, Calculator, BookOpen, Users, Search, Play } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Chemistry() {
  const [searchQuery, setSearchQuery] = useState("");
  const [mathProblem, setMathProblem] = useState("");
  const [chatMessage, setChatMessage] = useState("");

  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      return apiRequest(`/api/search`, {
        method: "POST",
        body: JSON.stringify({ 
          query, 
          type: "all",
          context: "chemistry education" 
        }),
        headers: { "Content-Type": "application/json" }
      });
    }
  });

  const mathMutation = useMutation({
    mutationFn: async (problem: string) => {
      return apiRequest(`/api/ai/math`, {
        method: "POST",
        body: JSON.stringify({ problem }),
        headers: { "Content-Type": "application/json" }
      });
    }
  });

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      return apiRequest(`/api/ai/chat`, {
        method: "POST",
        body: JSON.stringify({ 
          message,
          conversationHistory: [],
          context: "chemistry"
        }),
        headers: { "Content-Type": "application/json" }
      });
    }
  });

  const chemistryTopics = [
    {
      title: "General Chemistry",
      description: "Fundamental principles, atomic structure, and chemical bonding",
      icon: "⚛️",
      subtopics: ["Atomic Theory", "Chemical Bonding", "Stoichiometry", "Gas Laws", "Thermochemistry"]
    },
    {
      title: "Organic Chemistry",
      description: "Carbon-based compounds, reactions, and synthesis",
      icon: "🧬",
      subtopics: ["Hydrocarbons", "Functional Groups", "Stereochemistry", "Reaction Mechanisms", "Synthesis"]
    },
    {
      title: "Inorganic Chemistry",
      description: "Non-carbon compounds, metals, and coordination chemistry",
      icon: "💎",
      subtopics: ["Coordination Compounds", "Crystal Field Theory", "Transition Metals", "Solid State", "Acids & Bases"]
    },
    {
      title: "Physical Chemistry",
      description: "Chemical phenomena through physics principles",
      icon: "⚗️",
      subtopics: ["Quantum Chemistry", "Thermodynamics", "Kinetics", "Spectroscopy", "Electrochemistry"]
    },
    {
      title: "Analytical Chemistry",
      description: "Composition analysis and quantitative methods",
      icon: "🔬",
      subtopics: ["Chromatography", "Mass Spectrometry", "Titrations", "Spectrophotometry", "Electroanalysis"]
    },
    {
      title: "Biochemistry",
      description: "Chemical processes in living organisms",
      icon: "🧪",
      subtopics: ["Proteins", "Enzymes", "Metabolism", "DNA/RNA", "Cell Biochemistry"]
    }
  ];

  const handleSearch = () => {
    if (searchQuery.trim()) {
      searchMutation.mutate(searchQuery);
    }
  };

  const handleMathSolve = () => {
    if (mathProblem.trim()) {
      mathMutation.mutate(mathProblem);
    }
  };

  const handleChat = () => {
    if (chatMessage.trim()) {
      chatMutation.mutate(`Chemistry question: ${chatMessage}`);
      setChatMessage("");
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
          <TestTube className="h-10 w-10 text-green-600" />
          Chemistry Learning Center
        </h1>
        <p className="text-xl text-muted-foreground">
          Master the science of matter, its properties, and transformations
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="search">Research</TabsTrigger>
          <TabsTrigger value="calculator">Chemical Calculator</TabsTrigger>
          <TabsTrigger value="chat">AI Tutor</TabsTrigger>
          <TabsTrigger value="lab">Virtual Lab</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {chemistryTopics.map((topic, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">{topic.icon}</span>
                    {topic.title}
                  </CardTitle>
                  <CardDescription>{topic.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {topic.subtopics.map((subtopic, idx) => (
                      <Badge key={idx} variant="secondary" className="mr-2 mb-2">
                        {subtopic}
                      </Badge>
                    ))}
                  </div>
                  <Button className="w-full mt-4" onClick={() => {
                    setSearchQuery(topic.title);
                    handleSearch();
                  }}>
                    <BookOpen className="w-4 h-4 mr-2" />
                    Explore Topic
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Chemistry Research
              </CardTitle>
              <CardDescription>
                Search for chemical concepts, reactions, and educational resources
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Search chemistry topics..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
                <Button onClick={handleSearch} disabled={searchMutation.isPending}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>
              
              {searchMutation.data?.directAnswer && (
                <Card className="border-green-200 bg-green-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Direct Answer</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed">
                      {searchMutation.data.directAnswer.answer}
                    </p>
                    {searchMutation.data.directAnswer.relatedQuestions?.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">Related Questions:</h4>
                        <div className="space-y-1">
                          {searchMutation.data.directAnswer.relatedQuestions.map((q: string, idx: number) => (
                            <Button 
                              key={idx} 
                              variant="outline" 
                              size="sm" 
                              className="mr-2 mb-2"
                              onClick={() => setSearchQuery(q)}
                            >
                              {q}
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {searchMutation.data?.results && (
                <div className="space-y-3">
                  <h3 className="font-semibold">Search Results</h3>
                  {searchMutation.data.results.map((result: any, idx: number) => (
                    <Card key={idx} className="hover:shadow-md transition-shadow">
                      <CardContent className="pt-4">
                        <h4 className="font-medium text-green-600 mb-1">{result.title}</h4>
                        <p className="text-sm text-muted-foreground mb-2">{result.snippet}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="outline">{result.domain}</Badge>
                          <Badge variant="secondary">{result.type}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calculator" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Chemistry Problem Solver
              </CardTitle>
              <CardDescription>
                Solve stoichiometry, equilibrium, and thermodynamics problems
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Enter chemistry problem (e.g., 'Calculate the molarity of 5.0 g NaCl in 250 mL solution')"
                value={mathProblem}
                onChange={(e) => setMathProblem(e.target.value)}
                rows={3}
              />
              <Button onClick={handleMathSolve} disabled={mathMutation.isPending} className="w-full">
                <Calculator className="w-4 h-4 mr-2" />
                Solve Problem
              </Button>
              
              {mathMutation.data && (
                <Card className="border-green-200 bg-green-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Solution</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Answer:</h4>
                      <p className="text-lg font-mono bg-white p-2 rounded border">
                        {mathMutation.data.solution}
                      </p>
                    </div>
                    {mathMutation.data.steps && (
                      <div>
                        <h4 className="font-semibold mb-2">Step-by-step solution:</h4>
                        <div className="space-y-2">
                          {mathMutation.data.steps.map((step: string, idx: number) => (
                            <div key={idx} className="bg-white p-3 rounded border">
                              <div className="font-medium text-sm text-green-600 mb-1">Step {idx + 1}</div>
                              <p className="text-sm">{step}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chat" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Chemistry AI Tutor
              </CardTitle>
              <CardDescription>
                Ask questions about chemical concepts, reactions, and mechanisms
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Ask a chemistry question..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                rows={3}
              />
              <Button onClick={handleChat} disabled={chatMutation.isPending} className="w-full">
                <Users className="w-4 h-4 mr-2" />
                Ask Chemistry Tutor
              </Button>
              
              {chatMutation.data && (
                <Card className="border-purple-200 bg-purple-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Chemistry Tutor Response</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {chatMutation.data.message}
                    </p>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lab" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Beaker className="h-5 w-5" />
                  Virtual Chemistry Lab
                </CardTitle>
                <CardDescription>Interactive simulations and experiments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    "Acid-Base Titrations",
                    "Molecular Modeling",
                    "Reaction Mechanisms",
                    "Periodic Trends Visualization",
                    "Spectroscopy Analysis"
                  ].map((experiment, idx) => (
                    <Button key={idx} variant="outline" className="w-full justify-start">
                      <Play className="w-4 h-4 mr-2" />
                      {experiment}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Chemical Constants & Data</CardTitle>
                <CardDescription>Quick reference for common chemical values</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Avogadro's number (Na):</span>
                    <span className="font-mono">6.022 × 10²³ mol⁻¹</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gas constant (R):</span>
                    <span className="font-mono">8.314 J/(mol·K)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Planck constant (h):</span>
                    <span className="font-mono">6.626 × 10⁻³⁴ J·s</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Boltzmann constant (k):</span>
                    <span className="font-mono">1.381 × 10⁻²³ J/K</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Faraday constant (F):</span>
                    <span className="font-mono">96,485 C/mol</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}