import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Brain, 
  Send, 
  BookOpen, 
  Lightbulb, 
  MessageSquare, 
  History, 
  User, 
  Bot,
  Calculator,
  Beaker,
  Globe,
  Atom,
  Languages,
  FileText,
  Music,
  DollarSign,
  Briefcase,
  Computer,
  TreePine,
  Camera,
  Scale,
  Feather,
  Heart,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  RefreshCw,
  Star,
  ThumbsUp,
  ThumbsDown,
  Download,
  Share
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  subject?: string;
}

interface TutorResponse {
  answer: string;
  explanation: string;
  resources?: {
    title: string;
    description: string;
    url?: string;
  }[];
  followUpQuestions?: string[];
}

const subjects = [
  { id: 'mathematics', name: 'Mathematics', icon: Calculator },
  { id: 'science', name: 'Science', icon: Atom },
  { id: 'physics', name: 'Physics', icon: Beaker },
  { id: 'chemistry', name: 'Chemistry', icon: Beaker },
  { id: 'biology', name: 'Biology', icon: TreePine },
  { id: 'history', name: 'History', icon: Globe },
  { id: 'literature', name: 'Literature', icon: Feather },
  { id: 'languages', name: 'Languages', icon: Languages },
  { id: 'psychology', name: 'Psychology', icon: Heart },
  { id: 'philosophy', name: 'Philosophy', icon: Brain },
  { id: 'computer-science', name: 'Computer Science', icon: Computer },
  { id: 'economics', name: 'Economics', icon: DollarSign },
  { id: 'business', name: 'Business', icon: Briefcase },
  { id: 'art', name: 'Art', icon: Camera },
  { id: 'music', name: 'Music', icon: Music }
];

export default function AiTutor() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('mathematics');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognition = useRef<any>(null);
  const synthesis = useRef<any>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize speech recognition and synthesis
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Speech Recognition
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognition.current = new SpeechRecognition();
        recognition.current.continuous = false;
        recognition.current.interimResults = false;
        recognition.current.lang = 'en-US';

        recognition.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setInputMessage(transcript);
          setIsListening(false);
        };

        recognition.current.onerror = () => {
          setIsListening(false);
        };

        recognition.current.onend = () => {
          setIsListening(false);
        };
      }

      // Speech Synthesis
      if ('speechSynthesis' in window) {
        synthesis.current = window.speechSynthesis;
      }
    }
  }, []);

  // Fetch chat history
  const { data: chatHistory = [] } = useQuery<any[]>({
    queryKey: ['/api/tutor/history', 1],
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/api/tutor/chat', {
        method: 'POST',
        body: JSON.stringify({
          question: data.question,
          subject: selectedSubject,
          userId: 1
        }),
      });
    },
    onSuccess: (response: any) => {
      const assistantMessage: ChatMessage = {
        id: Date.now().toString() + '_assistant',
        role: 'assistant',
        content: response.message,
        timestamp: new Date().toISOString(),
        subject: selectedSubject
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Text-to-speech for response
      if (speechEnabled && synthesis.current) {
        const utterance = new SpeechSynthesisUtterance(response.message);
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        synthesis.current.speak(utterance);
      }

      queryClient.invalidateQueries({ queryKey: ['/api/tutor/history'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString() + '_user',
      role: 'user',
      content: inputMessage.trim(),
      timestamp: new Date().toISOString(),
      subject: selectedSubject
    };

    setMessages(prev => [...prev, userMessage]);

    sendMessageMutation.mutate({
      question: inputMessage.trim(),
      subject: selectedSubject,
      userId: 1
    });

    setInputMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const startListening = () => {
    if (recognition.current && !isListening) {
      setIsListening(true);
      recognition.current.start();
    }
  };

  const stopListening = () => {
    if (recognition.current && isListening) {
      recognition.current.stop();
    }
  };

  const stopSpeaking = () => {
    if (synthesis.current) {
      synthesis.current.cancel();
      setIsSpeaking(false);
    }
  };

  const handleSampleQuestion = (question: string) => {
    setInputMessage(question);
  };

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sampleQuestions = {
    mathematics: [
      "Explain the Pythagorean theorem with examples",
      "How do I solve quadratic equations?",
      "What is calculus and when do I use it?",
      "Explain the concept of derivatives"
    ],
    science: [
      "How does photosynthesis work?",
      "Explain Newton's laws of motion",
      "What is the difference between mass and weight?",
      "How do chemical reactions occur?"
    ],
    history: [
      "What caused World War I?",
      "Explain the Industrial Revolution",
      "Who was Leonardo da Vinci?",
      "What was the Renaissance period?"
    ],
    literature: [
      "Analyze the themes in Romeo and Juliet",
      "What is symbolism in literature?",
      "Explain different types of poetry",
      "How do I write a compelling essay?"
    ]
  };

  const currentSamples = sampleQuestions[selectedSubject as keyof typeof sampleQuestions] || sampleQuestions.mathematics;
  const selectedSubjectInfo = subjects.find(s => s.id === selectedSubject);

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="flex items-center gap-3 mb-6">
        <Brain className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold dark:text-white">AI Tutor</h1>
          <p className="text-neutral-600 dark:text-neutral-400">Get personalized help with your studies</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Subject</CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => {
                    const Icon = subject.icon;
                    return (
                      <SelectItem key={subject.id} value={subject.id}>
                        <div className="flex items-center gap-2">
                          <Icon className="h-4 w-4" />
                          {subject.name}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Voice Features</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Text-to-Speech</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSpeechEnabled(!speechEnabled)}
                >
                  {speechEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
              </div>
              
              {recognition.current && (
                <div className="flex gap-2">
                  <Button
                    variant={isListening ? "destructive" : "outline"}
                    size="sm"
                    onClick={isListening ? stopListening : startListening}
                    disabled={sendMessageMutation.isPending}
                  >
                    {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  </Button>
                  {isSpeaking && (
                    <Button variant="outline" size="sm" onClick={stopSpeaking}>
                      Stop
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Sample Questions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {currentSamples.map((question, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="sm"
                  className="w-full text-left h-auto p-2 text-wrap"
                  onClick={() => handleSampleQuestion(question)}
                >
                  <Lightbulb className="h-3 w-3 mr-2 flex-shrink-0" />
                  {question}
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Main Chat Area */}
        <div className="lg:col-span-3">
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="border-b">
              <CardTitle className="flex items-center gap-2">
                {selectedSubjectInfo && <selectedSubjectInfo.icon className="h-5 w-5" />}
                {selectedSubjectInfo?.name} Tutor
                <Badge variant="outline" className="ml-auto">
                  {messages.length} messages
                </Badge>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col p-0">
              {/* Messages Area */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.length === 0 && (
                    <div className="text-center py-8 text-neutral-500">
                      <Bot className="h-12 w-12 mx-auto mb-4 text-neutral-400" />
                      <p>Start a conversation with your AI tutor!</p>
                      <p className="text-sm mt-2">Ask questions about {selectedSubjectInfo?.name.toLowerCase()} or use the sample questions.</p>
                    </div>
                  )}
                  
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex gap-3 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          message.role === 'user' 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-neutral-200 dark:bg-neutral-700'
                        }`}>
                          {message.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                        </div>
                        
                        <div className={`rounded-lg p-3 ${
                          message.role === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-neutral-100 dark:bg-neutral-800 border'
                        }`}>
                          <p className="whitespace-pre-wrap">{message.content}</p>
                          <div className={`text-xs mt-2 ${
                            message.role === 'user' ? 'text-blue-100' : 'text-neutral-500'
                          }`}>
                            {new Date(message.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {sendMessageMutation.isPending && (
                    <div className="flex gap-3 justify-start">
                      <div className="w-8 h-8 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center">
                        <Bot className="h-4 w-4" />
                      </div>
                      <div className="bg-neutral-100 dark:bg-neutral-800 border rounded-lg p-3">
                        <div className="flex items-center gap-2">
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          AI tutor is thinking...
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <div ref={messagesEndRef} />
              </ScrollArea>

              {/* Input Area */}
              <div className="border-t p-4">
                <div className="flex gap-2">
                  <div className="flex-1">
                    <Textarea
                      placeholder={`Ask your ${selectedSubjectInfo?.name.toLowerCase()} question...`}
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      rows={2}
                      className="resize-none"
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    {recognition.current && (
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={isListening ? stopListening : startListening}
                        disabled={sendMessageMutation.isPending}
                      >
                        {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                      </Button>
                    )}
                    <Button
                      onClick={handleSendMessage}
                      disabled={!inputMessage.trim() || sendMessageMutation.isPending}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                {isListening && (
                  <div className="mt-2 text-sm text-blue-600 flex items-center gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    Listening... Speak your question
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}