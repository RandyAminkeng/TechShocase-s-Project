import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { 
  Pen, 
  Eraser, 
  Square, 
  Circle, 
  Minus, 
  Type, 
  Palette, 
  Undo, 
  Redo, 
  Download, 
  Share, 
  Users, 
  Bot,
  Loader2,
  Lightbulb,
  Camera,
  Save
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface DrawingPoint {
  x: number;
  y: number;
  tool: string;
  color: string;
  size: number;
  timestamp: number;
  userId?: string;
}

interface DrawingPath {
  id: string;
  points: DrawingPoint[];
  tool: string;
  color: string;
  size: number;
  userId?: string;
  timestamp: number;
}

interface CollaboratorCursor {
  userId: string;
  username: string;
  x: number;
  y: number;
  color: string;
  lastSeen: number;
}

interface AIExplanation {
  content: string;
  confidence: number;
  suggestions: string[];
  relatedConcepts: string[];
}

export default function Whiteboard() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentTool, setCurrentTool] = useState("pen");
  const [currentColor, setCurrentColor] = useState("#000000");
  const [currentSize, setCurrentSize] = useState(3);
  const [paths, setPaths] = useState<DrawingPath[]>([]);
  const [currentPath, setCurrentPath] = useState<DrawingPoint[]>([]);
  const [collaborators, setCollaborators] = useState<CollaboratorCursor[]>([]);
  const [aiExplanation, setAiExplanation] = useState<AIExplanation | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [roomId] = useState(`room_${Date.now()}`);
  const [undoStack, setUndoStack] = useState<DrawingPath[][]>([]);
  const [redoStack, setRedoStack] = useState<DrawingPath[][]>([]);

  const wsRef = useRef<WebSocket | null>(null);

  // Available colors
  const colors = [
    "#000000", "#FF0000", "#00FF00", "#0000FF", "#FFFF00", 
    "#FF00FF", "#00FFFF", "#FFA500", "#800080", "#008000",
    "#FFC0CB", "#A52A2A", "#808080", "#000080", "#800000"
  ];

  // Tools configuration
  const tools = [
    { id: "pen", icon: Pen, label: "Pen" },
    { id: "eraser", icon: Eraser, label: "Eraser" },
    { id: "line", icon: Minus, label: "Line" },
    { id: "rectangle", icon: Square, label: "Rectangle" },
    { id: "circle", icon: Circle, label: "Circle" },
    { id: "text", icon: Type, label: "Text" }
  ];

  // Initialize WebSocket connection for real-time collaboration
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    wsRef.current = new WebSocket(wsUrl);
    
    wsRef.current.onopen = () => {
      console.log("Connected to collaboration server");
      // Join whiteboard room
      wsRef.current?.send(JSON.stringify({
        type: "join_whiteboard",
        roomId,
        userId: `user_${Date.now()}`,
        username: `User ${Math.floor(Math.random() * 1000)}`
      }));
    };

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleWebSocketMessage(data);
    };

    wsRef.current.onclose = () => {
      console.log("Disconnected from collaboration server");
    };

    return () => {
      wsRef.current?.close();
    };
  }, [roomId]);

  const handleWebSocketMessage = (data: any) => {
    switch (data.type) {
      case "drawing_update":
        setPaths(prev => [...prev, data.path]);
        redrawCanvas();
        break;
      case "cursor_update":
        setCollaborators(prev => 
          prev.filter(c => c.userId !== data.userId).concat({
            userId: data.userId,
            username: data.username,
            x: data.x,
            y: data.y,
            color: data.color,
            lastSeen: Date.now()
          })
        );
        break;
      case "user_joined":
        console.log(`${data.username} joined the whiteboard`);
        break;
      case "user_left":
        setCollaborators(prev => prev.filter(c => c.userId !== data.userId));
        break;
    }
  };

  // AI analysis mutation
  const analyzeDrawingMutation = useMutation({
    mutationFn: async (): Promise<AIExplanation> => {
      const canvas = canvasRef.current;
      if (!canvas) throw new Error("Canvas not available");
      
      const imageData = canvas.toDataURL("image/png").split(",")[1];
      
      return await apiRequest('/api/ai/analyze-drawing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageData,
          context: "educational_whiteboard"
        })
      });
    },
    onSuccess: (explanation) => {
      setAiExplanation(explanation);
      setIsAnalyzing(false);
    },
    onError: () => {
      setIsAnalyzing(false);
    }
  });

  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw all paths
    paths.forEach(path => {
      if (path.points.length < 2) return;

      ctx.beginPath();
      ctx.strokeStyle = path.color;
      ctx.lineWidth = path.size;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      if (path.tool === "eraser") {
        ctx.globalCompositeOperation = "destination-out";
      } else {
        ctx.globalCompositeOperation = "source-over";
      }

      if (path.tool === "pen" || path.tool === "eraser") {
        ctx.moveTo(path.points[0].x, path.points[0].y);
        path.points.forEach(point => {
          ctx.lineTo(point.x, point.y);
        });
        ctx.stroke();
      } else if (path.tool === "line") {
        const start = path.points[0];
        const end = path.points[path.points.length - 1];
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.stroke();
      } else if (path.tool === "rectangle") {
        const start = path.points[0];
        const end = path.points[path.points.length - 1];
        const width = end.x - start.x;
        const height = end.y - start.y;
        ctx.strokeRect(start.x, start.y, width, height);
      } else if (path.tool === "circle") {
        const start = path.points[0];
        const end = path.points[path.points.length - 1];
        const radius = Math.sqrt(Math.pow(end.x - start.x, 2) + Math.pow(end.y - start.y, 2));
        ctx.beginPath();
        ctx.arc(start.x, start.y, radius, 0, 2 * Math.PI);
        ctx.stroke();
      }
    });

    // Draw current path being drawn
    if (currentPath.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = currentSize;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.globalCompositeOperation = currentTool === "eraser" ? "destination-out" : "source-over";

      ctx.moveTo(currentPath[0].x, currentPath[0].y);
      currentPath.forEach(point => {
        ctx.lineTo(point.x, point.y);
      });
      ctx.stroke();
    }

    // Draw collaborator cursors
    collaborators.forEach(collaborator => {
      if (Date.now() - collaborator.lastSeen < 5000) { // Show cursor for 5 seconds
        ctx.fillStyle = collaborator.color;
        ctx.beginPath();
        ctx.arc(collaborator.x, collaborator.y, 5, 0, 2 * Math.PI);
        ctx.fill();
        
        // Username label
        ctx.fillStyle = "#000";
        ctx.font = "12px Arial";
        ctx.fillText(collaborator.username, collaborator.x + 10, collaborator.y - 10);
      }
    });
  }, [paths, currentPath, currentColor, currentSize, currentTool, collaborators]);

  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pos = getMousePos(e);
    setIsDrawing(true);
    setCurrentPath([{
      x: pos.x,
      y: pos.y,
      tool: currentTool,
      color: currentColor,
      size: currentSize,
      timestamp: Date.now()
    }]);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    
    const pos = getMousePos(e);
    setCurrentPath(prev => [...prev, {
      x: pos.x,
      y: pos.y,
      tool: currentTool,
      color: currentColor,
      size: currentSize,
      timestamp: Date.now()
    }]);

    // Send cursor position to other collaborators
    wsRef.current?.send(JSON.stringify({
      type: "cursor_update",
      roomId,
      x: pos.x,
      y: pos.y
    }));
  };

  const stopDrawing = () => {
    if (!isDrawing || currentPath.length === 0) return;
    
    setIsDrawing(false);
    
    const newPath: DrawingPath = {
      id: `path_${Date.now()}`,
      points: currentPath,
      tool: currentTool,
      color: currentColor,
      size: currentSize,
      timestamp: Date.now()
    };

    // Add to undo stack
    setUndoStack(prev => [...prev, paths]);
    setRedoStack([]); // Clear redo stack when new action is performed

    setPaths(prev => [...prev, newPath]);
    setCurrentPath([]);

    // Send drawing update to other collaborators
    wsRef.current?.send(JSON.stringify({
      type: "drawing_update",
      roomId,
      path: newPath
    }));
  };

  const undo = () => {
    if (undoStack.length === 0) return;
    
    const previousState = undoStack[undoStack.length - 1];
    setRedoStack(prev => [...prev, paths]);
    setPaths(previousState);
    setUndoStack(prev => prev.slice(0, -1));
  };

  const redo = () => {
    if (redoStack.length === 0) return;
    
    const nextState = redoStack[redoStack.length - 1];
    setUndoStack(prev => [...prev, paths]);
    setPaths(nextState);
    setRedoStack(prev => prev.slice(0, -1));
  };

  const clearCanvas = () => {
    setUndoStack(prev => [...prev, paths]);
    setRedoStack([]);
    setPaths([]);
    setCurrentPath([]);
  };

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const link = document.createElement("a");
    link.download = `whiteboard_${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  const analyzeDrawing = () => {
    setIsAnalyzing(true);
    analyzeDrawingMutation.mutate();
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">AI Collaboration Whiteboard</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Real-time collaborative drawing with AI-powered explanations
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            {collaborators.length + 1} Active
          </Badge>
          <Badge variant="outline">Room: {roomId.slice(-6)}</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Drawing Tools */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5" />
              Drawing Tools
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Tool Selection */}
            <div>
              <label className="text-sm font-medium mb-2 block">Tools</label>
              <div className="grid grid-cols-3 gap-2">
                {tools.map(tool => (
                  <Button
                    key={tool.id}
                    variant={currentTool === tool.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentTool(tool.id)}
                    className="flex flex-col items-center gap-1 h-auto py-2"
                  >
                    <tool.icon className="w-4 h-4" />
                    <span className="text-xs">{tool.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Color Selection */}
            <div>
              <label className="text-sm font-medium mb-2 block">Color</label>
              <div className="grid grid-cols-5 gap-2">
                {colors.map(color => (
                  <button
                    key={color}
                    className={`w-8 h-8 rounded border-2 ${
                      currentColor === color ? "border-gray-800 dark:border-gray-200" : "border-gray-300"
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={() => setCurrentColor(color)}
                  />
                ))}
              </div>
              <input
                type="color"
                value={currentColor}
                onChange={(e) => setCurrentColor(e.target.value)}
                className="w-full mt-2 h-8 rounded border"
              />
            </div>

            {/* Brush Size */}
            <div>
              <label className="text-sm font-medium mb-2 block">
                Size: {currentSize}px
              </label>
              <Slider
                value={[currentSize]}
                onValueChange={(value) => setCurrentSize(value[0])}
                min={1}
                max={50}
                step={1}
                className="w-full"
              />
            </div>

            {/* Actions */}
            <Separator />
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" onClick={undo} disabled={undoStack.length === 0}>
                  <Undo className="w-4 h-4 mr-1" />
                  Undo
                </Button>
                <Button variant="outline" size="sm" onClick={redo} disabled={redoStack.length === 0}>
                  <Redo className="w-4 h-4 mr-1" />
                  Redo
                </Button>
              </div>
              <Button variant="outline" size="sm" onClick={clearCanvas} className="w-full">
                Clear All
              </Button>
              <Button variant="outline" size="sm" onClick={downloadCanvas} className="w-full">
                <Download className="w-4 h-4 mr-1" />
                Download
              </Button>
              <Button 
                variant="default" 
                size="sm" 
                onClick={analyzeDrawing}
                disabled={isAnalyzing || paths.length === 0}
                className="w-full"
              >
                {isAnalyzing ? (
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                ) : (
                  <Bot className="w-4 h-4 mr-1" />
                )}
                AI Analyze
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Canvas Area */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pen className="w-5 h-5" />
              Whiteboard Canvas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg overflow-hidden">
              <canvas
                ref={canvasRef}
                width={800}
                height={600}
                className="cursor-crosshair bg-white"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
              />
            </div>
          </CardContent>
        </Card>

        {/* AI Analysis Panel */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5" />
              AI Assistant
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isAnalyzing && (
              <div className="flex items-center gap-2 text-blue-600">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">Analyzing drawing...</span>
              </div>
            )}

            {aiExplanation && (
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h4 className="font-semibold mb-2">AI Analysis</h4>
                  <p className="text-sm">{aiExplanation.content}</p>
                  <div className="mt-2">
                    <Badge variant="secondary">
                      Confidence: {Math.round(aiExplanation.confidence * 100)}%
                    </Badge>
                  </div>
                </div>

                {aiExplanation.suggestions.length > 0 && (
                  <div>
                    <h5 className="font-semibold mb-2">Suggestions</h5>
                    <ul className="text-sm space-y-1">
                      {aiExplanation.suggestions.map((suggestion, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-blue-500">•</span>
                          <span>{suggestion}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {aiExplanation.relatedConcepts.length > 0 && (
                  <div>
                    <h5 className="font-semibold mb-2">Related Concepts</h5>
                    <div className="flex flex-wrap gap-1">
                      {aiExplanation.relatedConcepts.map((concept, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {concept}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {!aiExplanation && !isAnalyzing && (
              <div className="text-center py-8 text-gray-500">
                <Bot className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p className="text-sm">Draw something and click "AI Analyze" to get intelligent explanations and suggestions!</p>
              </div>
            )}

            {/* Active Collaborators */}
            <Separator />
            <div>
              <h5 className="font-semibold mb-2">Active Users</h5>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  You (Host)
                </div>
                {collaborators.map(collaborator => (
                  <div key={collaborator.userId} className="flex items-center gap-2 text-sm">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: collaborator.color }}
                    ></div>
                    {collaborator.username}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}