import { useQuery } from "@tanstack/react-query";
import ProgressCard from "@/components/Progress/ProgressCard";
import CourseProgressCard from "@/components/Progress/CourseProgressCard";
import { getUserStats, getUserProgress } from "@/lib/api";
import { format } from "date-fns";

const Progress = () => {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/stats/1'],
    staleTime: 60000 // 1 minute
  });

  const { data: progress, isLoading: progressLoading } = useQuery({
    queryKey: ['/api/progress/1'],
    staleTime: 60000 // 1 minute
  });

  // Format date for "last activity"
  const formatLastActivity = (date: string) => {
    const lastActivity = new Date(date);
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return "Today";
    } else if (diffInDays === 1) {
      return "Yesterday";
    } else {
      return `${diffInDays} days ago`;
    }
  };

  return (
    <div className="p-6">
      <header className="mb-6">
        <h2 className="font-heading text-2xl font-bold text-neutral-800 dark:text-white">Progress Tracker</h2>
        <p className="text-neutral-500 dark:text-neutral-400">Monitor your learning achievements</p>
      </header>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {statsLoading ? (
          // Skeleton loaders for stats
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="h-32 bg-white rounded-xl shadow-sm animate-pulse dark:bg-neutral-800"></div>
          ))
        ) : (
          <>
            <ProgressCard
              icon="school"
              iconColor="primary"
              title="Courses Completed"
              value={7}
              total={20}
              percentage={35}
            />
            <ProgressCard
              icon="assignment_turned_in"
              iconColor="secondary"
              title="Lessons Completed"
              value={stats?.completedLessons || 0}
              total={200}
              percentage={stats ? Math.round((stats.completedLessons / 200) * 100) : 0}
            />
            <ProgressCard
              icon="quiz"
              iconColor="accent"
              title="Quiz Score Average"
              value={stats?.quizAverage || 0}
              unit="%"
              percentage={stats?.quizAverage || 0}
            />
          </>
        )}
      </div>

      {/* Weekly Activity */}
      <section className="mb-8">
        <h3 className="font-heading text-xl font-semibold mb-4 dark:text-white">Weekly Activity</h3>
        
        <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 dark:bg-neutral-800 dark:border-neutral-700">
          <div className="flex justify-between mb-6">
            <div>
              <h4 className="font-medium dark:text-white">Learning Time (hours)</h4>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Last 7 days</p>
            </div>
            <select className="bg-white px-3 py-1 text-sm rounded border border-neutral-300 dark:bg-neutral-700 dark:border-neutral-600 dark:text-white">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 90 days</option>
            </select>
          </div>
          
          {/* Activity Chart (Simplified) */}
          <div className="h-64 flex items-end justify-between space-x-2">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => {
              // Generate mock heights for the chart bars
              const heights = [40, 65, 30, 80, 90, 50, 20];
              const barClass = i === 4 ? "bg-primary" : "bg-primary-light";
              
              return (
                <div key={day} className="flex flex-col items-center w-full">
                  <div className={`${barClass} rounded-t w-full dark:opacity-80`} style={{ height: `${heights[i]}%` }}></div>
                  <p className="text-xs mt-2 dark:text-neutral-300">{day}</p>
                </div>
              );
            })}
          </div>
          
          <div className="flex justify-center mt-4">
            <div className="flex items-center space-x-8">
              <div>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">Total Time</p>
                <p className="font-medium dark:text-white">12.5 hours</p>
              </div>
              <div>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">Daily Average</p>
                <p className="font-medium dark:text-white">1.8 hours</p>
              </div>
              <div>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">Best Day</p>
                <p className="font-medium dark:text-white">Friday (3.2h)</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Course Progress */}
      <section>
        <h3 className="font-heading text-xl font-semibold mb-4 dark:text-white">Course Progress</h3>
        
        <div className="space-y-4">
          {progressLoading ? (
            // Skeleton loaders for course progress
            Array(2).fill(0).map((_, i) => (
              <div key={i} className="h-48 bg-white rounded-xl shadow-sm animate-pulse dark:bg-neutral-800"></div>
            ))
          ) : (
            progress?.map((item: any) => (
              <CourseProgressCard
                key={item.courseId}
                id={item.courseId}
                title={item.course?.name || "Course"}
                subject={item.course?.subjectId === 1 ? "Mathematics" : 
                         item.course?.subjectId === 2 ? "Science" : "Languages"}
                icon={item.course?.subjectId === 1 ? "calculate" : 
                      item.course?.subjectId === 2 ? "science" : "language"}
                iconColor={item.course?.subjectId === 1 ? "primary" : 
                           item.course?.subjectId === 2 ? "secondary" : "accent"}
                lessonsCompleted={item.completedLessons}
                totalLessons={item.course?.totalLessons || 0}
                progress={item.progress}
                lastActivity={formatLastActivity(item.lastActivity)}
                quizzesPassed={Math.floor(Math.random() * 5) + 1} // Mock data for demo
              />
            ))
          )}
        </div>
      </section>
    </div>
  );
};

export default Progress;
