import { useState, useEffect } from 'react';
import { useRoute } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface Question {
  id: number;
  type: 'multiple-choice' | 'short-answer' | 'problem-solving';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  points: number;
}

interface Lesson {
  id: number;
  title: string;
  subject: string;
  content: string;
  difficulty: string;
  estimatedTime: string;
  objectives: string[];
  questions: Question[];
}

// Real lesson data with comprehensive educational content
const realLessons: Lesson[] = [
  {
    id: 1,
    title: "Linear Equations and Problem Solving",
    subject: "Mathematics",
    content: `
# Linear Equations and Problem Solving

## What is a Linear Equation?

A linear equation is an equation that makes a straight line when graphed. It has the general form:
**ax + b = c**

Where:
- a, b, and c are constants
- x is the variable we're solving for
- The highest power of x is 1

## Key Properties

1. **Addition Property**: If you add the same number to both sides of an equation, the equation remains true
2. **Subtraction Property**: If you subtract the same number from both sides, the equation remains true
3. **Multiplication Property**: If you multiply both sides by the same non-zero number, the equation remains true
4. **Division Property**: If you divide both sides by the same non-zero number, the equation remains true

## Solving Steps

1. **Simplify** both sides of the equation
2. **Isolate** the variable term on one side
3. **Solve** for the variable
4. **Check** your answer by substituting back

## Example Problem

Solve: 3x + 7 = 22

**Step 1**: Subtract 7 from both sides
3x + 7 - 7 = 22 - 7
3x = 15

**Step 2**: Divide both sides by 3
3x ÷ 3 = 15 ÷ 3
x = 5

**Step 3**: Check: 3(5) + 7 = 15 + 7 = 22 ✓

## Real-World Applications

Linear equations are used in:
- **Business**: Calculating profit and loss
- **Science**: Converting temperatures (F to C)
- **Engineering**: Designing slopes and gradients
- **Economics**: Supply and demand relationships
    `,
    difficulty: "Intermediate",
    estimatedTime: "25 minutes",
    objectives: [
      "Understand the definition and properties of linear equations",
      "Apply the four properties to solve equations",
      "Solve multi-step linear equations systematically",
      "Check solutions by substitution",
      "Apply linear equations to real-world problems"
    ],
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: "What is the solution to the equation 2x + 5 = 13?",
        options: ["x = 4", "x = 6", "x = 8", "x = 9"],
        correctAnswer: "x = 4",
        explanation: "Subtract 5 from both sides: 2x = 8. Then divide by 2: x = 4.",
        points: 10
      },
      {
        id: 2,
        type: 'problem-solving',
        question: "A taxi charges $3.50 for the first mile and $1.25 for each additional mile. If your total fare is $9.25, how many miles did you travel?",
        correctAnswer: "5.6 miles",
        explanation: "Set up equation: 3.50 + 1.25(x-1) = 9.25. Solving: 1.25(x-1) = 5.75, so x-1 = 4.6, therefore x = 5.6 miles.",
        points: 15
      },
      {
        id: 3,
        type: 'short-answer',
        question: "Solve for x: 4(x - 3) = 2x + 6",
        correctAnswer: "x = 9",
        explanation: "Expand: 4x - 12 = 2x + 6. Subtract 2x: 2x - 12 = 6. Add 12: 2x = 18. Divide by 2: x = 9.",
        points: 12
      }
    ]
  },
  {
    id: 2,
    title: "Introduction to Chemical Reactions",
    subject: "Science", 
    content: `
# Chemical Reactions

## What is a Chemical Reaction?

A chemical reaction is a process where substances (reactants) are transformed into new substances (products) with different chemical properties.

## Types of Chemical Reactions

### 1. Synthesis (Combination)
Two or more simple substances combine to form a more complex substance.
**General form**: A + B → AB
**Example**: 2H₂ + O₂ → 2H₂O (formation of water)

### 2. Decomposition
A complex substance breaks down into simpler substances.
**General form**: AB → A + B  
**Example**: 2H₂O₂ → 2H₂O + O₂ (hydrogen peroxide decomposition)

### 3. Single Replacement
One element replaces another in a compound.
**General form**: A + BC → AC + B
**Example**: Zn + CuSO₄ → ZnSO₄ + Cu

### 4. Double Replacement
Two compounds exchange ions.
**General form**: AB + CD → AD + CB
**Example**: AgNO₃ + NaCl → AgCl + NaNO₃

## Balancing Chemical Equations

Chemical equations must be balanced to follow the Law of Conservation of Mass.

### Steps to Balance:
1. **Count** atoms of each element on both sides
2. **Add coefficients** to balance each element
3. **Check** that all elements are balanced
4. **Verify** using the smallest whole number coefficients

### Example:
Balance: H₂ + O₂ → H₂O

**Step 1**: H₂ + O₂ → H₂O
- Left: 2 H, 2 O
- Right: 2 H, 1 O (unbalanced)

**Step 2**: H₂ + O₂ → 2H₂O  
- Left: 2 H, 2 O
- Right: 4 H, 2 O (H unbalanced)

**Step 3**: 2H₂ + O₂ → 2H₂O
- Left: 4 H, 2 O
- Right: 4 H, 2 O (balanced!)

## Signs of Chemical Reactions

- Color change
- Gas production (bubbling)
- Precipitate formation
- Temperature change
- Light emission
    `,
    difficulty: "Beginner",
    estimatedTime: "30 minutes",
    objectives: [
      "Identify the four main types of chemical reactions",
      "Understand the Law of Conservation of Mass",
      "Balance simple chemical equations",
      "Recognize signs of chemical reactions",
      "Apply reaction types to real examples"
    ],
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: "What type of reaction is: 2H₂O → 2H₂ + O₂?",
        options: ["Synthesis", "Decomposition", "Single Replacement", "Double Replacement"],
        correctAnswer: "Decomposition",
        explanation: "This is decomposition because one compound (H₂O) breaks down into simpler substances (H₂ and O₂).",
        points: 8
      },
      {
        id: 2,
        type: 'short-answer',
        question: "Balance this equation: Fe + O₂ → Fe₂O₃",
        correctAnswer: "4Fe + 3O₂ → 2Fe₂O₃",
        explanation: "To balance: 4 Fe atoms and 6 O atoms on each side. The balanced equation is 4Fe + 3O₂ → 2Fe₂O₃.",
        points: 12
      },
      {
        id: 3,
        type: 'problem-solving',
        question: "In the reaction Mg + HCl → MgCl₂ + H₂, if you start with 24g of Mg, how many moles of H₂ gas will be produced?",
        correctAnswer: "1 mole",
        explanation: "24g Mg = 1 mole Mg. From the balanced equation Mg + 2HCl → MgCl₂ + H₂, 1 mole Mg produces 1 mole H₂.",
        points: 15
      }
    ]
  },
  {
    id: 3,
    title: "Introduction to Programming with Python",
    subject: "Computer Science",
    content: `
# Introduction to Programming with Python

## What is Programming?

Programming is the process of creating instructions for computers to follow. Python is a popular programming language known for its simplicity and readability.

## Why Python?

- **Easy to learn**: Simple, readable syntax
- **Versatile**: Used for web development, data science, AI, automation
- **Large community**: Extensive libraries and support
- **Cross-platform**: Runs on Windows, Mac, and Linux

## Basic Python Concepts

### 1. Variables and Data Types

Variables store data that can be used later in your program.

**Example:**
\`\`\`python
# Numbers
age = 25
height = 5.9

# Text (strings)
name = "Alice"
message = "Hello, World!"

# Boolean (True/False)
is_student = True
has_license = False
\`\`\`

### 2. Basic Operations

**Arithmetic Operations:**
\`\`\`python
# Addition
result = 10 + 5    # 15

# Subtraction  
result = 10 - 3    # 7

# Multiplication
result = 4 * 6     # 24

# Division
result = 15 / 3    # 5.0
\`\`\`

### 3. Input and Output

**Getting user input:**
\`\`\`python
name = input("What's your name? ")
print("Hello, " + name + "!")
\`\`\`

### 4. Conditional Statements

Make decisions in your code:
\`\`\`python
age = int(input("Enter your age: "))

if age >= 18:
    print("You are an adult")
elif age >= 13:
    print("You are a teenager")
else:
    print("You are a child")
\`\`\`

### 5. Loops

Repeat actions:
\`\`\`python
# For loop - repeat a specific number of times
for i in range(5):
    print("Count:", i)

# While loop - repeat while condition is true
count = 0
while count < 3:
    print("Loop number:", count)
    count += 1
\`\`\`

## Your First Program

Let's create a simple calculator:
\`\`\`python
print("Simple Calculator")
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))
operation = input("Enter operation (+, -, *, /): ")

if operation == "+":
    result = num1 + num2
elif operation == "-":
    result = num1 - num2
elif operation == "*":
    result = num1 * num2
elif operation == "/":
    if num2 != 0:
        result = num1 / num2
    else:
        result = "Error: Division by zero"
else:
    result = "Error: Invalid operation"

print("Result:", result)
\`\`\`

## Best Practices

1. **Use meaningful variable names**: \`user_age\` instead of \`x\`
2. **Add comments**: Explain what your code does
3. **Test your code**: Run it with different inputs
4. **Keep it simple**: Break complex problems into smaller parts
    `,
    difficulty: "Beginner",
    estimatedTime: "40 minutes",
    objectives: [
      "Understand what programming is and why Python is popular",
      "Learn basic data types: numbers, strings, booleans",
      "Use variables to store and manipulate data",
      "Write conditional statements to make decisions",
      "Create loops to repeat actions",
      "Build a simple calculator program"
    ],
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: "Which of the following is a valid Python variable name?",
        options: ["2user_name", "user-name", "user_name", "user name"],
        correctAnswer: "user_name",
        explanation: "Python variable names must start with a letter or underscore, and can contain letters, numbers, and underscores. No spaces or hyphens allowed.",
        points: 8
      },
      {
        id: 2,
        type: 'short-answer',
        question: "What will this code print?\n\nage = 16\nif age >= 18:\n    print('Adult')\nelse:\n    print('Minor')",
        correctAnswer: "Minor",
        explanation: "Since age (16) is less than 18, the condition is False, so the else block executes and prints 'Minor'.",
        points: 10
      },
      {
        id: 3,
        type: 'problem-solving',
        question: "Write Python code to calculate the area of a rectangle. The user should input length and width, and the program should output the area.",
        correctAnswer: "length = float(input('Enter length: '))\nwidth = float(input('Enter width: '))\narea = length * width\nprint('Area:', area)",
        explanation: "Get user input for length and width, convert to float, multiply them for area, and print the result.",
        points: 15
      }
    ]
  },
  {
    id: 4,
    title: "World War II: Causes and Consequences",
    subject: "History",
    content: `
# World War II: Causes and Consequences (1939-1945)

## Overview

World War II was the deadliest conflict in human history, involving over 30 countries and resulting in 70-85 million deaths. It reshaped the global political landscape and marked the beginning of the modern era.

## Major Causes

### 1. Treaty of Versailles (1919)
- **Harsh terms**: Germany forced to pay massive reparations
- **Territorial losses**: Germany lost significant territory
- **Military restrictions**: German army severely limited
- **National humiliation**: Created resentment among Germans

### 2. Rise of Totalitarian Regimes
- **Nazi Germany**: Adolf Hitler's aggressive expansionism
- **Fascist Italy**: Mussolini's imperial ambitions
- **Imperial Japan**: Military expansion in Asia and Pacific

### 3. Economic Factors
- **Great Depression**: Global economic crisis weakened democracies
- **Unemployment**: Created social unrest and political instability
- **Resource competition**: Nations fought for raw materials and markets

### 4. Policy of Appeasement
- **British and French strategy**: Avoiding conflict through concessions
- **Munich Agreement (1938)**: Allowed Germany to annex Sudetenland
- **Failed deterrence**: Encouraged further aggression

## Key Events and Timeline

### 1939: War Begins
- **September 1**: Germany invades Poland
- **September 3**: Britain and France declare war on Germany
- **Blitzkrieg tactics**: Fast-moving, coordinated attacks

### 1940: Axis Expansion
- **April-June**: Germany conquers Norway, Denmark, Netherlands, Belgium, France
- **Battle of Britain**: German air campaign against UK fails
- **Operation Barbarossa planned**: Hitler prepares to invade Soviet Union

### 1941: Global Conflict
- **June 22**: Germany invades Soviet Union
- **December 7**: Japan attacks Pearl Harbor
- **December 11**: Germany declares war on United States

### 1942-1943: Turning Points
- **Battle of Stalingrad**: German advance in USSR stopped
- **Battle of Midway**: Japanese naval power broken in Pacific
- **North African Campaign**: Allies gain control of Mediterranean

### 1944-1945: Allied Victory
- **D-Day (June 6, 1944)**: Allied invasion of Normandy
- **Liberation of concentration camps**: Holocaust horrors revealed
- **May 8, 1945**: Germany surrenders (VE Day)
- **August 6 & 9**: Atomic bombs dropped on Hiroshima and Nagasaki
- **August 15**: Japan surrenders (VJ Day)

## Major Consequences

### Political Changes
- **United Nations formed**: International peacekeeping organization
- **Cold War begins**: US-Soviet rivalry emerges
- **Decolonization**: European empires collapse
- **Germany divided**: Split between East and West

### Social Impact
- **Holocaust**: Systematic murder of 6 million Jews and millions of others
- **Displaced persons**: Millions of refugees and displaced people
- **Women's roles**: Increased participation in workforce
- **Civil rights awareness**: Contradiction of fighting racism while practicing segregation

### Economic Transformation
- **Marshall Plan**: US rebuilds Western Europe
- **Bretton Woods System**: New international monetary system
- **Economic boom**: Post-war prosperity in victor nations
- **Technological advancement**: Radar, computers, nuclear energy

### Technological Innovation
- **Radar and sonar**: Advanced detection systems
- **Jet engines**: Revolutionary aircraft propulsion
- **Nuclear weapons**: Changed nature of warfare forever
- **Medical advances**: Antibiotics, blood plasma, prosthetics

## Lessons Learned

1. **Appeasement fails**: Concessions to aggressors encourage further aggression
2. **International cooperation**: Need for strong international institutions
3. **Economic stability**: Economic crises can destabilize democracies
4. **Human rights**: Importance of protecting minority groups
5. **Collective security**: Nations must work together to prevent war

## Legacy

World War II established the United States and Soviet Union as superpowers, led to the creation of the United Nations, and began the process of decolonization that would reshape the world map. The war's lessons about the dangers of totalitarianism and the importance of international cooperation continue to influence global politics today.
    `,
    difficulty: "Intermediate",
    estimatedTime: "35 minutes",
    objectives: [
      "Identify the major causes of World War II",
      "Understand the key events and turning points of the war",
      "Analyze the political, social, and economic consequences",
      "Evaluate the lessons learned and their modern relevance",
      "Assess the war's impact on human rights and international relations"
    ],
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: "Which event is considered the immediate cause of World War II in Europe?",
        options: ["Germany's invasion of Poland", "Attack on Pearl Harbor", "Battle of Britain", "Munich Agreement"],
        correctAnswer: "Germany's invasion of Poland",
        explanation: "Germany's invasion of Poland on September 1, 1939, prompted Britain and France to declare war on Germany, officially beginning WWII in Europe.",
        points: 8
      },
      {
        id: 2,
        type: 'short-answer',
        question: "Name three major turning points that shifted the war in favor of the Allies.",
        correctAnswer: "Battle of Stalingrad, Battle of Midway, D-Day",
        explanation: "Stalingrad stopped German advance in USSR, Midway broke Japanese naval power, and D-Day opened second front in Europe.",
        points: 12
      },
      {
        id: 3,
        type: 'problem-solving',
        question: "Analyze how the Treaty of Versailles contributed to the causes of WWII. Provide specific examples of how its terms created conditions for conflict.",
        correctAnswer: "The Treaty imposed harsh reparations that devastated Germany's economy, stripped Germany of territory creating ethnic tensions, limited Germany's military creating resentment, and imposed war guilt that humiliated the German people, all contributing to conditions that Hitler exploited to gain power.",
        explanation: "The Treaty's punitive terms created economic hardship, national humiliation, and political instability in Germany, which Hitler used to justify his aggressive policies and gain popular support.",
        points: 18
      }
    ]
  },
  {
    id: 5,
    title: "Introduction to Business and Entrepreneurship",
    subject: "Business Studies",
    content: `
# Introduction to Business and Entrepreneurship

## What is Business?

Business is the activity of making, buying, or selling goods or providing services in exchange for money. It involves creating value for customers while generating profit for owners.

## Key Business Concepts

### 1. Supply and Demand
- **Supply**: Amount of product available
- **Demand**: Consumer desire for the product
- **Market equilibrium**: Point where supply meets demand
- **Price determination**: Influenced by supply and demand balance

### 2. Types of Business Ownership

**Sole Proprietorship**
- Single owner
- Unlimited liability
- Simple to start
- Owner keeps all profits

**Partnership**
- Two or more owners
- Shared responsibilities
- Shared profits and losses
- Partnership agreement needed

**Corporation**
- Legal entity separate from owners
- Limited liability for shareholders
- Can raise capital by selling stock
- More complex regulations

### 3. Business Functions

**Marketing**
- Identifying customer needs
- Promoting products/services
- Market research and analysis
- Brand development

**Finance**
- Managing money and investments
- Budgeting and forecasting
- Securing funding
- Financial reporting

**Operations**
- Production of goods/services
- Supply chain management
- Quality control
- Efficiency optimization

**Human Resources**
- Recruiting and hiring
- Training and development
- Employee relations
- Compensation and benefits

## Entrepreneurship

### What is an Entrepreneur?
An entrepreneur is someone who starts and operates a business, taking on financial risks in hopes of profit and innovation.

### Characteristics of Successful Entrepreneurs
1. **Risk-taking**: Willing to take calculated risks
2. **Innovation**: Creative problem-solving
3. **Persistence**: Don't give up easily
4. **Leadership**: Ability to motivate others
5. **Adaptability**: Flexible to change
6. **Vision**: Clear long-term goals

### The Entrepreneurial Process

**1. Idea Generation**
- Identify problems to solve
- Spot market opportunities
- Consider personal interests and skills

**2. Market Research**
- Analyze target customers
- Study competitors
- Assess market size and trends

**3. Business Planning**
- Write business plan
- Define mission and vision
- Set goals and strategies

**4. Securing Resources**
- Obtain funding
- Acquire necessary equipment
- Build team

**5. Launch and Growth**
- Start operations
- Market the business
- Monitor and adjust

## Business Plan Essentials

### Executive Summary
- Brief overview of business
- Key success factors
- Financial projections

### Market Analysis
- Industry overview
- Target market description
- Competitive analysis

### Marketing Strategy
- Product/service description
- Pricing strategy
- Promotion plan
- Distribution channels

### Financial Projections
- Startup costs
- Revenue forecasts
- Break-even analysis
- Profit projections

## Sources of Business Funding

### Personal Sources
- Personal savings
- Friends and family
- Credit cards (risky)

### Traditional Lending
- Bank loans
- Small Business Administration (SBA) loans
- Credit lines

### Investment Capital
- Angel investors
- Venture capital
- Crowdfunding

### Government Programs
- Grants
- Tax incentives
- Small business programs

## Keys to Business Success

1. **Customer Focus**: Understand and meet customer needs
2. **Quality Products/Services**: Deliver consistent value
3. **Financial Management**: Control costs and cash flow
4. **Marketing**: Effectively reach target customers
5. **Adaptability**: Respond to market changes
6. **Continuous Learning**: Stay informed about industry trends

## Common Business Challenges

- **Cash flow problems**: Not enough money coming in
- **Competition**: Other businesses offering similar products
- **Regulatory compliance**: Following laws and regulations
- **Economic downturns**: Reduced consumer spending
- **Technology changes**: Keeping up with innovations
- **Hiring good employees**: Finding and retaining talent

## Real-World Example: Starting a Local Coffee Shop

**Market Research**: Analyze local competition, customer preferences, foot traffic patterns

**Business Model**: Premium coffee, comfortable atmosphere, local community focus

**Startup Costs**: Equipment ($50,000), rent deposit ($10,000), initial inventory ($5,000), permits ($2,000)

**Revenue Streams**: Coffee sales, food items, catering, retail coffee beans

**Marketing**: Social media, local partnerships, loyalty program, grand opening event

**Success Metrics**: Daily sales targets, customer retention rate, profit margins
    `,
    difficulty: "Beginner",
    estimatedTime: "45 minutes",
    objectives: [
      "Understand basic business concepts and terminology",
      "Compare different types of business ownership structures",
      "Identify key characteristics of successful entrepreneurs",
      "Outline the essential components of a business plan",
      "Evaluate different sources of business funding",
      "Apply business concepts to real-world scenarios"
    ],
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: "Which type of business ownership provides limited liability protection?",
        options: ["Sole Proprietorship", "Partnership", "Corporation", "All of the above"],
        correctAnswer: "Corporation",
        explanation: "Corporations provide limited liability protection, meaning shareholders are not personally responsible for business debts beyond their investment.",
        points: 8
      },
      {
        id: 2,
        type: 'short-answer',
        question: "List the four main business functions and briefly describe each.",
        correctAnswer: "Marketing (promoting products), Finance (managing money), Operations (producing goods/services), Human Resources (managing employees)",
        explanation: "These four functions cover the core activities that all businesses must perform to operate successfully.",
        points: 12
      },
      {
        id: 3,
        type: 'problem-solving',
        question: "You want to start a tutoring business. Describe your target market, identify two potential competitors, and explain how you would differentiate your service.",
        correctAnswer: "Target market: High school and college students struggling with specific subjects. Competitors: Established tutoring centers and online platforms like Khan Academy. Differentiation: Personalized one-on-one sessions, flexible scheduling, subject specialization, and proven track record of grade improvement.",
        explanation: "Successful businesses identify specific target customers, understand their competition, and offer unique value propositions that set them apart.",
        points: 15
      }
    ]
  }
];

export default function Lesson() {
  const [match, params] = useRoute("/lesson/:id");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState("");
  const queryClient = useQueryClient();

  const lessonId = params?.id ? parseInt(params.id) : 1;
  const lesson = realLessons.find(l => l.id === lessonId) || realLessons[0];
  const currentQuestion = lesson.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / lesson.questions.length) * 100;

  const submitAnswerMutation = useMutation({
    mutationFn: async (answer: string) => {
      // Add live activity for answering questions
      await fetch('/api/live/activity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'study',
          message: `Randy answered a question in "${lesson.title}"`,
          userId: 1,
          icon: 'quiz',
          color: 'text-blue-600'
        })
      });
      return answer;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/live/activities'] });
    }
  });

  const handleAnswerSubmit = () => {
    const answer = selectedAnswer || userAnswers[currentQuestion.id] || "";
    setUserAnswers(prev => ({ ...prev, [currentQuestion.id]: answer }));
    
    submitAnswerMutation.mutate(answer);

    if (currentQuestionIndex < lesson.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer("");
    } else {
      calculateScore();
      setShowResults(true);
    }
  };

  const calculateScore = () => {
    let totalScore = 0;
    lesson.questions.forEach(question => {
      const userAnswer = userAnswers[question.id];
      if (userAnswer?.toLowerCase().trim() === question.correctAnswer.toLowerCase().trim()) {
        totalScore += question.points;
      }
    });
    setScore(totalScore);
  };

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setUserAnswers({});
    setShowResults(false);
    setScore(0);
    setSelectedAnswer("");
  };

  if (showResults) {
    const totalPoints = lesson.questions.reduce((sum, q) => sum + q.points, 0);
    const percentage = Math.round((score / totalPoints) * 100);

    return (
      <div className="p-6 max-w-4xl mx-auto">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-green-600">Quiz Complete!</CardTitle>
            <div className="text-6xl font-bold text-neutral-800 dark:text-white mt-4">
              {percentage}%
            </div>
            <p className="text-neutral-600 dark:text-neutral-400">
              You scored {score} out of {totalPoints} points
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {lesson.questions.map((question, index) => {
                const userAnswer = userAnswers[question.id];
                const isCorrect = userAnswer?.toLowerCase().trim() === question.correctAnswer.toLowerCase().trim();
                
                return (
                  <div key={question.id} className="border rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm ${
                        isCorrect ? 'bg-green-500' : 'bg-red-500'
                      }`}>
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium mb-2">{question.question}</p>
                        <div className="space-y-1 text-sm">
                          <p><strong>Your answer:</strong> <span className={isCorrect ? 'text-green-600' : 'text-red-600'}>{userAnswer || 'No answer'}</span></p>
                          <p><strong>Correct answer:</strong> <span className="text-green-600">{question.correctAnswer}</span></p>
                          <p className="text-neutral-600 dark:text-neutral-400">{question.explanation}</p>
                        </div>
                      </div>
                      <Badge variant={isCorrect ? "default" : "destructive"}>
                        {isCorrect ? `+${question.points}` : '0'} pts
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="flex gap-4 mt-6">
              <Button onClick={restartQuiz} variant="outline" className="flex-1">
                Retake Quiz
              </Button>
              <Button onClick={() => window.history.back()} className="flex-1">
                Back to Course
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Lesson Content */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">{lesson.title}</CardTitle>
              <div className="flex items-center gap-4 mt-2 text-sm text-neutral-600 dark:text-neutral-400">
                <Badge variant="secondary">{lesson.difficulty}</Badge>
                <span className="flex items-center gap-1">
                  <span className="material-icons text-sm">schedule</span>
                  {lesson.estimatedTime}
                </span>
                <span className="flex items-center gap-1">
                  <span className="material-icons text-sm">school</span>
                  {lesson.subject}
                </span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="prose dark:prose-invert max-w-none">
            <div dangerouslySetInnerHTML={{ 
              __html: lesson.content
                .replace(/\n\n/g, '</p><p>')
                .replace(/\n/g, '<br>')
                .replace(/^/, '<p>')
                .replace(/$/, '</p>')
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/# (.*?)\n/g, '<h2>$1</h2>')
                .replace(/## (.*?)\n/g, '<h3>$1</h3>')
                .replace(/### (.*?)\n/g, '<h4>$1</h4>')
            }} />
          </div>
          
          <div className="mt-6">
            <h3 className="font-semibold mb-3">Learning Objectives</h3>
            <ul className="space-y-2">
              {lesson.objectives.map((objective, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="material-icons text-green-600 text-sm mt-0.5">check_circle</span>
                  <span className="text-sm">{objective}</span>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Quiz Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Knowledge Check</CardTitle>
            <div className="text-sm text-neutral-600 dark:text-neutral-400">
              Question {currentQuestionIndex + 1} of {lesson.questions.length}
            </div>
          </div>
          <Progress value={progress} className="w-full" />
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-4">{currentQuestion.question}</h3>
              
              {currentQuestion.type === 'multiple-choice' && (
                <div className="space-y-3">
                  {currentQuestion.options?.map((option, index) => (
                    <label key={index} className="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800">
                      <input
                        type="radio"
                        name="answer"
                        value={option}
                        checked={selectedAnswer === option}
                        onChange={(e) => setSelectedAnswer(e.target.value)}
                        className="text-blue-600"
                      />
                      <span>{option}</span>
                    </label>
                  ))}
                </div>
              )}
              
              {(currentQuestion.type === 'short-answer' || currentQuestion.type === 'problem-solving') && (
                <textarea
                  className="w-full p-3 border rounded-lg resize-none"
                  rows={4}
                  placeholder="Enter your answer here..."
                  value={selectedAnswer}
                  onChange={(e) => setSelectedAnswer(e.target.value)}
                />
              )}
            </div>
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-neutral-600 dark:text-neutral-400">
                <span className="material-icons text-sm mr-1">star</span>
                {currentQuestion.points} points
              </div>
              <Button 
                onClick={handleAnswerSubmit}
                disabled={!selectedAnswer.trim() || submitAnswerMutation.isPending}
              >
                {currentQuestionIndex < lesson.questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}