import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Lightbulb, Scale, Globe, Users, Clock, Sparkles } from "lucide-react";

export default function Philosophy() {
  const philosophicalBranches = [
    {
      title: "Ethics",
      description: "Right and wrong, moral principles and values",
      icon: Scale,
      color: "text-blue-600",
      questions: ["What makes an action right or wrong?", "How should we live?", "What are our moral duties?"],
      thinkers: ["Aristotle", "Kant", "Mill", "Nietzsche"]
    },
    {
      title: "Metaphysics",
      description: "Nature of reality, existence, and being",
      icon: Sparkles,
      color: "text-purple-600",
      questions: ["What is real?", "Do we have free will?", "What is the nature of time?"],
      thinkers: ["Plato", "Descartes", "Heidegger", "Berkeley"]
    },
    {
      title: "Epistemology",
      description: "Knowledge, belief, and justification",
      icon: Lightbulb,
      color: "text-yellow-600",
      questions: ["What can we know?", "How do we acquire knowledge?", "What is truth?"],
      thinkers: ["Locke", "Hume", "Kant", "Wittgenstein"]
    },
    {
      title: "Political Philosophy",
      description: "Government, justice, and social organization",
      icon: Users,
      color: "text-green-600",
      questions: ["What makes government legitimate?", "What is justice?", "How should society be organized?"],
      thinkers: ["Plato", "Hobbes", "Rousseau", "Rawls"]
    },
    {
      title: "Philosophy of Mind",
      description: "Consciousness, thought, and mental states",
      icon: Globe,
      color: "text-red-600",
      questions: ["What is consciousness?", "How does mind relate to body?", "Can machines think?"],
      thinkers: ["Descartes", "Ryle", "Dennett", "Chalmers"]
    },
    {
      title: "Aesthetics",
      description: "Beauty, art, and aesthetic experience",
      icon: Clock,
      color: "text-indigo-600",
      questions: ["What is beauty?", "What makes art valuable?", "Is taste subjective?"],
      thinkers: ["Kant", "Hegel", "Benjamin", "Adorno"]
    }
  ];

  const greatPhilosophers = [
    { name: "Socrates", period: "470-399 BCE", tradition: "Ancient Greek", contribution: "Socratic method, examined life" },
    { name: "Plato", period: "428-348 BCE", tradition: "Ancient Greek", contribution: "Theory of Forms, ideal state" },
    { name: "Aristotle", period: "384-322 BCE", tradition: "Ancient Greek", contribution: "Logic, virtue ethics, biology" },
    { name: "Augustine", period: "354-430 CE", tradition: "Christian", contribution: "Faith and reason, just war theory" },
    { name: "Thomas Aquinas", period: "1225-1274", tradition: "Scholastic", contribution: "Natural law, proofs for God" },
    { name: "René Descartes", period: "1596-1650", tradition: "Modern", contribution: "Cogito ergo sum, mind-body dualism" },
    { name: "Immanuel Kant", period: "1724-1804", tradition: "German Idealism", contribution: "Categorical imperative, transcendental idealism" },
    { name: "Friedrich Nietzsche", period: "1844-1900", tradition: "Continental", contribution: "Will to power, critique of morality" },
    { name: "John Stuart Mill", period: "1806-1873", tradition: "Utilitarian", contribution: "Harm principle, greatest happiness" },
    { name: "Simone de Beauvoir", period: "1908-1986", tradition: "Existentialist", contribution: "Feminist philosophy, The Second Sex" }
  ];

  const thoughtExperiments = [
    { 
      title: "The Ship of Theseus", 
      origin: "Plutarch", 
      question: "If all parts of a ship are gradually replaced, is it still the same ship?",
      explores: "Identity and change"
    },
    { 
      title: "The Trolley Problem", 
      origin: "Philippa Foot", 
      question: "Is it moral to divert a runaway trolley to kill one person instead of five?",
      explores: "Utilitarianism vs. deontology"
    },
    { 
      title: "The Veil of Ignorance", 
      origin: "John Rawls", 
      question: "What kind of society would you choose if you didn't know your position in it?",
      explores: "Justice and fairness"
    },
    { 
      title: "The Chinese Room", 
      origin: "John Searle", 
      question: "Can a computer understand language just by following rules?",
      explores: "Consciousness and AI"
    },
    { 
      title: "Mary's Room", 
      origin: "Frank Jackson", 
      question: "Does a color scientist learn something new when seeing color for the first time?",
      explores: "Qualia and consciousness"
    },
    { 
      title: "The Experience Machine", 
      origin: "Robert Nozick", 
      question: "Would you plug into a machine that gives you perfect experiences but isn't real?",
      explores: "What makes life meaningful"
    }
  ];

  const philosophicalMovements = [
    { name: "Stoicism", period: "3rd cent. BCE", focus: "Virtue, wisdom, emotional resilience", key: "Accept what you cannot control" },
    { name: "Existentialism", period: "19th-20th cent.", focus: "Individual existence, freedom, authenticity", key: "Existence precedes essence" },
    { name: "Utilitarianism", period: "18th-19th cent.", focus: "Greatest happiness for greatest number", key: "Consequences determine morality" },
    { name: "Phenomenology", period: "20th cent.", focus: "Structures of experience and consciousness", key: "Back to the things themselves" },
    { name: "Analytic Philosophy", period: "20th cent.", focus: "Language, logic, conceptual analysis", key: "Clarity through linguistic analysis" },
    { name: "Postmodernism", period: "Late 20th cent.", focus: "Critique of grand narratives, deconstruction", key: "Question absolute truths" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100 dark:from-gray-900 dark:to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Philosophy & Critical Thinking
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Explore fundamental questions about existence, knowledge, values, and human nature through philosophical inquiry
          </p>
        </div>

        <Tabs defaultValue="branches" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="branches">Branches</TabsTrigger>
            <TabsTrigger value="philosophers">Great Thinkers</TabsTrigger>
            <TabsTrigger value="experiments">Thought Experiments</TabsTrigger>
            <TabsTrigger value="movements">Movements</TabsTrigger>
            <TabsTrigger value="dialogue">Socratic Dialogue</TabsTrigger>
          </TabsList>

          <TabsContent value="branches" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {philosophicalBranches.map((branch, index) => {
                const IconComponent = branch.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <IconComponent className={`h-8 w-8 ${branch.color}`} />
                        <CardTitle className="text-lg">{branch.title}</CardTitle>
                      </div>
                      <CardDescription>{branch.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Key Questions:</p>
                          <div className="space-y-1">
                            {branch.questions.map((question, qIndex) => (
                              <div key={qIndex} className="text-xs text-gray-600 dark:text-gray-400">• {question}</div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Key Thinkers:</p>
                          <div className="flex flex-wrap gap-1">
                            {branch.thinkers.map((thinker, tIndex) => (
                              <Badge key={tIndex} variant="outline" className="text-xs">{thinker}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="philosophers" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {greatPhilosophers.map((philosopher, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {philosopher.name}
                      <Badge variant="outline">{philosopher.period}</Badge>
                    </CardTitle>
                    <CardDescription className="font-medium text-blue-600 dark:text-blue-400">
                      {philosopher.tradition}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{philosopher.contribution}</p>
                    <Button variant="outline" size="sm" className="w-full">
                      Explore Philosophy
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="experiments" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {thoughtExperiments.map((experiment, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-lg">{experiment.title}</CardTitle>
                    <CardDescription>By {experiment.origin}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">The Question:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{experiment.question}</p>
                      </div>
                      <div>
                        <Badge variant="secondary" className="text-xs">{experiment.explores}</Badge>
                      </div>
                      <Button variant="outline" size="sm" className="w-full">
                        Explore Experiment
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="movements" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {philosophicalMovements.map((movement, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {movement.name}
                      <Badge variant="outline">{movement.period}</Badge>
                    </CardTitle>
                    <CardDescription>{movement.focus}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Core Insight:</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 italic">"{movement.key}"</p>
                      <Button variant="outline" size="sm" className="w-full mt-3">
                        Study Movement
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="dialogue" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>AI Socratic Dialogue</CardTitle>
                <CardDescription>
                  Engage in philosophical inquiry through guided questioning and critical thinking
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Ask a philosophical question or share a belief to examine..."
                    className="flex-1"
                  />
                  <Button>Begin Dialogue</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <Lightbulb className="h-8 w-8 text-yellow-600 mb-2" />
                      <h3 className="font-semibold mb-2">Question Assumptions</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Examine underlying beliefs and premises</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Scale className="h-8 w-8 text-blue-600 mb-2" />
                      <h3 className="font-semibold mb-2">Weigh Arguments</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Consider multiple perspectives and evidence</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Sparkles className="h-8 w-8 text-purple-600 mb-2" />
                      <h3 className="font-semibold mb-2">Discover Insights</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Arrive at deeper understanding through inquiry</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}