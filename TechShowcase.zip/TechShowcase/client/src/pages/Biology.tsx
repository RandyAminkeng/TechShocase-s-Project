import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Microscope, Dna, Heart, Leaf, Bug, Fish, Users, Eye } from "lucide-react";

export default function Biology() {
  const biologyFields = [
    {
      title: "Cell Biology",
      description: "Structure and function of cells",
      icon: Microscope,
      color: "text-blue-600",
      topics: ["Cell Membrane", "Organelles", "Cell Division", "Protein Synthesis", "Cellular Respiration"]
    },
    {
      title: "Genetics",
      description: "Heredity and genetic variation",
      icon: Dna,
      color: "text-purple-600",
      topics: ["DNA Structure", "Gene Expression", "Inheritance Patterns", "Mutations", "Genetic Engineering"]
    },
    {
      title: "Human Biology",
      description: "Structure and function of human body",
      icon: Heart,
      color: "text-red-600",
      topics: ["Circulatory System", "Nervous System", "Digestive System", "Respiratory System", "Immune System"]
    },
    {
      title: "Botany",
      description: "Study of plant life",
      icon: Leaf,
      color: "text-green-600",
      topics: ["Photosynthesis", "Plant Structure", "Plant Reproduction", "Plant Ecology", "Plant Evolution"]
    },
    {
      title: "Zoology",
      description: "Study of animal life",
      icon: Bug,
      color: "text-orange-600",
      topics: ["Animal Behavior", "Animal Classification", "Animal Physiology", "Animal Evolution", "Animal Ecology"]
    },
    {
      title: "Marine Biology",
      description: "Study of ocean life",
      icon: Fish,
      color: "text-cyan-600",
      topics: ["Ocean Ecosystems", "Marine Animals", "Coral Reefs", "Deep Sea Biology", "Marine Conservation"]
    },
    {
      title: "Ecology",
      description: "Interactions between organisms and environment",
      icon: Users,
      color: "text-emerald-600",
      topics: ["Food Chains", "Ecosystems", "Population Dynamics", "Conservation Biology", "Climate Change"]
    },
    {
      title: "Microbiology",
      description: "Study of microscopic organisms",
      icon: Eye,
      color: "text-indigo-600",
      topics: ["Bacteria", "Viruses", "Fungi", "Microbiomes", "Disease Mechanisms"]
    }
  ];

  const biologicalProcesses = [
    { name: "Photosynthesis", category: "Plant Biology", importance: "Energy production in plants" },
    { name: "Cellular Respiration", category: "Cell Biology", importance: "Energy release in cells" },
    { name: "DNA Replication", category: "Genetics", importance: "Cell division and inheritance" },
    { name: "Protein Synthesis", category: "Molecular Biology", importance: "Building cellular machinery" },
    { name: "Evolution", category: "Evolutionary Biology", importance: "Species adaptation and change" },
    { name: "Homeostasis", category: "Physiology", importance: "Maintaining internal balance" }
  ];

  const biologicalSystems = [
    { system: "Circulatory System", function: "Transport nutrients and oxygen", organs: ["Heart", "Blood Vessels", "Blood"] },
    { system: "Nervous System", function: "Control and coordination", organs: ["Brain", "Spinal Cord", "Nerves"] },
    { system: "Digestive System", function: "Break down and absorb nutrients", organs: ["Stomach", "Intestines", "Liver"] },
    { system: "Respiratory System", function: "Gas exchange", organs: ["Lungs", "Trachea", "Bronchi"] },
    { system: "Immune System", function: "Defense against pathogens", organs: ["White Blood Cells", "Lymph Nodes", "Spleen"] },
    { system: "Endocrine System", function: "Hormone regulation", organs: ["Glands", "Hormones", "Receptors"] }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-green-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Biology & Life Sciences
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Explore the fascinating world of living organisms, from microscopic cells to complex ecosystems
          </p>
        </div>

        <Tabs defaultValue="fields" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="fields">Biology Fields</TabsTrigger>
            <TabsTrigger value="processes">Key Processes</TabsTrigger>
            <TabsTrigger value="systems">Body Systems</TabsTrigger>
            <TabsTrigger value="lab">Virtual Lab</TabsTrigger>
          </TabsList>

          <TabsContent value="fields" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {biologyFields.map((field, index) => {
                const IconComponent = field.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <IconComponent className={`h-8 w-8 ${field.color}`} />
                        <CardTitle className="text-lg">{field.title}</CardTitle>
                      </div>
                      <CardDescription>{field.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Topics:</p>
                        <div className="flex flex-wrap gap-1">
                          {field.topics.slice(0, 3).map((topic, topicIndex) => (
                            <Badge key={topicIndex} variant="outline" className="text-xs">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="processes" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {biologicalProcesses.map((process, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {process.name}
                      <Badge variant="secondary">{process.category}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{process.importance}</p>
                    <Button variant="outline" size="sm" className="w-full">
                      Learn Process
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="systems" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {biologicalSystems.map((system, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-lg">{system.system}</CardTitle>
                    <CardDescription>{system.function}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Key Components:</p>
                      <div className="flex flex-wrap gap-1">
                        {system.organs.map((organ, organIndex) => (
                          <Badge key={organIndex} variant="outline" className="text-xs">
                            {organ}
                          </Badge>
                        ))}
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-3">
                        Explore System
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="lab" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Virtual Biology Laboratory</CardTitle>
                <CardDescription>
                  Interactive experiments and simulations for biological concepts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <Microscope className="h-8 w-8 text-blue-600 mb-2" />
                      <h3 className="font-semibold mb-2">Microscopy Lab</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Examine cells and tissues</p>
                      <Button size="sm" className="w-full mt-2">Start Lab</Button>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Dna className="h-8 w-8 text-purple-600 mb-2" />
                      <h3 className="font-semibold mb-2">DNA Analysis</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Genetic sequence analysis</p>
                      <Button size="sm" className="w-full mt-2">Start Lab</Button>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Leaf className="h-8 w-8 text-green-600 mb-2" />
                      <h3 className="font-semibold mb-2">Photosynthesis</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Energy conversion in plants</p>
                      <Button size="sm" className="w-full mt-2">Start Lab</Button>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}