import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Brain, 
  Heart, 
  Zap, 
  Target, 
  TrendingUp, 
  Calendar, 
  Clock, 
  Award,
  Lightbulb,
  CheckCircle,
  AlertCircle,
  Plus,
  BarChart3,
  Smile,
  Frown,
  Meh,
  Battery,
  Flame
} from 'lucide-react';
import { Line, LineChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface MoodEntry {
  id: number;
  userId: number;
  moodScore: number;
  energyLevel: number;
  motivationLevel: number;
  stressLevel: number;
  notes?: string;
  tags: string[];
  date: string;
}

interface MotivationGoal {
  id: number;
  userId: number;
  title: string;
  description?: string;
  targetValue: number;
  currentValue: number;
  unit: string;
  category: string;
  deadline?: string;
  isCompleted: boolean;
  priority: string;
  createdAt: string;
}

interface AiInsight {
  id: number;
  userId: number;
  insightType: string;
  content: string;
  recommendations: string[];
  confidence: number;
  isRead: boolean;
  generatedAt: string;
}

export default function MoodTracker() {
  const [moodScore, setMoodScore] = useState([7]);
  const [energyLevel, setEnergyLevel] = useState([6]);
  const [motivationLevel, setMotivationLevel] = useState([8]);
  const [stressLevel, setStressLevel] = useState([4]);
  const [notes, setNotes] = useState('');
  const [tags, setTags] = useState('');
  const [showGoalForm, setShowGoalForm] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    targetValue: 0,
    unit: 'hours',
    category: 'daily',
    priority: 'medium'
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch mood entries
  const { data: moodEntries = [] } = useQuery<MoodEntry[]>({
    queryKey: ['/api/mood/entries'],
  });

  // Fetch motivation goals
  const { data: goals = [] } = useQuery<MotivationGoal[]>({
    queryKey: ['/api/motivation/goals'],
  });

  // Fetch AI insights
  const { data: insights = [] } = useQuery<AiInsight[]>({
    queryKey: ['/api/ai/insights'],
  });

  // Create mood entry mutation
  const createMoodEntryMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/api/mood/entries', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mood/entries'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ai/insights'] });
      setNotes('');
      setTags('');
      setMoodScore([7]);
      setEnergyLevel([6]);
      setMotivationLevel([8]);
      setStressLevel([4]);
      toast({
        title: "Mood Entry Saved",
        description: "Your mood has been recorded and AI insights are being generated.",
      });
    },
  });

  // Create goal mutation
  const createGoalMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/api/motivation/goals', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/motivation/goals'] });
      setShowGoalForm(false);
      setNewGoal({
        title: '',
        description: '',
        targetValue: 0,
        unit: 'hours',
        category: 'daily',
        priority: 'medium'
      });
      toast({
        title: "Goal Created",
        description: "Your motivation goal has been set successfully.",
      });
    },
  });

  const handleSubmitMoodEntry = () => {
    const tagArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
    
    createMoodEntryMutation.mutate({
      moodScore: moodScore[0],
      energyLevel: energyLevel[0],
      motivationLevel: motivationLevel[0],
      stressLevel: stressLevel[0],
      notes: notes || null,
      tags: tagArray
    });
  };

  const handleCreateGoal = () => {
    createGoalMutation.mutate(newGoal);
  };

  const getMoodIcon = (score: number) => {
    if (score >= 8) return <Smile className="h-6 w-6 text-green-500" />;
    if (score >= 6) return <Meh className="h-6 w-6 text-yellow-500" />;
    return <Frown className="h-6 w-6 text-red-500" />;
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  // Prepare chart data
  const chartData = moodEntries.slice(-7).map(entry => ({
    date: new Date(entry.date).toLocaleDateString(),
    mood: entry.moodScore,
    energy: entry.energyLevel,
    motivation: entry.motivationLevel,
    stress: 10 - entry.stressLevel // Invert stress for better visualization
  }));

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Brain className="h-8 w-8 text-purple-600" />
        <div>
          <h1 className="text-3xl font-bold dark:text-white">AI Mood & Motivation Tracker</h1>
          <p className="text-neutral-600 dark:text-neutral-400">Track your emotional well-being with AI-powered insights</p>
        </div>
      </div>

      <Tabs defaultValue="track" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="track">Track Mood</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="track" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-red-500" />
                How are you feeling today?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="flex items-center gap-2 mb-3">
                      <Smile className="h-4 w-4" />
                      Mood Score: {moodScore[0]}/10
                    </Label>
                    <Slider
                      value={moodScore}
                      onValueChange={setMoodScore}
                      max={10}
                      min={1}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <Label className="flex items-center gap-2 mb-3">
                      <Battery className="h-4 w-4" />
                      Energy Level: {energyLevel[0]}/10
                    </Label>
                    <Slider
                      value={energyLevel}
                      onValueChange={setEnergyLevel}
                      max={10}
                      min={1}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <Label className="flex items-center gap-2 mb-3">
                      <Flame className="h-4 w-4" />
                      Motivation: {motivationLevel[0]}/10
                    </Label>
                    <Slider
                      value={motivationLevel}
                      onValueChange={setMotivationLevel}
                      max={10}
                      min={1}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <Label className="flex items-center gap-2 mb-3">
                      <AlertCircle className="h-4 w-4" />
                      Stress Level: {stressLevel[0]}/10
                    </Label>
                    <Slider
                      value={stressLevel}
                      onValueChange={setStressLevel}
                      max={10}
                      min={1}
                      step={1}
                      className="w-full"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      placeholder="How are you feeling? What's on your mind?"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={4}
                    />
                  </div>

                  <div>
                    <Label htmlFor="tags">Tags (Optional)</Label>
                    <Input
                      id="tags"
                      placeholder="work, stress, happy, tired (comma separated)"
                      value={tags}
                      onChange={(e) => setTags(e.target.value)}
                    />
                  </div>

                  <Button 
                    onClick={handleSubmitMoodEntry}
                    disabled={createMoodEntryMutation.isPending}
                    className="w-full"
                  >
                    {createMoodEntryMutation.isPending ? 'Saving...' : 'Save Mood Entry'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Mood Entries */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Entries</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {moodEntries.slice(0, 5).map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between p-3 border rounded-lg dark:border-neutral-700">
                    <div className="flex items-center gap-3">
                      {getMoodIcon(entry.moodScore)}
                      <div>
                        <div className="font-medium">Mood: {entry.moodScore}/10</div>
                        <div className="text-sm text-neutral-500">
                          {new Date(entry.date).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Badge variant="outline">Energy: {entry.energyLevel}</Badge>
                      <Badge variant="outline">Motivation: {entry.motivationLevel}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid gap-6">
            {insights.map((insight) => (
              <Card key={insight.id} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                    AI Insight
                    <Badge variant="outline" className="ml-auto">
                      {Math.round(insight.confidence * 100)}% confidence
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-neutral-700 dark:text-neutral-300">
                    {insight.content}
                  </p>
                  
                  {insight.recommendations.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Recommendations:</h4>
                      <ul className="space-y-1">
                        {insight.recommendations.map((rec, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  <div className="text-sm text-neutral-500">
                    Generated: {new Date(insight.generatedAt).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="goals" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold dark:text-white">Motivation Goals</h2>
            <Button onClick={() => setShowGoalForm(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Goal
            </Button>
          </div>

          {showGoalForm && (
            <Card>
              <CardHeader>
                <CardTitle>Create New Goal</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="goal-title">Title</Label>
                    <Input
                      id="goal-title"
                      value={newGoal.title}
                      onChange={(e) => setNewGoal({...newGoal, title: e.target.value})}
                      placeholder="Study 2 hours daily"
                    />
                  </div>
                  <div>
                    <Label htmlFor="goal-target">Target Value</Label>
                    <Input
                      id="goal-target"
                      type="number"
                      value={newGoal.targetValue}
                      onChange={(e) => setNewGoal({...newGoal, targetValue: parseInt(e.target.value)})}
                      placeholder="2"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="goal-description">Description</Label>
                  <Textarea
                    id="goal-description"
                    value={newGoal.description}
                    onChange={(e) => setNewGoal({...newGoal, description: e.target.value})}
                    placeholder="Daily study goal to improve academic performance"
                  />
                </div>

                <div className="flex gap-4">
                  <Button onClick={handleCreateGoal} disabled={createGoalMutation.isPending}>
                    Create Goal
                  </Button>
                  <Button variant="outline" onClick={() => setShowGoalForm(false)}>
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-4">
            {goals.map((goal) => (
              <Card key={goal.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2 dark:text-white">{goal.title}</h3>
                      {goal.description && (
                        <p className="text-neutral-600 dark:text-neutral-400 mb-3">{goal.description}</p>
                      )}
                      <div className="flex items-center gap-4 mb-3">
                        <Badge className={getPriorityColor(goal.priority)}>
                          {goal.priority}
                        </Badge>
                        <span className="text-sm text-neutral-500">
                          {goal.category}
                        </span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{goal.currentValue}/{goal.targetValue} {goal.unit}</span>
                        </div>
                        <Progress value={(goal.currentValue / goal.targetValue) * 100} />
                      </div>
                    </div>
                    <div className="ml-4">
                      {goal.isCompleted ? (
                        <CheckCircle className="h-6 w-6 text-green-500" />
                      ) : (
                        <Target className="h-6 w-6 text-blue-500" />
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Mood Trends (Last 7 Days)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={[0, 10]} />
                    <Tooltip />
                    <Line type="monotone" dataKey="mood" stroke="#8884d8" strokeWidth={2} />
                    <Line type="monotone" dataKey="energy" stroke="#82ca9d" strokeWidth={2} />
                    <Line type="monotone" dataKey="motivation" stroke="#ffc658" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Weekly Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {moodEntries.length > 0 && (
                  <>
                    <div className="flex justify-between">
                      <span>Average Mood:</span>
                      <span className="font-semibold">
                        {(moodEntries.slice(-7).reduce((sum, entry) => sum + entry.moodScore, 0) / Math.min(7, moodEntries.length)).toFixed(1)}/10
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Average Energy:</span>
                      <span className="font-semibold">
                        {(moodEntries.slice(-7).reduce((sum, entry) => sum + entry.energyLevel, 0) / Math.min(7, moodEntries.length)).toFixed(1)}/10
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Average Motivation:</span>
                      <span className="font-semibold">
                        {(moodEntries.slice(-7).reduce((sum, entry) => sum + entry.motivationLevel, 0) / Math.min(7, moodEntries.length)).toFixed(1)}/10
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Entries This Week:</span>
                      <span className="font-semibold">{Math.min(7, moodEntries.length)}</span>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}