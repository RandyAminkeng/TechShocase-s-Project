import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calculator, BookOpen, TrendingUp, Users } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Mathematics() {
  const [problem, setProblem] = useState("");
  const [solution, setSolution] = useState("");

  const mathSolveMutation = useMutation({
    mutationFn: async (data: { problem: string }) => {
      const response = await fetch("/api/ai/math", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSolution(data.solution || data.answer || "Solution calculated successfully");
    }
  });

  const mathTopics = [
    { title: "Algebra", description: "Linear equations, polynomials, functions", level: "Beginner to Advanced", icon: "📊" },
    { title: "Calculus", description: "Derivatives, integrals, limits", level: "Intermediate to Advanced", icon: "∫" },
    { title: "Geometry", description: "Shapes, angles, proofs", level: "Beginner to Intermediate", icon: "📐" },
    { title: "Statistics", description: "Data analysis, probability", level: "All Levels", icon: "📈" },
    { title: "Trigonometry", description: "Sine, cosine, tangent functions", level: "Intermediate", icon: "📏" },
    { title: "Number Theory", description: "Prime numbers, divisibility", level: "Advanced", icon: "🔢" },
    { title: "Linear Algebra", description: "Matrices, vectors, transformations", level: "Advanced", icon: "🔄" },
    { title: "Discrete Math", description: "Logic, sets, combinatorics", level: "Intermediate", icon: "🧮" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-blue-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Mathematics Learning Center
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Master mathematics with AI-powered problem solving, interactive lessons, and comprehensive study materials
          </p>
        </div>

        {/* AI Math Solver */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-6 w-6" />
              AI Math Problem Solver
            </CardTitle>
            <CardDescription>
              Enter any mathematical problem and get step-by-step solutions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Textarea
                placeholder="Enter your math problem here... (e.g., Solve: 2x + 5 = 13)"
                value={problem}
                onChange={(e) => setProblem(e.target.value)}
                className="min-h-[100px]"
              />
              <Button 
                onClick={() => mathSolveMutation.mutate({ problem })}
                disabled={!problem.trim() || mathSolveMutation.isPending}
                className="w-full"
              >
                {mathSolveMutation.isPending ? "Solving..." : "Solve Problem"}
              </Button>
              {solution && (
                <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h3 className="font-semibold text-green-800 dark:text-green-200 mb-2">Solution:</h3>
                  <div className="text-green-700 dark:text-green-300 whitespace-pre-wrap">{solution}</div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Math Topics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {mathTopics.map((topic, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <div className="text-4xl mb-2">{topic.icon}</div>
                <CardTitle className="text-lg">{topic.title}</CardTitle>
                <CardDescription>{topic.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">{topic.level}</Badge>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <BookOpen className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-2xl font-bold">500+</p>
                  <p className="text-gray-600 dark:text-gray-400">Practice Problems</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <TrendingUp className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-2xl font-bold">95%</p>
                  <p className="text-gray-600 dark:text-gray-400">Success Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <Users className="h-8 w-8 text-purple-600" />
                <div>
                  <p className="text-2xl font-bold">10K+</p>
                  <p className="text-gray-600 dark:text-gray-400">Students Helped</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}