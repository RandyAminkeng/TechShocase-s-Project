import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import ResourceItem from "@/components/Resources/ResourceItem";
import CollectionCard from "@/components/Resources/CollectionCard";
import { getResources, getSubjects } from "@/lib/api";

const Resources = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("All Subjects");
  const [selectedType, setSelectedType] = useState("All Types");

  const { data: resources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/resources'],
    staleTime: 300000 // 5 minutes
  });

  const { data: subjects } = useQuery({
    queryKey: ['/api/subjects'],
    staleTime: Infinity
  });

  // Filter resources based on search and filters
  const filteredResources = resources?.filter(resource => {
    const matchesSearch = searchTerm === "" || 
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSubject = selectedSubject === "All Subjects" || 
      (subjects?.find(s => s.id === resource.subjectId)?.name === selectedSubject);
    
    const matchesType = selectedType === "All Types" || resource.type === selectedType;
    
    return matchesSearch && matchesSubject && matchesType;
  });

  // Collections data
  const collections = [
    {
      id: 1,
      title: "Mathematics Mastery",
      subjectName: "Mathematics",
      icon: "calculate",
      color: "primary",
      resourceCount: 12,
      updateFrequency: "Updated weekly",
      resources: [
        { title: "Calculus Video Series", type: "Video", duration: "45 min" },
        { title: "Algebra Cheat Sheet", type: "PDF", pages: 4 },
        { title: "Geometry Practice Problems", type: "Practice", items: 25 }
      ]
    },
    {
      id: 2,
      title: "Science Explorer",
      subjectName: "Science",
      icon: "science",
      color: "secondary",
      resourceCount: 15,
      updateFrequency: "Updated weekly",
      resources: [
        { title: "Chemistry Lab Demonstrations", type: "Video", duration: "60 min" },
        { title: "Physics Interactive Simulations", type: "Interactive", items: 8 },
        { title: "Biology Study Guides", type: "PDF", pages: 6 }
      ]
    }
  ];

  return (
    <div className="p-6">
      <header className="mb-6">
        <h2 className="font-heading text-2xl font-bold text-neutral-800 dark:text-white">Resource Center</h2>
        <p className="text-neutral-500 dark:text-neutral-400">Personalized learning materials</p>
      </header>

      {/* Resource Search */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <input 
            type="text" 
            className="w-full px-4 py-3 pl-10 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary dark:bg-neutral-700 dark:border-neutral-600 dark:text-white" 
            placeholder="Search resources..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <span className="material-icons absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 dark:text-neutral-500">search</span>
        </div>
        <div className="flex gap-2">
          <select 
            className="bg-white px-4 py-3 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary dark:bg-neutral-700 dark:border-neutral-600 dark:text-white"
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
          >
            <option>All Subjects</option>
            {subjects?.map(subject => (
              <option key={subject.id}>{subject.name}</option>
            ))}
          </select>
          <select 
            className="bg-white px-4 py-3 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary dark:bg-neutral-700 dark:border-neutral-600 dark:text-white"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
          >
            <option>All Types</option>
            <option>Video</option>
            <option>PDF</option>
            <option>Interactive</option>
            <option>Quiz</option>
            <option>Practice</option>
          </select>
        </div>
      </div>

      {/* Recommended Resources */}
      <section className="mb-8">
        <h3 className="font-heading text-xl font-semibold mb-4 dark:text-white">Recommended for You</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resourcesLoading ? (
            // Skeleton loaders for resources
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="h-72 bg-white rounded-xl shadow-sm animate-pulse dark:bg-neutral-800"></div>
            ))
          ) : (
            filteredResources?.slice(0, 3).map(resource => {
              const subject = subjects?.find(s => s.id === resource.subjectId);
              return (
                <ResourceItem
                  key={resource.id}
                  id={resource.id}
                  title={resource.title}
                  description={resource.description}
                  type={resource.type}
                  subjectName={subject?.name || ""}
                  subjectColor={subject?.color || "primary"}
                  imageUrl={resource.imageUrl || ""}
                  metadata={resource.metadata ? JSON.parse(JSON.stringify(resource.metadata)) : undefined}
                />
              );
            })
          )}
        </div>
      </section>

      {/* Resource Collections */}
      <section>
        <h3 className="font-heading text-xl font-semibold mb-4 dark:text-white">Popular Collections</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {collections.map(collection => (
            <CollectionCard
              key={collection.id}
              id={collection.id}
              title={collection.title}
              subjectName={collection.subjectName}
              icon={collection.icon}
              color={collection.color}
              resourceCount={collection.resourceCount}
              updateFrequency={collection.updateFrequency}
              resources={collection.resources}
            />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Resources;
