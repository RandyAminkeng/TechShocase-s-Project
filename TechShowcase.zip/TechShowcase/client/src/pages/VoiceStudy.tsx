import { useState, useEffect, useRef } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface VoiceSession {
  id: string;
  startTime: Date;
  duration: number;
  commands: string[];
  motivationalMessages: string[];
  studyGoals: string[];
  completed: boolean;
}

interface MotivationalResponse {
  message: string;
  encouragement: string;
  nextAction: string;
  progressUpdate: string;
}

export default function VoiceStudy() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [currentSession, setCurrentSession] = useState<VoiceSession | null>(null);
  const [studyGoal, setStudyGoal] = useState('');
  const [sessionProgress, setSessionProgress] = useState(0);
  const [motivationalMessages, setMotivationalMessages] = useState<string[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceCommands, setVoiceCommands] = useState<string[]>([]);

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis>(window.speechSynthesis);

  // Voice commands for study mode
  const studyCommands = [
    'start study session',
    'set goal',
    'take break',
    'end session',
    'motivate me',
    'show progress',
    'quiz me',
    'study math',
    'study science',
    'study history'
  ];

  const motivationMutation = useMutation({
    mutationFn: async (command: string) => {
      const response = await fetch('/api/voice/motivation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, progress: sessionProgress, goal: studyGoal })
      });
      return response.json();
    },
    onSuccess: (data: MotivationalResponse) => {
      setMotivationalMessages(prev => [...prev, data.message]);
      speakMessage(data.message);
      if (data.progressUpdate) {
        setSessionProgress(prev => Math.min(100, prev + 10));
      }
    }
  });

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      if (recognitionRef.current) {
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onresult = (event: any) => {
          let finalTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript;
            }
          }
          
          if (finalTranscript) {
            setTranscript(finalTranscript);
            processVoiceCommand(finalTranscript.toLowerCase().trim());
          }
        };

        recognitionRef.current.onerror = (event: any) => {
          console.error('Speech recognition error:', event.error);
          setIsListening(false);
        };

        recognitionRef.current.onend = () => {
          setIsListening(false);
        };
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const speakMessage = (message: string) => {
    if (synthRef.current && 'speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.rate = 0.9;
      utterance.pitch = 1.1;
      utterance.volume = 0.8;
      
      utterance.onend = () => {
        setIsSpeaking(false);
      };
      
      synthRef.current.speak(utterance);
    }
  };

  const processVoiceCommand = (command: string) => {
    setVoiceCommands(prev => [...prev, command]);

    if (command.includes('start study') || command.includes('begin study')) {
      startStudySession();
    } else if (command.includes('set goal')) {
      const goalMatch = command.match(/set goal (.+)/);
      if (goalMatch) {
        setStudyGoal(goalMatch[1]);
        speakMessage(`Great! Your study goal is set to: ${goalMatch[1]}. Let's achieve it together!`);
      } else {
        speakMessage('What would you like to study today? Please say "set goal" followed by your study topic.');
      }
    } else if (command.includes('motivate me') || command.includes('encourage me')) {
      motivationMutation.mutate(command);
    } else if (command.includes('take break') || command.includes('break time')) {
      handleBreakTime();
    } else if (command.includes('end session') || command.includes('stop studying')) {
      endStudySession();
    } else if (command.includes('show progress')) {
      speakMessage(`You've completed ${sessionProgress}% of your study session. Keep going, you're doing amazing!`);
    } else if (command.includes('quiz me')) {
      startQuizMode();
    } else {
      // General motivational response for any study-related command
      motivationMutation.mutate(command);
    }
  };

  const startStudySession = () => {
    const newSession: VoiceSession = {
      id: `session_${Date.now()}`,
      startTime: new Date(),
      duration: 0,
      commands: [],
      motivationalMessages: [],
      studyGoals: [studyGoal || 'General Study'],
      completed: false
    };
    
    setCurrentSession(newSession);
    setSessionProgress(0);
    setMotivationalMessages([]);
    speakMessage('Study session started! I\'m here to help you stay motivated and focused. You\'ve got this!');
  };

  const endStudySession = () => {
    if (currentSession) {
      setCurrentSession(null);
      setSessionProgress(0);
      speakMessage(`Excellent work! You've completed your study session. You should be proud of your dedication and effort!`);
    }
  };

  const handleBreakTime = () => {
    speakMessage('Taking a break is important for learning! Rest for a few minutes, then come back stronger. I believe in you!');
  };

  const startQuizMode = () => {
    speakMessage('Quiz mode activated! Get ready to test your knowledge. You\'ve been studying hard, so I know you\'ll do great!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-purple-900 dark:text-purple-100 mb-4">
              Voice-Activated Study Mode
            </h1>
            <p className="text-lg text-neutral-600 dark:text-neutral-400">
              Use your voice to control your study session and get motivational coaching
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Voice Control Panel */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="material-icons">mic</span>
                  Voice Control
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Button
                      onClick={startListening}
                      disabled={isListening}
                      className={`flex-1 ${isListening ? 'bg-red-500 hover:bg-red-600' : 'bg-purple-600 hover:bg-purple-700'}`}
                    >
                      <span className="material-icons mr-2">
                        {isListening ? 'mic' : 'mic_none'}
                      </span>
                      {isListening ? 'Listening...' : 'Start Voice Commands'}
                    </Button>
                    {isListening && (
                      <Button onClick={stopListening} variant="outline">
                        Stop
                      </Button>
                    )}
                  </div>

                  {isListening && (
                    <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                      <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                      <span className="text-sm">Listening for commands...</span>
                    </div>
                  )}

                  {isSpeaking && (
                    <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                      <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                      <span className="text-sm">Speaking...</span>
                    </div>
                  )}

                  {transcript && (
                    <div className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-lg">
                      <p className="text-sm font-medium mb-1">Last Command:</p>
                      <p className="text-neutral-700 dark:text-neutral-300">{transcript}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Study Session Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="material-icons">school</span>
                  Study Session
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {currentSession ? (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-neutral-600 dark:text-neutral-400">Status</span>
                        <Badge className="bg-green-500 text-white">Active</Badge>
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">Progress</span>
                          <span className="text-sm font-medium">{sessionProgress}%</span>
                        </div>
                        <Progress value={sessionProgress} className="h-2" />
                      </div>

                      {studyGoal && (
                        <div>
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">Current Goal</span>
                          <p className="font-medium text-purple-700 dark:text-purple-300">{studyGoal}</p>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-6">
                      <span className="material-icons text-4xl text-neutral-400 mb-2">play_circle</span>
                      <p className="text-neutral-600 dark:text-neutral-400">
                        Say "start study session" to begin
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Voice Commands Guide */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="material-icons">list</span>
                Voice Commands
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {studyCommands.map((command) => (
                  <div key={command} className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg">
                    <p className="font-medium text-sm">{command}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Motivational Messages */}
          {motivationalMessages.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="material-icons">sentiment_very_satisfied</span>
                  Motivational Coaching
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {motivationalMessages.map((message, index) => (
                    <div key={index} className="p-3 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-lg">
                      <p className="text-purple-800 dark:text-purple-200">{message}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Voice Commands */}
          {voiceCommands.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="material-icons">history</span>
                  Recent Commands
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {voiceCommands.slice(-5).reverse().map((command, index) => (
                    <div key={index} className="text-sm text-neutral-600 dark:text-neutral-400 p-2 bg-neutral-50 dark:bg-neutral-800 rounded">
                      "{command}"
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}