import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Crown, Globe, Users, BookOpen, MapPin, Calendar } from "lucide-react";

export default function History() {
  const [searchQuery, setSearchQuery] = useState("");

  const historicalPeriods = [
    {
      title: "Ancient Civilizations",
      period: "3500 BCE - 500 CE",
      description: "Egypt, Mesopotamia, Greece, Rome",
      icon: Crown,
      color: "text-yellow-600",
      events: ["Rise of Writing", "Greek Democracy", "Roman Empire", "Silk Road"]
    },
    {
      title: "Medieval Period",
      period: "500 - 1500 CE",
      description: "Middle Ages, feudalism, crusades",
      icon: Globe,
      color: "text-blue-600",
      events: ["Fall of Rome", "Islamic Golden Age", "Black Death", "Renaissance"]
    },
    {
      title: "Age of Exploration",
      period: "1400 - 1700 CE",
      description: "Discovery, colonization, trade",
      icon: MapPin,
      color: "text-green-600",
      events: ["Columbus", "Magellan", "Colonial America", "Scientific Revolution"]
    },
    {
      title: "Industrial Revolution",
      period: "1760 - 1840",
      description: "Mechanization, urbanization",
      icon: Users,
      color: "text-red-600",
      events: ["Steam Engine", "Factory System", "Railways", "Social Changes"]
    },
    {
      title: "Modern Era",
      period: "1900 - Present",
      description: "World wars, technology, globalization",
      icon: Calendar,
      color: "text-purple-600",
      events: ["World Wars", "Space Age", "Internet", "Digital Revolution"]
    }
  ];

  const civilizations = [
    { name: "Ancient Egypt", period: "3100 - 30 BCE", achievement: "Pyramids, Hieroglyphs", region: "Africa" },
    { name: "Roman Empire", period: "27 BCE - 476 CE", achievement: "Law, Engineering", region: "Europe" },
    { name: "Chinese Dynasties", period: "2070 BCE - 1912 CE", achievement: "Paper, Gunpowder", region: "Asia" },
    { name: "Maya Civilization", period: "2000 BCE - 1500 CE", achievement: "Calendar, Mathematics", region: "Americas" },
    { name: "Islamic Golden Age", period: "8th - 13th Century", achievement: "Algebra, Medicine", region: "Middle East" },
    { name: "Renaissance Italy", period: "14th - 17th Century", achievement: "Art, Science", region: "Europe" }
  ];

  const historicalFigures = [
    { name: "Alexander the Great", era: "Ancient", impact: "Conquered vast empire", field: "Military" },
    { name: "Leonardo da Vinci", era: "Renaissance", impact: "Art and invention", field: "Arts & Science" },
    { name: "Napoleon Bonaparte", era: "Modern", impact: "European conquest", field: "Military & Politics" },
    { name: "Marie Curie", era: "Modern", impact: "Radioactivity research", field: "Science" },
    { name: "Mahatma Gandhi", era: "20th Century", impact: "Non-violent resistance", field: "Politics & Social" },
    { name: "Nelson Mandela", era: "20th Century", impact: "Anti-apartheid leader", field: "Human Rights" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 dark:from-gray-900 dark:to-amber-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            History Learning Center
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Journey through time and explore the events, people, and civilizations that shaped our world
          </p>
        </div>

        <Tabs defaultValue="periods" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="periods">Time Periods</TabsTrigger>
            <TabsTrigger value="civilizations">Civilizations</TabsTrigger>
            <TabsTrigger value="figures">Historical Figures</TabsTrigger>
            <TabsTrigger value="research">Research Tools</TabsTrigger>
          </TabsList>

          <TabsContent value="periods" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {historicalPeriods.map((period, index) => {
                const IconComponent = period.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <IconComponent className={`h-8 w-8 ${period.color}`} />
                        <div>
                          <CardTitle className="text-lg">{period.title}</CardTitle>
                          <Badge variant="outline" className="text-xs mt-1">{period.period}</Badge>
                        </div>
                      </div>
                      <CardDescription>{period.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Key Events:</p>
                        <div className="space-y-1">
                          {period.events.map((event, eventIndex) => (
                            <div key={eventIndex} className="text-sm text-gray-600 dark:text-gray-400">
                              • {event}
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="civilizations" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {civilizations.map((civ, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {civ.name}
                      <Badge variant="secondary">{civ.region}</Badge>
                    </CardTitle>
                    <CardDescription>{civ.period}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Major Achievements:</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{civ.achievement}</p>
                      <Button variant="outline" size="sm" className="w-full mt-3">
                        Explore Civilization
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="figures" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {historicalFigures.map((figure, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-lg">{figure.name}</CardTitle>
                    <div className="flex gap-2">
                      <Badge variant="outline">{figure.era}</Badge>
                      <Badge variant="secondary">{figure.field}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{figure.impact}</p>
                    <Button variant="outline" size="sm" className="w-full">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="research" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Historical Research Tools</CardTitle>
                <CardDescription>
                  Access historical documents, archives, and scholarly resources
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Search historical events, people, or periods..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1"
                  />
                  <Button>Search</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <BookOpen className="h-8 w-8 text-blue-600 mb-2" />
                      <h3 className="font-semibold mb-2">Digital Archives</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Historical documents and manuscripts</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Globe className="h-8 w-8 text-green-600 mb-2" />
                      <h3 className="font-semibold mb-2">World History Database</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Comprehensive timeline of world events</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Users className="h-8 w-8 text-purple-600 mb-2" />
                      <h3 className="font-semibold mb-2">Biographical Records</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Lives of historical figures</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}