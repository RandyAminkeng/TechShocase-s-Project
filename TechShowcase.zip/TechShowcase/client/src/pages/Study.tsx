import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Clock, Target, TrendingUp } from "lucide-react";
import { getSubjects, getCourses, getUserProgress } from "@/lib/api";

export default function Study() {
  const [selectedSubject, setSelectedSubject] = useState<number | null>(null);

  const { data: subjects } = useQuery({
    queryKey: ["/api/subjects"]
  });

  const { data: courses } = useQuery({
    queryKey: ["/api/courses", selectedSubject],
    enabled: !!selectedSubject
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/progress", 1] // Using user ID 1 from seeded data
  });

  const getSubjectProgress = (subjectId: number) => {
    if (!userProgress || !courses) return 0;
    
    const subjectCourses = (courses as any[]).filter((course: any) => course.subjectId === subjectId);
    const subjectProgress = (userProgress as any[]).filter((progress: any) => 
      subjectCourses.some((course: any) => course.id === progress.courseId)
    );
    
    if (subjectProgress.length === 0) return 0;
    
    const avgProgress = subjectProgress.reduce((sum: number, progress: any) => sum + progress.progress, 0) / subjectProgress.length;
    return avgProgress;
  };

  const getCourseProgress = (courseId: number) => {
    const progress = (userProgress as any[])?.find((p: any) => p.courseId === courseId);
    return progress?.progress || 0;
  };

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Study Center</h1>
        <p className="text-muted-foreground">Choose a subject and course to begin your learning journey</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Subjects Panel */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Subjects
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(subjects as any[])?.map((subject: any) => {
                const progress = getSubjectProgress(subject.id);
                return (
                  <Card 
                    key={subject.id}
                    className={`cursor-pointer transition-colors ${
                      selectedSubject === subject.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'
                    }`}
                    onClick={() => setSelectedSubject(subject.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">{subject.name}</h3>
                        <Badge variant="secondary">{Math.round(progress)}%</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{subject.description}</p>
                      <Progress value={progress} className="h-2" />
                    </CardContent>
                  </Card>
                );
              }) || []}
            </CardContent>
          </Card>
        </div>

        {/* Courses Panel */}
        <div className="lg:col-span-2">
          {selectedSubject ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Available Courses
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(courses as any[])?.length ? (
                  <div className="grid gap-4">
                    {(courses as any[]).map((course: any) => {
                      const progress = getCourseProgress(course.id);
                      const progressData = (userProgress as any[])?.find((p: any) => p.courseId === course.id);
                      
                      return (
                        <Card key={course.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-6">
                            <div className="flex items-start gap-4">
                              {course.imageUrl && (
                                <img 
                                  src={course.imageUrl} 
                                  alt={course.name}
                                  className="w-20 h-20 rounded-lg object-cover"
                                />
                              )}
                              <div className="flex-1">
                                <div className="flex items-center justify-between mb-2">
                                  <h3 className="text-xl font-semibold">{course.name}</h3>
                                  <Badge variant={progress > 0 ? "default" : "secondary"}>
                                    {course.level}
                                  </Badge>
                                </div>
                                <p className="text-muted-foreground mb-4">{course.description}</p>
                                
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                                  <div className="flex items-center gap-2">
                                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">{course.totalLessons} lessons</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Clock className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">{progressData?.completedLessons || 0} completed</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">{Math.round(progress)}% progress</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Target className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">{course.level}</span>
                                  </div>
                                </div>
                                
                                <div className="space-y-2 mb-4">
                                  <div className="flex justify-between text-sm">
                                    <span>Progress</span>
                                    <span>{Math.round(progress)}%</span>
                                  </div>
                                  <Progress value={progress} />
                                </div>
                                
                                <div className="flex gap-2">
                                  <Button className="flex-1">
                                    {progress > 0 ? 'Continue Learning' : 'Start Course'}
                                  </Button>
                                  <Button variant="outline">
                                    View Details
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No courses available for this subject yet.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center h-64">
                <div className="text-center">
                  <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Select a Subject</h3>
                  <p className="text-muted-foreground">Choose a subject from the left panel to view available courses</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}