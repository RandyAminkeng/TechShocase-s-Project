import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Send, Bot, User, Code, Calculator, Globe, FileText, Sparkles, Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
}

interface ChatResponse {
  message: string;
  conversationId?: string;
  timestamp: string;
  tokens?: number;
  model: string;
}

export default function ChatGPT() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [activeTab, setActiveTab] = useState("chat");
  const [codeLanguage, setCodeLanguage] = useState("javascript");
  const [creativeType, setCreativeType] = useState("story");
  const [creativeLength, setCreativeLength] = useState("medium");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Real ChatGPT-like chat
  const chatMutation = useMutation({
    mutationFn: async (message: string): Promise<ChatResponse> => {
      return await apiRequest('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          conversationHistory: messages.slice(-10), // Keep last 10 messages for context
          systemPrompt: "You are ChatGPT, a helpful AI assistant created by OpenAI. Provide helpful, accurate, and engaging responses to user questions."
        })
      });
    },
    onSuccess: (response: ChatResponse) => {
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response.message,
        timestamp: response.timestamp
      };
      setMessages(prev => [...prev, assistantMessage]);
    }
  });

  // Intelligent search
  const searchMutation = useMutation({
    mutationFn: async (query: string): Promise<any> => {
      return await apiRequest('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });
    }
  });

  // Code generation
  const codeMutation = useMutation({
    mutationFn: async (description: string): Promise<any> => {
      return await apiRequest('/api/ai/code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description,
          language: codeLanguage
        })
      });
    }
  });

  // Math solving
  const mathMutation = useMutation({
    mutationFn: async (problem: string): Promise<any> => {
      return await apiRequest('/api/ai/math', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ problem })
      });
    }
  });

  // Translation
  const translateMutation = useMutation({
    mutationFn: async ({ text, targetLanguage }: { text: string; targetLanguage: string }): Promise<any> => {
      return await apiRequest('/api/ai/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          targetLanguage
        })
      });
    }
  });

  // Content summarization
  const summarizeMutation = useMutation({
    mutationFn: async (content: string): Promise<any> => {
      return await apiRequest('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
      });
    }
  });

  // Creative content generation
  const creativeMutation = useMutation({
    mutationFn: async (prompt: string): Promise<any> => {
      return await apiRequest('/api/ai/creative', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          type: creativeType,
          length: creativeLength
        })
      });
    }
  });

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");

    await chatMutation.mutateAsync(input);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-2">ChatGPT AI Assistant</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Powered by OpenAI's GPT-4o - Real AI Intelligence
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="chat" className="flex items-center gap-2">
            <Bot className="w-4 h-4" />
            Chat
          </TabsTrigger>
          <TabsTrigger value="search" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            Search
          </TabsTrigger>
          <TabsTrigger value="code" className="flex items-center gap-2">
            <Code className="w-4 h-4" />
            Code
          </TabsTrigger>
          <TabsTrigger value="math" className="flex items-center gap-2">
            <Calculator className="w-4 h-4" />
            Math
          </TabsTrigger>
          <TabsTrigger value="translate" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            Translate
          </TabsTrigger>
          <TabsTrigger value="creative" className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            Creative
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="space-y-4">
          <Card className="h-[600px] flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="w-5 h-5" />
                AI Chat Assistant
                <Badge variant="secondary">GPT-4o</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <ScrollArea className="flex-1 mb-4">
                <div className="space-y-4">
                  {messages.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Bot className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Start a conversation with ChatGPT!</p>
                      <p className="text-sm">Ask me anything - I'm powered by real AI.</p>
                    </div>
                  )}
                  {messages.map((message, index) => (
                    <div key={index} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`flex gap-3 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          message.role === 'user' ? 'bg-blue-500' : 'bg-green-500'
                        }`}>
                          {message.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
                        </div>
                        <div className={`p-3 rounded-lg ${
                          message.role === 'user' 
                            ? 'bg-blue-500 text-white' 
                            : 'bg-gray-100 dark:bg-gray-800'
                        }`}>
                          <p className="whitespace-pre-wrap">{message.content}</p>
                          <p className="text-xs opacity-70 mt-1">
                            {new Date(message.timestamp).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {chatMutation.isPending && (
                    <div className="flex gap-3 justify-start">
                      <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                        <Loader2 className="w-4 h-4 text-white animate-spin" />
                      </div>
                      <div className="p-3 rounded-lg bg-gray-100 dark:bg-gray-800">
                        <p>Thinking...</p>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
              <div className="flex gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything..."
                  className="flex-1 min-h-[60px]"
                  disabled={chatMutation.isPending}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!input.trim() || chatMutation.isPending}
                  size="lg"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                AI-Powered Search
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Search for anything..."
                  onKeyPress={(e) => e.key === 'Enter' && searchMutation.mutate(input)}
                />
                <Button
                  onClick={() => searchMutation.mutate(input)}
                  disabled={!input.trim() || searchMutation.isPending}
                >
                  {searchMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Globe className="w-4 h-4" />}
                  Search
                </Button>
              </div>
              {searchMutation.data && (
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <h3 className="font-semibold mb-2">AI Answer</h3>
                    <p>{searchMutation.data.answer}</p>
                  </div>
                  {searchMutation.data.sources.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-2">Sources</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {searchMutation.data.sources.map((source: string, index: number) => (
                          <li key={index} className="text-sm text-gray-600 dark:text-gray-400">{source}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {searchMutation.data.relatedQuestions.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-2">Related Questions</h4>
                      <div className="space-y-1">
                        {searchMutation.data.relatedQuestions.map((question: string, index: number) => (
                          <Button
                            key={index}
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setInput(question);
                              searchMutation.mutate(question);
                            }}
                            className="mr-2 mb-2"
                          >
                            {question}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="code" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                AI Code Generator
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Select value={codeLanguage} onValueChange={setCodeLanguage}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="java">Java</SelectItem>
                    <SelectItem value="cpp">C++</SelectItem>
                    <SelectItem value="html">HTML</SelectItem>
                    <SelectItem value="css">CSS</SelectItem>
                    <SelectItem value="sql">SQL</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Describe the code you want to generate..."
                  className="min-h-[100px]"
                />
                <Button
                  onClick={() => codeMutation.mutate(input)}
                  disabled={!input.trim() || codeMutation.isPending}
                >
                  {codeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Code className="w-4 h-4" />}
                  Generate
                </Button>
              </div>
              {codeMutation.data && (
                <div className="space-y-4">
                  <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <h3 className="font-semibold mb-2">Generated Code</h3>
                    <pre className="text-sm overflow-x-auto">
                      <code>{codeMutation.data.code}</code>
                    </pre>
                  </div>
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <h3 className="font-semibold mb-2">Explanation</h3>
                    <p>{codeMutation.data.explanation}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="math" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                AI Math Solver
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Enter your math problem..."
                  className="min-h-[100px]"
                />
                <Button
                  onClick={() => mathMutation.mutate(input)}
                  disabled={!input.trim() || mathMutation.isPending}
                >
                  {mathMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Calculator className="w-4 h-4" />}
                  Solve
                </Button>
              </div>
              {mathMutation.data && (
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <h3 className="font-semibold mb-2">Solution</h3>
                    <p className="text-lg font-mono">{mathMutation.data.solution}</p>
                  </div>
                  {mathMutation.data.steps.length > 0 && (
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <h3 className="font-semibold mb-2">Steps</h3>
                      <ol className="list-decimal list-inside space-y-1">
                        {mathMutation.data.steps.map((step: string, index: number) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  )}
                  <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <h3 className="font-semibold mb-2">Explanation</h3>
                    <p>{mathMutation.data.explanation}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="translate" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                AI Translator
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Enter text to translate..."
                  className="min-h-[150px]"
                />
                <div className="space-y-2">
                  <Select onValueChange={(value) => translateMutation.mutate({ text: input, targetLanguage: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select target language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Spanish">Spanish</SelectItem>
                      <SelectItem value="French">French</SelectItem>
                      <SelectItem value="German">German</SelectItem>
                      <SelectItem value="Italian">Italian</SelectItem>
                      <SelectItem value="Portuguese">Portuguese</SelectItem>
                      <SelectItem value="Chinese">Chinese</SelectItem>
                      <SelectItem value="Japanese">Japanese</SelectItem>
                      <SelectItem value="Korean">Korean</SelectItem>
                      <SelectItem value="Arabic">Arabic</SelectItem>
                      <SelectItem value="Russian">Russian</SelectItem>
                    </SelectContent>
                  </Select>
                  {translateMutation.data && (
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <h3 className="font-semibold mb-2">Translation</h3>
                      <p>{translateMutation.data.translation}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                        Confidence: {Math.round(translateMutation.data.confidence * 100)}%
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="creative" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                AI Creative Writer
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Select value={creativeType} onValueChange={setCreativeType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="story">Story</SelectItem>
                    <SelectItem value="poem">Poem</SelectItem>
                    <SelectItem value="article">Article</SelectItem>
                    <SelectItem value="essay">Essay</SelectItem>
                    <SelectItem value="creative">Creative Writing</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={creativeLength} onValueChange={setCreativeLength}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Short</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="long">Long</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Describe what you want me to write..."
                  className="min-h-[100px]"
                />
                <Button
                  onClick={() => creativeMutation.mutate(input)}
                  disabled={!input.trim() || creativeMutation.isPending}
                >
                  {creativeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  Create
                </Button>
              </div>
              {creativeMutation.data && (
                <div className="space-y-4">
                  <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <h3 className="font-semibold mb-2">{creativeMutation.data.title}</h3>
                    <div className="whitespace-pre-wrap">{creativeMutation.data.content}</div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-4">
                      Word count: {creativeMutation.data.wordCount}
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}