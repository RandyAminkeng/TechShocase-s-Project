import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, 
  MessageCircle, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Bot, 
  User, 
  Lightbulb,
  Smile,
  Frown,
  Meh,
  Star,
  Clock,
  Target,
  TrendingUp,
  Coffee,
  Brain,
  Zap
} from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  mood?: 'happy' | 'neutral' | 'sad' | 'stressed' | 'motivated' | 'confused';
  empathyMode?: 'supportive' | 'motivational' | 'encouraging' | 'understanding';
}

interface MoodEntry {
  mood: string;
  energy: number;
  motivation: number;
  stress: number;
  timestamp: string;
}

const empathyModes = [
  {
    id: 'supportive',
    name: 'Supportive',
    description: 'Gentle, understanding responses that validate your feelings',
    icon: Heart,
    color: 'text-pink-600'
  },
  {
    id: 'motivational',
    name: 'Motivational',
    description: 'Energizing responses that boost confidence and drive',
    icon: Zap,
    color: 'text-yellow-600'
  },
  {
    id: 'encouraging',
    name: 'Encouraging',
    description: 'Positive reinforcement and celebration of progress',
    icon: Star,
    color: 'text-blue-600'
  },
  {
    id: 'understanding',
    name: 'Understanding',
    description: 'Patient responses that acknowledge struggles and provide guidance',
    icon: Brain,
    color: 'text-purple-600'
  }
];

const quickMoodActions = [
  { emoji: '😊', mood: 'happy', label: 'Feeling good' },
  { emoji: '😐', mood: 'neutral', label: 'Okay' },
  { emoji: '😔', mood: 'sad', label: 'Down' },
  { emoji: '😰', mood: 'stressed', label: 'Stressed' },
  { emoji: '💪', mood: 'motivated', label: 'Motivated' },
  { emoji: '😕', mood: 'confused', label: 'Confused' }
];

export default function StudyBuddy() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [currentMood, setCurrentMood] = useState<string>('neutral');
  const [empathyMode, setEmpathyMode] = useState('supportive');
  const [isListening, setIsListening] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(false);
  const [energyLevel, setEnergyLevel] = useState(5);
  const [motivationLevel, setMotivationLevel] = useState(5);
  const [stressLevel, setStressLevel] = useState(5);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognition = useRef<any>(null);
  const synthesis = useRef<any>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize speech features
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognition.current = new SpeechRecognition();
        recognition.current.continuous = false;
        recognition.current.interimResults = false;
        recognition.current.lang = 'en-US';

        recognition.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setInputMessage(transcript);
          setIsListening(false);
        };

        recognition.current.onerror = () => setIsListening(false);
        recognition.current.onend = () => setIsListening(false);
      }

      if ('speechSynthesis' in window) {
        synthesis.current = window.speechSynthesis;
      }
    }
  }, []);

  // Fetch mood entries
  const { data: moodEntries = [] } = useQuery<MoodEntry[]>({
    queryKey: ['/api/mood/entries'],
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/api/ai/chat', {
        method: 'POST',
        body: JSON.stringify({
          message: data.message,
          conversationHistory: messages.slice(-5).map(m => ({
            role: m.role,
            content: m.content
          })),
          systemPrompt: `You are an empathetic AI study buddy. Current empathy mode: ${empathyMode}. User's current mood: ${currentMood}. Energy level: ${energyLevel}/10, Motivation: ${motivationLevel}/10, Stress: ${stressLevel}/10. 
          
          ${empathyMode === 'supportive' ? 'Respond with gentle, understanding language that validates their feelings and provides emotional support.' : ''}
          ${empathyMode === 'motivational' ? 'Respond with energizing, confidence-boosting language that inspires action and perseverance.' : ''}
          ${empathyMode === 'encouraging' ? 'Respond with positive reinforcement, celebrating progress and highlighting strengths.' : ''}
          ${empathyMode === 'understanding' ? 'Respond with patience and acknowledgment of struggles, providing thoughtful guidance.' : ''}
          
          Always be helpful with study-related questions while maintaining the empathetic tone.`,
          context: `study buddy empathy mode: ${empathyMode}, mood: ${currentMood}`
        }),
      });
    },
    onSuccess: (response: any) => {
      const assistantMessage: ChatMessage = {
        id: Date.now().toString() + '_assistant',
        role: 'assistant',
        content: response.message || response.answer || 'I understand. How can I help you with your studies today?',
        timestamp: new Date().toISOString(),
        empathyMode: empathyMode as any
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Text-to-speech if enabled
      if (speechEnabled && synthesis.current) {
        const utterance = new SpeechSynthesisUtterance(assistantMessage.content);
        utterance.rate = 0.9;
        utterance.pitch = 1.1;
        synthesis.current.speak(utterance);
      }
    },
    onError: (error) => {
      toast({
        title: "Connection issue",
        description: "I'm having trouble responding right now. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Save mood entry mutation
  const saveMoodMutation = useMutation({
    mutationFn: async (moodData: any) => {
      return apiRequest('/api/mood/entries', {
        method: 'POST',
        body: JSON.stringify(moodData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mood/entries'] });
      toast({
        title: "Mood saved",
        description: "Your mood has been recorded to help me understand you better.",
      });
    },
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString() + '_user',
      role: 'user',
      content: inputMessage.trim(),
      timestamp: new Date().toISOString(),
      mood: currentMood as any
    };

    setMessages(prev => [...prev, userMessage]);
    sendMessageMutation.mutate({ message: inputMessage.trim() });
    setInputMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const startListening = () => {
    if (recognition.current && !isListening) {
      setIsListening(true);
      recognition.current.start();
    }
  };

  const stopListening = () => {
    if (recognition.current && isListening) {
      recognition.current.stop();
    }
  };

  const handleMoodChange = (mood: string) => {
    setCurrentMood(mood);
    
    // Save mood entry
    saveMoodMutation.mutate({
      userId: 1,
      moodScore: mood === 'happy' ? 8 : mood === 'sad' ? 3 : mood === 'stressed' ? 4 : mood === 'motivated' ? 9 : mood === 'confused' ? 5 : 6,
      energyLevel,
      motivationLevel,
      stressLevel,
      notes: `Quick mood update: ${mood}`
    });

    // Send contextual message based on mood
    const moodMessages = {
      happy: "I'm glad you're feeling good! What would you like to work on while you're in this positive mindset?",
      sad: "I notice you're feeling down. That's completely okay - we all have those moments. Would you like to talk about what's on your mind, or shall we focus on something that might help lift your spirits?",
      stressed: "I can sense you're feeling stressed. Take a deep breath with me. Remember, stress is temporary, and we can work through this together. What's causing the most pressure right now?",
      motivated: "I love your energy! This is a perfect time to tackle challenging material. What goal would you like to focus on while you're feeling so motivated?",
      confused: "It's perfectly normal to feel confused when learning something new. Confusion often means you're on the edge of a breakthrough! What topic is puzzling you?",
      neutral: "I'm here whenever you need support. What's on your study agenda today?"
    };

    if (moodMessages[mood as keyof typeof moodMessages]) {
      const contextMessage: ChatMessage = {
        id: Date.now().toString() + '_mood_response',
        role: 'assistant',
        content: moodMessages[mood as keyof typeof moodMessages],
        timestamp: new Date().toISOString(),
        empathyMode: empathyMode as any
      };
      
      setTimeout(() => {
        setMessages(prev => [...prev, contextMessage]);
      }, 500);
    }
  };

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const selectedEmpathyMode = empathyModes.find(mode => mode.id === empathyMode);

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="flex items-center gap-3 mb-6">
        <Heart className="h-8 w-8 text-pink-600" />
        <div>
          <h1 className="text-3xl font-bold dark:text-white">AI Study Buddy</h1>
          <p className="text-neutral-600 dark:text-neutral-400">Your empathetic learning companion</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          {/* Empathy Mode Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                {selectedEmpathyMode && <selectedEmpathyMode.icon className={`h-5 w-5 ${selectedEmpathyMode.color}`} />}
                Empathy Mode
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={empathyMode} onValueChange={setEmpathyMode}>
                <SelectTrigger>
                  <SelectValue placeholder="Select empathy mode" />
                </SelectTrigger>
                <SelectContent>
                  {empathyModes.map((mode) => {
                    const Icon = mode.icon;
                    return (
                      <SelectItem key={mode.id} value={mode.id}>
                        <div className="flex items-center gap-2">
                          <Icon className={`h-4 w-4 ${mode.color}`} />
                          {mode.name}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              {selectedEmpathyMode && (
                <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-2">
                  {selectedEmpathyMode.description}
                </p>
              )}
            </CardContent>
          </Card>

          {/* Quick Mood Check */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">How are you feeling?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {quickMoodActions.map((action) => (
                  <Button
                    key={action.mood}
                    variant={currentMood === action.mood ? "default" : "outline"}
                    size="sm"
                    className="h-auto p-2 flex flex-col gap-1"
                    onClick={() => handleMoodChange(action.mood)}
                  >
                    <span className="text-lg">{action.emoji}</span>
                    <span className="text-xs">{action.label}</span>
                  </Button>
                ))}
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium">Energy: {energyLevel}/10</label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={energyLevel}
                    onChange={(e) => setEnergyLevel(Number(e.target.value))}
                    className="w-full mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Motivation: {motivationLevel}/10</label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={motivationLevel}
                    onChange={(e) => setMotivationLevel(Number(e.target.value))}
                    className="w-full mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Stress: {stressLevel}/10</label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={stressLevel}
                    onChange={(e) => setStressLevel(Number(e.target.value))}
                    className="w-full mt-1"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Voice Features */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Voice Features</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Text-to-Speech</label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSpeechEnabled(!speechEnabled)}
                >
                  {speechEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
              </div>
              
              {recognition.current && (
                <Button
                  variant={isListening ? "destructive" : "outline"}
                  size="sm"
                  onClick={isListening ? stopListening : startListening}
                  disabled={sendMessageMutation.isPending}
                  className="w-full"
                >
                  {isListening ? <MicOff className="h-4 w-4 mr-2" /> : <Mic className="h-4 w-4 mr-2" />}
                  {isListening ? 'Stop Listening' : 'Voice Input'}
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Main Chat Area */}
        <div className="lg:col-span-3">
          <Card className="h-[700px] flex flex-col">
            <CardHeader className="border-b">
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                Study Buddy Chat
                <Badge variant="outline" className="ml-auto">
                  {messages.length} messages
                </Badge>
              </CardTitle>
              <CardDescription>
                Currently in {selectedEmpathyMode?.name.toLowerCase()} mode • Mood: {currentMood}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col p-0">
              {/* Messages Area */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.length === 0 && (
                    <div className="text-center py-8 text-neutral-500">
                      <Heart className="h-12 w-12 mx-auto mb-4 text-pink-400" />
                      <p>Hi there! I'm your AI study buddy.</p>
                      <p className="text-sm mt-2">I'm here to support you emotionally and academically. How are you feeling today?</p>
                    </div>
                  )}
                  
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex gap-3 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          message.role === 'user' 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-pink-100 dark:bg-pink-900 text-pink-600 dark:text-pink-400'
                        }`}>
                          {message.role === 'user' ? <User className="h-4 w-4" /> : <Heart className="h-4 w-4" />}
                        </div>
                        
                        <div className={`rounded-lg p-3 ${
                          message.role === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-neutral-100 dark:bg-neutral-800 border'
                        }`}>
                          <p className="whitespace-pre-wrap">{message.content}</p>
                          <div className={`text-xs mt-2 flex items-center gap-2 ${
                            message.role === 'user' ? 'text-blue-100' : 'text-neutral-500'
                          }`}>
                            <span>{new Date(message.timestamp).toLocaleTimeString()}</span>
                            {message.mood && (
                              <Badge variant="secondary" className="text-xs py-0">
                                {message.mood}
                              </Badge>
                            )}
                            {message.empathyMode && (
                              <Badge variant="outline" className="text-xs py-0">
                                {message.empathyMode}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {sendMessageMutation.isPending && (
                    <div className="flex gap-3 justify-start">
                      <div className="flex gap-3 max-w-[80%]">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center bg-pink-100 dark:bg-pink-900 text-pink-600 dark:text-pink-400">
                          <Heart className="h-4 w-4" />
                        </div>
                        <div className="bg-neutral-100 dark:bg-neutral-800 border rounded-lg p-3">
                          <div className="flex items-center gap-2">
                            <div className="animate-pulse flex space-x-1">
                              <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                              <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                            </div>
                            <span className="text-sm text-neutral-500">Thinking with empathy...</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="border-t p-4">
                <div className="flex gap-2">
                  <Textarea
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Share what's on your mind or ask for study help..."
                    className="flex-1 min-h-[50px] max-h-[120px] resize-none"
                    disabled={sendMessageMutation.isPending}
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!inputMessage.trim() || sendMessageMutation.isPending}
                    className="self-end"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center justify-between mt-2 text-xs text-neutral-500">
                  <span>Press Enter to send, Shift+Enter for new line</span>
                  {isListening && (
                    <span className="text-red-500 animate-pulse">🎤 Listening...</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}