import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import StatCard from "@/components/Dashboard/StatCard";
import LearningCard from "@/components/Dashboard/LearningCard";
import AiTutorCard from "@/components/Dashboard/AiTutorCard";
import ResourceCard from "@/components/Dashboard/ResourceCard";
import LiveActivityFeed from "@/components/LiveActivityFeed";
import { getUserStats, getUserProgress, getRecommendedResources, getUser } from "@/lib/api";
import type { UserStats, UserProgress, Resource } from "@/../../shared/schema";

const Dashboard = () => {
  const { data: user } = useQuery({
    queryKey: ['/api/me'],
    staleTime: Infinity
  });

  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ['/api/stats/1'],
    staleTime: 60000 // 1 minute
  });

  const { data: progress, isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: ['/api/progress/1'],
    staleTime: 60000 // 1 minute
  });

  const { data: resources, isLoading: resourcesLoading } = useQuery<Resource[]>({
    queryKey: ['/api/resources/recommended/1'],
    staleTime: 300000 // 5 minutes
  });

  return (
    <div className="p-6">
      <header className="mb-8">
        <h2 className="font-heading text-2xl font-bold text-neutral-800 dark:text-white">
          Welcome back, {(user as any)?.displayName?.split(' ')[0] || 'Student'}!
        </h2>
        <p className="text-neutral-500 dark:text-neutral-400">Continue your learning journey</p>
      </header>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {statsLoading ? (
          // Skeleton loaders for stats
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="h-32 bg-white rounded-xl shadow-sm animate-pulse dark:bg-neutral-800"></div>
          ))
        ) : (
          <>
            <StatCard 
              title="Learning Hours" 
              value={stats?.learningHours || 0} 
              change="+2.4 hours this week" 
              icon="schedule" 
              iconColor="primary"
            />
            <StatCard 
              title="Completed Lessons" 
              value={stats?.completedLessons || 0} 
              change="+5 lessons this week" 
              icon="task_alt" 
              iconColor="secondary"
            />
            <StatCard 
              title="Current Streak" 
              value={`${stats?.streak || 0} days`} 
              change={`Best: ${stats?.bestStreak || 0} days`} 
              icon="bolt" 
              iconColor="accent"
            />
          </>
        )}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-8">
        {/* Continue Learning Section */}
        <section className="lg:col-span-3">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading text-xl font-semibold dark:text-white">Continue Learning</h3>
            <Link href="/subjects" className="text-primary text-sm font-medium flex items-center dark:text-primary-light">
              View all
              <span className="material-icons text-sm ml-1">chevron_right</span>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {progressLoading ? (
              // Skeleton loaders for learning cards
              Array(3).fill(0).map((_, i) => (
                <div key={i} className="h-56 bg-white rounded-xl shadow-sm animate-pulse dark:bg-neutral-800"></div>
              ))
            ) : (
              progress?.slice(0, 3).map((item: any) => (
                <LearningCard
                  key={item.courseId}
                  id={item.courseId}
                  title={item.course?.name || "Course"}
                  subject={item.course?.subjectId === 1 ? "Mathematics" : 
                           item.course?.subjectId === 2 ? "Science" :
                           "Languages"}
                  progress={item.progress}
                  icon={item.course?.subjectId === 1 ? "calculate" : 
                        item.course?.subjectId === 2 ? "science" :
                        "language"}
                  color={item.course?.subjectId === 1 ? "primary" : 
                         item.course?.subjectId === 2 ? "secondary" :
                         "accent"}
                />
              ))
            )}
          </div>
        </section>

        {/* Live Activity Feed */}
        <section className="lg:col-span-1">
          <LiveActivityFeed />
        </section>
      </div>

      {/* AI Tutor Quick Access */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading text-xl font-semibold dark:text-white">AI Tutor</h3>
          <Link href="/ai-tutor" className="text-primary text-sm font-medium flex items-center dark:text-primary-light">
            Full mode
            <span className="material-icons text-sm ml-1">chevron_right</span>
          </Link>
        </div>
        
        <AiTutorCard />
      </section>

      {/* Recommended Resources */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading text-xl font-semibold dark:text-white">Recommended Resources</h3>
          <Link href="/resources" className="text-primary text-sm font-medium flex items-center dark:text-primary-light">
            View all
            <span className="material-icons text-sm ml-1">chevron_right</span>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resourcesLoading ? (
            // Skeleton loaders for resource cards
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="h-64 bg-white rounded-xl shadow-sm animate-pulse dark:bg-neutral-800"></div>
            ))
          ) : (
            resources?.map((resource: any) => (
              <ResourceCard
                key={resource.id}
                id={resource.id}
                title={resource.title}
                description={resource.description}
                subject={resource.subjectId === 1 ? "Mathematics" : 
                         resource.subjectId === 2 ? "Science" :
                         "Languages"}
                subjectColor={resource.subjectId === 1 ? "primary" : 
                              resource.subjectId === 2 ? "secondary" :
                              "accent"}
                imageUrl={resource.imageUrl}
              />
            ))
          )}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
