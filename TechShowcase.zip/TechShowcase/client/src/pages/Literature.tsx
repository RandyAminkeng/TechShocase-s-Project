import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Feather, Quote, Users, Globe, Award } from "lucide-react";

export default function Literature() {
  const [searchQuery, setSearchQuery] = useState("");

  const literaryPeriods = [
    {
      title: "Classical Literature",
      period: "800 BCE - 500 CE",
      description: "Ancient Greek and Roman works",
      icon: Quote,
      color: "text-purple-600",
      works: ["The Iliad", "The Odyssey", "Aeneid", "Metamorphoses"]
    },
    {
      title: "Medieval Literature",
      period: "500 - 1500 CE",
      description: "Epic poems, religious texts, courtly romance",
      icon: BookOpen,
      color: "text-blue-600",
      works: ["Beowulf", "Divine Comedy", "Canterbury Tales", "Arthurian Legends"]
    },
    {
      title: "Renaissance",
      period: "1400 - 1600",
      description: "Humanism, sonnets, dramatic works",
      icon: Feather,
      color: "text-green-600",
      works: ["Hamlet", "Romeo and Juliet", "Paradise Lost", "Don Quixote"]
    },
    {
      title: "Romantic Period",
      period: "1800 - 1850",
      description: "Emotion, nature, individualism",
      icon: Globe,
      color: "text-red-600",
      works: ["Pride and Prejudice", "Frankenstein", "Wuthering Heights", "Jane Eyre"]
    },
    {
      title: "Modern Literature",
      period: "1900 - 1945",
      description: "Experimental forms, stream of consciousness",
      icon: Users,
      color: "text-orange-600",
      works: ["Ulysses", "The Waste Land", "1984", "To Kill a Mockingbird"]
    },
    {
      title: "Contemporary",
      period: "1945 - Present",
      description: "Diverse voices, postmodernism, global literature",
      icon: Award,
      color: "text-indigo-600",
      works: ["Beloved", "One Hundred Years of Solitude", "The Kite Runner", "Persepolis"]
    }
  ];

  const authors = [
    { name: "William Shakespeare", period: "Renaissance", nationality: "English", genre: "Drama/Poetry" },
    { name: "Jane Austen", period: "Romantic", nationality: "English", genre: "Novel" },
    { name: "Charles Dickens", period: "Victorian", nationality: "English", genre: "Social Novel" },
    { name: "Virginia Woolf", period: "Modernist", nationality: "English", genre: "Experimental Fiction" },
    { name: "Gabriel García Márquez", period: "Contemporary", nationality: "Colombian", genre: "Magical Realism" },
    { name: "Toni Morrison", period: "Contemporary", nationality: "American", genre: "Literary Fiction" },
    { name: "Chinua Achebe", period: "Postcolonial", nationality: "Nigerian", genre: "African Literature" },
    { name: "Haruki Murakami", period: "Contemporary", nationality: "Japanese", genre: "Surreal Fiction" }
  ];

  const genres = [
    { name: "Epic Poetry", description: "Long narrative poems about heroic deeds", examples: ["The Iliad", "Beowulf"] },
    { name: "Tragedy", description: "Dramatic works ending in catastrophe", examples: ["Hamlet", "Oedipus Rex"] },
    { name: "Comedy", description: "Humorous works with happy endings", examples: ["A Midsummer Night's Dream", "The Importance of Being Earnest"] },
    { name: "Romance", description: "Stories of love and adventure", examples: ["Pride and Prejudice", "Jane Eyre"] },
    { name: "Gothic Fiction", description: "Dark, mysterious, supernatural elements", examples: ["Frankenstein", "Dracula"] },
    { name: "Science Fiction", description: "Futuristic and technological themes", examples: ["1984", "Brave New World"] },
    { name: "Magical Realism", description: "Realistic narrative with magical elements", examples: ["One Hundred Years of Solitude", "Beloved"] },
    { name: "Autobiography", description: "Personal life stories", examples: ["The Autobiography of Malcolm X", "I Know Why the Caged Bird Sings"] }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 dark:from-gray-900 dark:to-purple-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Literature & Language Arts
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Explore the world of literature through classic and contemporary works, literary analysis, and creative writing
          </p>
        </div>

        <Tabs defaultValue="periods" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="periods">Literary Periods</TabsTrigger>
            <TabsTrigger value="authors">Authors</TabsTrigger>
            <TabsTrigger value="genres">Genres</TabsTrigger>
            <TabsTrigger value="analysis">Analysis Tools</TabsTrigger>
          </TabsList>

          <TabsContent value="periods" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {literaryPeriods.map((period, index) => {
                const IconComponent = period.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <IconComponent className={`h-8 w-8 ${period.color}`} />
                        <div>
                          <CardTitle className="text-lg">{period.title}</CardTitle>
                          <Badge variant="outline" className="text-xs mt-1">{period.period}</Badge>
                        </div>
                      </div>
                      <CardDescription>{period.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Notable Works:</p>
                        <div className="space-y-1">
                          {period.works.map((work, workIndex) => (
                            <div key={workIndex} className="text-sm text-gray-600 dark:text-gray-400">
                              • {work}
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="authors" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {authors.map((author, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {author.name}
                      <Badge variant="secondary">{author.nationality}</Badge>
                    </CardTitle>
                    <div className="flex gap-2">
                      <Badge variant="outline">{author.period}</Badge>
                      <Badge variant="outline">{author.genre}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" size="sm" className="w-full">
                      Explore Works
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="genres" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {genres.map((genre, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-lg">{genre.name}</CardTitle>
                    <CardDescription>{genre.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Examples:</p>
                      <div className="space-y-1">
                        {genre.examples.map((example, exampleIndex) => (
                          <div key={exampleIndex} className="text-sm text-gray-600 dark:text-gray-400">
                            • {example}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Literary Analysis Tools</CardTitle>
                <CardDescription>
                  AI-powered tools for analyzing themes, characters, and literary devices
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter text to analyze for themes, style, or literary devices..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1"
                  />
                  <Button>Analyze</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <Quote className="h-8 w-8 text-blue-600 mb-2" />
                      <h3 className="font-semibold mb-2">Theme Analysis</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Identify central themes and motifs</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Users className="h-8 w-8 text-green-600 mb-2" />
                      <h3 className="font-semibold mb-2">Character Study</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Analyze character development and relationships</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <Feather className="h-8 w-8 text-purple-600 mb-2" />
                      <h3 className="font-semibold mb-2">Literary Devices</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Detect metaphors, symbolism, and style</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}