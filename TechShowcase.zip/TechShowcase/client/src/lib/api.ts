import { apiRequest } from "./queryClient";

// User endpoints
export async function getUser(userId: number) {
  const res = await apiRequest("GET", `/api/users/${userId}`);
  return res.json();
}

export async function getCurrentUser() {
  const res = await apiRequest("GET", "/api/me");
  return res.json();
}

// Subject endpoints
export async function getSubjects() {
  const res = await apiRequest("GET", "/api/subjects");
  return res.json();
}

export async function getSubject(subjectId: number) {
  const res = await apiRequest("GET", `/api/subjects/${subjectId}`);
  return res.json();
}

// Course endpoints
export async function getCourses(subjectId?: number) {
  const url = subjectId ? `/api/courses?subjectId=${subjectId}` : "/api/courses";
  const res = await apiRequest("GET", url);
  return res.json();
}

export async function getCourse(courseId: number) {
  const res = await apiRequest("GET", `/api/courses/${courseId}`);
  return res.json();
}

// Progress endpoints
export async function getUserProgress(userId: number) {
  const res = await apiRequest("GET", `/api/progress/${userId}`);
  return res.json();
}

export async function updateProgress(progressId: number, data: any) {
  const res = await apiRequest("PUT", `/api/progress/${progressId}`, data);
  return res.json();
}

// Stats endpoints
export async function getUserStats(userId: number) {
  const res = await apiRequest("GET", `/api/stats/${userId}`);
  return res.json();
}

export async function updateUserStats(userId: number, data: any) {
  const res = await apiRequest("PUT", `/api/stats/${userId}`, data);
  return res.json();
}

// Resource endpoints
export async function getResources(subjectId?: number) {
  const url = subjectId ? `/api/resources?subjectId=${subjectId}` : "/api/resources";
  const res = await apiRequest("GET", url);
  return res.json();
}

export async function getRecommendedResources(userId: number) {
  const res = await apiRequest("GET", `/api/resources/recommended/${userId}`);
  return res.json();
}

// AI Tutor endpoints
export interface TutorQuestionRequest {
  userId: number;
  subjectId: number;
  question: string;
  model?: string;
}

export interface TutorResponse {
  answer: string;
  explanation: string;
  followUpQuestions?: string[];
  resources?: {
    title: string;
    description: string;
    url?: string;
  }[];
}

export async function askTutorQuestion(data: TutorQuestionRequest): Promise<TutorResponse> {
  const res = await apiRequest("POST", "/api/tutor/chat", data);
  return res.json();
}

export async function getChatHistory(userId: number, subjectId?: number) {
  const url = subjectId 
    ? `/api/tutor/history/${userId}?subjectId=${subjectId}` 
    : `/api/tutor/history/${userId}`;
  const res = await apiRequest("GET", url);
  return res.json();
}

export interface RecommendationRequest {
  userId: number;
  subject: string;
  performance: number;
}

export async function getTutorRecommendations(data: RecommendationRequest) {
  const res = await apiRequest("POST", "/api/tutor/recommendations", data);
  return res.json();
}
