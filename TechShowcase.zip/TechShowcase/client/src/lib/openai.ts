// This file serves as a client-side interface to OpenAI functionality
// The actual OpenAI calls are handled on the server to protect API keys

import { askTutorQuestion, getTutorRecommendations } from "./api";

/**
 * Interface for OpenAI-powered AI tutor interactions from client side
 */
export const aiTutor = {
  /**
   * Ask a question to the AI tutor
   * @param userId The ID of the user asking the question
   * @param subjectId The ID of the subject the question pertains to
   * @param question The question text
   * @returns Promise with the AI's response
   */
  askQuestion: async (userId: number, subjectId: number, question: string) => {
    return askTutorQuestion({
      userId,
      subjectId, 
      question
    });
  },
  
  /**
   * Get personalized resource recommendations based on user performance
   * @param userId The ID of the user
   * @param subject The subject name
   * @param performance User's performance metric (0-100)
   * @returns Promise with recommended resources
   */
  getRecommendations: async (userId: number, subject: string, performance: number) => {
    return getTutorRecommendations({
      userId,
      subject,
      performance
    });
  },
  
  /**
   * Process and format the AI response for display
   * @param response The raw AI response
   * @returns Formatted HTML string
   */
  formatResponse: (response: any): string => {
    if (typeof response === 'string') {
      try {
        response = JSON.parse(response);
      } catch (e) {
        return response;
      }
    }
    
    let formattedResponse = `<p>${response.answer}</p>`;
    formattedResponse += `<p class="mt-2">${response.explanation}</p>`;
    
    if (response.resources && response.resources.length > 0) {
      formattedResponse += `<div class="mt-3"><strong>Recommended Resources:</strong><ul class="list-disc ml-5 mt-1">`;
      response.resources.forEach(resource => {
        formattedResponse += `<li>${resource.title} - ${resource.description}</li>`;
      });
      formattedResponse += `</ul></div>`;
    }
    
    if (response.followUpQuestions && response.followUpQuestions.length > 0) {
      formattedResponse += `<div class="mt-3"><strong>You might also want to ask:</strong><ul class="list-disc ml-5 mt-1">`;
      response.followUpQuestions.forEach(q => {
        formattedResponse += `<li>${q}</li>`;
      });
      formattedResponse += `</ul></div>`;
    }
    
    return formattedResponse;
  }
};

export default aiTutor;
