import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/Sidebar";
import MobileHeader from "@/components/MobileHeader";
import Dashboard from "@/pages/Dashboard";
import AiTutor from "@/pages/AiTutor";
import StudyBuddy from "@/pages/StudyBuddy";
import Chat from "@/pages/Chat";
import Quiz from "@/pages/Quiz";
import Study from "@/pages/Study";
import Subjects from "@/pages/Subjects";
import Progress from "@/pages/Progress";
import Resources from "@/pages/Resources";
import Lesson from "@/pages/Lesson";
import Search from "@/pages/Search";
import VoiceStudy from "@/pages/VoiceStudy";
import GoogleServices from "@/pages/GoogleServices";
import ChatGPT from "@/pages/ChatGPT";
import Whiteboard from "@/pages/Whiteboard";
import Mathematics from "@/pages/Mathematics";
import Science from "@/pages/Science";
import Physics from "@/pages/Physics";
import Chemistry from "@/pages/Chemistry";
import History from "@/pages/History";
import Literature from "@/pages/Literature";
import Languages from "@/pages/Languages";
import Psychology from "@/pages/Psychology";
import Philosophy from "@/pages/Philosophy";
import Biology from "@/pages/Biology";
import MoodTracker from "@/pages/MoodTracker";
import Settings from "@/pages/Settings";
import { ThemeProvider } from "@/components/ui/ThemeProvider";
import { useState } from "react";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 0,
      retry: 1,
    },
  },
});

function Router() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onToggle={toggleSidebar} />
      <div className="flex-1 flex flex-col">
        <MobileHeader toggleSidebar={toggleSidebar} />
        <main className="flex-1 overflow-auto">
          <Switch>
            <Route path="/" component={Search} />
            <Route path="/search" component={Search} />
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/tutor" component={AiTutor} />
            <Route path="/study-buddy" component={StudyBuddy} />
            <Route path="/chatgpt" component={ChatGPT} />
            <Route path="/whiteboard" component={Whiteboard} />
            <Route path="/mathematics" component={Mathematics} />
            <Route path="/science" component={Science} />
            <Route path="/physics" component={Physics} />
            <Route path="/chemistry" component={Chemistry} />
            <Route path="/history" component={History} />
            <Route path="/literature" component={Literature} />
            <Route path="/languages" component={Languages} />
            <Route path="/psychology" component={Psychology} />
            <Route path="/philosophy" component={Philosophy} />
            <Route path="/biology" component={Biology} />
            <Route path="/mood-tracker" component={MoodTracker} />
            <Route path="/settings" component={Settings} />
            <Route path="/progress" component={Progress} />
            <Route path="/resources" component={Resources} />
            <Route path="/quiz" component={Quiz} />
            <Route path="/timer" component={Study} />
            <Route path="/labs" component={GoogleServices} />
            <Route path="/subjects" component={Subjects} />
            <Route path="/subjects/:id" component={Subjects} />
            <Route path="/lesson/:id" component={Lesson} />
            <Route path="/voice-study" component={VoiceStudy} />
            <Route>{() => <NotFound />}</Route>
          </Switch>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="edu-platform-theme">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;