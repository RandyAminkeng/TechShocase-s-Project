# LearnSmart AI - Intelligent Tutoring Platform

## Overview
LearnSmart AI is an educational platform that combines AI-powered tutoring with structured learning content. It features subject exploration, personalized progress tracking, and intelligent resource recommendations. The application uses a modern tech stack with React on the frontend and Express on the backend, with database operations handled through Drizzle ORM.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight alternative to React Router)
- **Data Fetching**: TanStack Query (React Query)
- **UI Components**: shadcn/ui component library (based on Radix UI)
- **Styling**: Tailwind CSS with a New York style theme
- **State Management**: React Query for server state, React hooks for local state

### Backend
- **Server**: Express.js running on Node.js
- **API Structure**: RESTful API with all endpoints prefixed with `/api`
- **Database Access**: Drizzle ORM for database operations
- **AI Integration**: OpenAI GPT-4o for AI tutoring capabilities

### Database
- **ORM**: Drizzle with PostgreSQL dialect configured
- **Schema**: Defined in `shared/schema.ts` with tables for users, subjects, courses, lessons, progress tracking, etc.
- **Migrations**: Using Drizzle Kit for schema migrations

### Authentication
- The application includes user management capabilities but authentication implementation is minimal in the current code

## Key Components

### Client
1. **Page Components**:
   - `Dashboard`: Main user entry point showing stats and learning progress
   - `AiTutor`: AI-powered learning assistant interface
   - `Subjects`: Library of available learning subjects
   - `Progress`: User learning progress tracking
   - `Resources`: Educational resources and materials

2. **UI Components**:
   - Comprehensive shadcn/ui component library
   - Custom components for specific application features
   - Responsive design with mobile navigation

3. **Shared Layout**:
   - `Sidebar`: Main navigation sidebar
   - `MobileHeader`: Header for mobile view with menu toggle

### Server
1. **API Routes**:
   - User management endpoints
   - Subject and course data endpoints
   - Progress tracking endpoints
   - AI tutoring integration

2. **OpenAI Integration**:
   - `generateTutorResponse`: Creates AI-powered educational responses
   - Uses GPT-4o model for high-quality tutoring

3. **Data Storage**:
   - Interface for database operations defined in `storage.ts`
   - Implements CRUD operations for all schema entities

## Data Flow

1. **User Interaction**:
   - User interacts with the UI
   - React components trigger API calls through React Query
   - Results are displayed and cached appropriately

2. **AI Tutoring**:
   - User submits a question in the AI Tutor interface
   - Question is sent to the backend with subject context
   - Server processes request through OpenAI API
   - Structured response is returned and displayed to the user

3. **Progress Tracking**:
   - User learning activities are tracked
   - Progress is stored in the database
   - Dashboard and Progress page display personalized stats and achievements

## External Dependencies

### Frontend
- `@radix-ui/*`: Various UI component primitives
- `@tanstack/react-query`: Data fetching and caching
- `class-variance-authority`: Component styling variants
- `cmdk`: Command palette functionality
- `date-fns`: Date utilities
- `embla-carousel-react`: Carousel component

### Backend
- `@neondatabase/serverless`: Database connection (for Neon Postgres)
- `drizzle-orm`: Database ORM
- `drizzle-zod`: Schema validation
- `openai`: OpenAI API client
- `express`: Web server framework

## Deployment Strategy

The application is configured for deployment on Replit with:

1. **Development Mode**:
   - `npm run dev`: Runs the server with development configuration
   - Vite development server for hot module replacement
   - Runtime error overlay for debugging

2. **Production Build**:
   - `npm run build`: 
     - Builds the client with Vite
     - Bundles the server with esbuild
   - `npm run start`: Runs the production build

3. **Database Management**:
   - `npm run db:push`: Pushes schema changes to the database
   - Requires `DATABASE_URL` environment variable to be set

## Getting Started

1. Set up environment variables:
   - `DATABASE_URL`: Your PostgreSQL connection string
   - `OPENAI_API_KEY`: OpenAI API key for AI tutoring features

2. Install dependencies:
   ```
   npm install
   ```

3. Push database schema:
   ```
   npm run db:push
   ```

4. Start development server:
   ```
   npm run dev
   ```

5. Access the application at: http://localhost:5000